-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 
-- Database : cms
-- 
-- Part : #1
-- Date : 2018-04-12 13:28:46
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ad`
-- -----------------------------
DROP TABLE IF EXISTS `ad`;
CREATE TABLE `ad` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `kinds` int(2) NOT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `sort` int(2) NOT NULL,
  `status` int(2) unsigned NOT NULL,
  `addtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ad`
-- -----------------------------
INSERT INTO `ad` VALUES ('44', '1', '', '/public/themes/Home/images/banner3.jpg', '', '0', '1', '1521612039');
INSERT INTO `ad` VALUES ('45', '1', '', '/public/themes/Home/images/banner1.jpg', '', '0', '1', '1521612039');
INSERT INTO `ad` VALUES ('46', '1', '', '/public/themes/Home/images/banner2.jpg', '', '0', '1', '1521612039');
INSERT INTO `ad` VALUES ('47', '1', 'rwer', '/public/themes/Home/images/banner4.jpg', 'htt', '0', '1', '1521612039');

-- -----------------------------
-- Table structure for `article`
-- -----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(2) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `titlecolor` varchar(255) NOT NULL,
  `fontstyle` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `content` mediumtext NOT NULL,
  `status` int(2) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `hits` int(11) unsigned NOT NULL,
  `posid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `article`
-- -----------------------------
INSERT INTO `article` VALUES ('1', '37', '22222222222222222', '', 'font-weight:bold;', '/uploads/20180321\\9c197a79866f0a4f31bd7c747691d6f2.png', '2222222222', '222222222222', '<p>222222222222222</p>', '1', '1521610397', '0', '');
INSERT INTO `article` VALUES ('3', '6', 'sdfsd', '', '', '/public/themes/Home/Picture/2017-10-12/59defb91a8ef9.png', '', '', '', '0', '1521610397', '0', '');
INSERT INTO `article` VALUES ('4', '6', 'sdf', '', '', '/public/themes/Home/Picture/2017-10-12/59defb91a8ef9.png', '', '', '', '0', '1521610397', '0', '');
INSERT INTO `article` VALUES ('5', '6', '北京市大兴区人民政府与北京市国有', '', '', '/public/themes/Home/Picture/2017-08-11/598d396942320.jpg', '8月14日，中关村国家自主创新示范区国家新媒体产业基地授牌仪式在国家新媒体产业', '北京市大兴区人民政府与北京市国有', '', '0', '1521610397', '0', '');
INSERT INTO `article` VALUES ('6', '6', '新京报：文化都汇开盘热销3.6亿', '', '', '/public/themes/Home/Picture/2017-08-10/598c2bf6ecc14.jpg', '新京报讯 （记者李捷）6月26日，位于大兴区国家新媒体基地、紧邻南五环的文化都汇首次开盘，开发商表示，开盘当天劲揽', '', '', '0', '1521610397', '0', '');
INSERT INTO `article` VALUES ('7', '6', '文化都汇——中国首家物联网国家标准', '', '', '/public/themes/Home/Picture/2017-08-18/59965cff6a304.jpg', '2016年7月11日，云集全球物联网技术与标准领域最顶尖级专家的“2016 国际开放', '', '', '0', '1521610397', '0', '');
INSERT INTO `article` VALUES ('8', '6', '北京市文化置业有限公司荣获“2017京', '', '', '/public/themes/Home/Picture/2017-10-12/59defb91a8ef9.png', '北京市文化置业有限公司荣获“2017京津冀影响力品牌”', '', '', '0', '1521610397', '0', '');
INSERT INTO `article` VALUES ('9', '40', '文化都汇', '', '', '/uploads/20180326\\17a26ba7391d0968f1fbda102cacbc7c.jpg', '', '', '<p><span style=\"line-height:1.5\"><span style=\"line-height:2.5;font-size:16px\">文化都汇是北京市文化置业有限公司重点打造的北京首席文创产业综合体，矗立于北京大兴国家新媒体产业基地，总建筑面积约</span></span><span style=\"line-height:2.5;font-size:16px\">14</span><span style=\"line-height:2.5;font-size:16px\">万㎡。项目集多功能智能办公、多业态商业、小面积办公、高端商务功能为一体，由</span><span style=\"line-height:2.5;font-size:16px\">5</span><span style=\"line-height:2.5;font-size:16px\">栋独立办公楼构成，</span><span style=\"line-height:2.5;font-size:16px\">3.8</span><span style=\"line-height:2.5;font-size:16px\">米层高，</span><span style=\"line-height:2.5;font-size:16px\">110-2800</span><span style=\"line-height:2.5;font-size:16px\">平鲜氧办公空间，自由组合，业态互动，可随需定制，独栋冠名，全面满足多元型企业办公。项目地处首都第二机场的空港经济圈，紧邻城市五环和京开高速，交通便利。所在的大兴区国家</span><a></a><span style=\"line-height:2.5;font-size:16px\">新媒体产业基地区域为政府重点投资区域，有着多项经济实惠的产业扶持政策。</span> &nbsp;</p><p style=\"text-align:left;text-indent:43px\"><span style=\"line-height:2.5;font-size:16px\">文化都汇以其超前的规划设计、完善的商务配套、强有力的扶持政策，已经成为全国文创企业高度关注的置业首选。</span> &nbsp;</p><p style=\"text-indent:43px\"><br/> </p><p style=\"text-indent:43px\"><img src=\"http://www.bjwhzy.com.cn/Uploads/Editor/2017-08-23/599d1c57e8f6c.jpg\" alt=\"\"/> &nbsp;</p><p><br/></p>', '1', '1522051075', '1', '');
INSERT INTO `article` VALUES ('10', '40', '北京文化产权交易中心', '', '', '/uploads/20180326\\5d144bbad012a8f86bb36b29e0b2a88e.jpg', '', '', '<p style=\"text-indent:40px\"><span style=\"font-size:16px;line-height:2.5\">2015年</span><span style=\"font-size:16px;line-height:2.5\">5</span><span style=\"font-size:16px;line-height:2.5\">月，根据市文资办和东城区政府《关于促进首都文化要素市场建设全面战略合作协议》，双方以“促进首都文化中心功能建设”为宗旨，合作建设北京文化产权交易中心。该项目总投资</span><span style=\"font-size:16px;line-height:2.5\">16</span><span style=\"font-size:16px;line-height:2.5\">亿元，由文化置业公司按照政府引导，市场化方式运作推进建设与运营，建成后将成为东城区的文化地标。</span> &nbsp;</p><p style=\"text-indent:40px\"><span style=\"font-size:16px;line-height:2.5\">项目地处东城区前门地区，东至前门东路，西至布巷子胡同，南至京泰龙国际酒店，北至阳平会馆南路。总占地面积</span><span style=\"font-size:16px;line-height:2.5\">0.82</span><span style=\"font-size:16px;line-height:2.5\">万平米，建筑面积共计</span><span style=\"font-size:16px;line-height:2.5\">6.10</span><span style=\"font-size:16px;line-height:2.5\">万平方米。项目致力于打造文化产权交易平台、文化产业“互联网</span><span style=\"font-size:16px;line-height:2.5\">+</span><span style=\"font-size:16px;line-height:2.5\">”投融资平台、文化企业孵化平台、文化产权登记托管保护平台、文化产权信息发布平台五大平台。</span> &nbsp;</p><p><br/></p>', '1', '1522051149', '0', '');
INSERT INTO `article` VALUES ('11', '40', '宋庄艺术小镇', '', '', '/uploads/20180326\\1e9e371fa04b83191b7d9f71cbdba781.jpg', '', '', '<p style=\"text-indent:40px\"><span style=\"line-height:2.5;font-size:16px\">2015年</span><span style=\"line-height:2.5;font-size:16px\">3</span><span style=\"line-height:2.5;font-size:16px\">月，根据文资办及文投集团的指示，文化置业公司通过市场竞拍方式，以</span><span style=\"line-height:2.5;font-size:16px\">10.8</span><span style=\"line-height:2.5;font-size:16px\">亿元获取宋庄</span><span style=\"line-height:2.5;font-size:16px\">A1</span><span style=\"line-height:2.5;font-size:16px\">地块，项目是按照政府引导和市场化运作原则，结合通州区政府提出的“建设世界文化名镇，打造中国文化硅谷，争创国家文化自主创新示范区”的战略构想，打造国际化的艺术聚集区。宋庄</span><span style=\"line-height:2.5;font-size:16px\">A1</span><span style=\"line-height:2.5;font-size:16px\">地块土地出让年限为商业</span><span style=\"line-height:2.5;font-size:16px\">40</span><span style=\"line-height:2.5;font-size:16px\">年、办公</span><span style=\"line-height:2.5;font-size:16px\">50</span><span style=\"line-height:2.5;font-size:16px\">年，规划总用地面积</span><span style=\"line-height:2.5;font-size:16px\">13.70</span><span style=\"line-height:2.5;font-size:16px\">万平方米，建设用地面积</span><span style=\"line-height:2.5;font-size:16px\">6.59</span><span style=\"line-height:2.5;font-size:16px\">万平方米，地上建筑面积</span><span style=\"line-height:2.5;font-size:16px\">16.47</span><span style=\"line-height:2.5;font-size:16px\">万平方米。</span> &nbsp;</p><p style=\"text-indent:40px\"><br/> </p><p><span style=\"line-height:2.5;font-size:16px\">项目地处通州区宋庄镇，紧邻宋庄文化聚集区中心街，周边艺术人才集聚，区位优势凸显。京哈高速、六环路两条交通线与项目相邻，距朝阳区</span><span style=\"line-height:2.5;font-size:16px\">CBD</span><span style=\"line-height:2.5;font-size:16px\">仅需</span><span style=\"line-height:2.5;font-size:16px\">30</span><span style=\"line-height:2.5;font-size:16px\">分钟车程，与首都国际机场距离</span><span style=\"line-height:2.5;font-size:16px\">13</span><span style=\"line-height:2.5;font-size:16px\">公里，辐射“首都城市圈”和“京津冀都市圈”。</span></p><p><br/></p>', '1', '1522051201', '0', '');
INSERT INTO `article` VALUES ('12', '43', '444444444444', '', '', '', '', '', '<p>4444444444<br/></p>', '1', '1522056571', '0', '');

-- -----------------------------
-- Table structure for `articles`
-- -----------------------------
DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '栏目',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(40) NOT NULL DEFAULT '' COMMENT '发布用户名',
  `title` varchar(120) NOT NULL DEFAULT '' COMMENT '标题',
  `title_style` varchar(225) NOT NULL DEFAULT '' COMMENT '标题样式',
  `thumb` varchar(225) NOT NULL DEFAULT '' COMMENT '缩略图',
  `keywords` varchar(120) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0：待发布;1:发布',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '允许评论',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0' COMMENT '阅读收费',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `copyfrom` varchar(255) NOT NULL DEFAULT '' COMMENT '来源',
  `fromlink` varchar(255) NOT NULL DEFAULT '' COMMENT '来源网址',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `articles`
-- -----------------------------
INSERT INTO `articles` VALUES ('60', '2', '0', '', '关于我们', 'font-weight:normal;', '/uploads/20180206\\b2e34b7c50be71a63258250e275a1ee4.png', 'qwerqweqw3423', 'werwerwer', '<p>werqaweqwewqweasdasqweqweqwwrew</p>', 'page_show', '0', '0', '0', '', '0', '0', '0', '1517902933', '1517904114', 'CLTPHP', 'http://www.cltphp.com/');
INSERT INTO `articles` VALUES ('72', '5', '1', 'admin', '视觉竞品分析怎么做？带你走进大厂核心方法论', 'color:rgb(255, 87, 34);font-weight:bold;', '/uploads/20180207\\4c2df5552f473a1110b6814ff7faeeb4.jpg', '设计', '经常有设计师朋友问如何做竞品分析，做分析最主要目标是通过竞品可以让设计师了解产品的一个重要途径，也就是常说的设计思维，通过对竞争对手产品检测，多观察了解对方的产品特点，然后在自己业务场景下提供符合当前产品解决方案。', '<h3><span style=\"color: #ff6600\"><strong>为什么要做竞品分析 ？&nbsp;&nbsp;</strong></span></h3><p><span class=\"\">经常有设计师朋友问如何做竞品分析，做分析最主要目标是通过竞品可以让设计师了解产品的一个重要途径，也就是常说的设计思维，通过对竞争对手产品检测，多观察了解对方的产品特点，然后在自己业务场景下提供符合当前产品解决方案。</span></p><p><span class=\"\">当对竞品了解足够深的前提下，产出的设计方案自然而然会比自己想的正确可能性更大，因为你看的足够多了，心中对各个业务模块，视觉样式能如数家珍，自然而然设计的正确性能提高，但是很多设计师做不到这一点，比如</span>谁能默写出微信4个主导航里面的每个功能结构？包括我自己都未必都背出来。</p><p>所以需要做竞品分析帮助我们了解产品功能，了解设计可能性，另外能随时知己知彼，在设计时做出正确设计决策。</p><p>&nbsp;</p><h3><span style=\"color: #ff6600\"><strong>&nbsp;竞品分析的维度？&nbsp;&nbsp;</strong></span></h3><p><img class=\"alignnone size-full wp-image-119771\" src=\"/ueditor/php/upload/image/20180207/1517995450134207.jpg\" alt=\"jingpinfenxi_06\" width=\"1080\" height=\"633\"/></p><p class=\"\">竞品分析有两个纬度，一个是功能交互纬度，另一个视觉纬度。<span class=\"\">今天只讲视觉维度，在APP中就是：<strong>色彩、UIkit、按钮、图文关系、表单、icon、导航、</strong><strong>弹窗等，</strong>也可以理解为</span><strong>形、色、字、构、质</strong>去分析<strong>。</strong></p><ul class=\" list-paddingleft-2\"><li><p><strong><span class=\"\">形：品牌符号、图形&nbsp;<span class=\"\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></span></strong></p></li><li><p><strong><span class=\"\">色：颜色、对比色、品牌色、饱和度等</span></strong></p></li><li><p><strong><span class=\"\">字：页面中字体、不同字体感受是不一样的</span></strong></p></li><li><p><strong><span class=\"\">构：结构，界面在结构是居中，还是偏左或偏右</span></strong></p></li><li><p><strong><span class=\"\">质：质感，扁平、3D、拟物化等</span></strong></p></li></ul><p><span class=\"\">以上是构建设计的所有元素，任何设计都离不开这些，那么在看竞品的时候同理也是围绕这些点去分析。可以分析单个APP，也可以横向对比分析。</span></p><p>&nbsp;</p><h3><span style=\"color: #ff6600\"><strong>竞品的选择&nbsp; &nbsp;</strong></span></h3><p><span class=\"\">以电商为例，需要研究全球TOP如ebay、亚马逊、韩国的SSG和R9CM、以及国内垂直领域独角兽，和一些设计优秀的应用，如Airbnb、Pinterest、Instagram等。</span></p><p><span class=\"\">跨领域分析，比如想做图文排版分析，那么除了竞品外，还需要关注新闻领域的，比如Yahoo News、网易新闻等，这些APP的图文板式是做的最好的，值得去学习。</span></p><p><span class=\"\">下面我围绕一个简单技法，页面中分隔来做个分析，梳理出业内通用技法特点，定出设计决策依据。</span></p><p>&nbsp;</p><h3><span style=\"color: #000000\"><strong>1.灰色描边强调分隔</strong></span></h3><p><span class=\"\">白色或浅色商品图四周添加1像素灰色描边强调分隔。</span></p><p><img class=\"alignnone size-full wp-image-119768\" src=\"/ueditor/php/upload/image/20180207/1517995450247260.jpg\" alt=\"jingpinfenxi_03\" width=\"756\" height=\"1010\"/></p><p>&nbsp;</p><h3><span style=\"color: #000000\"><strong>2.页面留白分隔</strong></span></h3><p><span class=\"\">足够大的留白来强调图片和图片之间关系。</span></p><p><img class=\"alignnone size-full wp-image-119769\" src=\"/ueditor/php/upload/image/20180207/1517995451104928.jpg\" alt=\"jingpinfenxi_04\" width=\"742\" height=\"1010\"/></p><p>&nbsp;</p><h3><span style=\"color: #000000\"><strong>3.灰色透明蒙版分隔</strong></span></h3><p><span class=\"\">白色商品图上叠加3-5%透明度黑色，形成图片轮廓。</span></p><p><img class=\"alignnone size-full wp-image-119775\" src=\"/ueditor/php/upload/image/20180207/1517995452437805.jpg\" alt=\"jingpinfenxi_10\" width=\"734\" height=\"506\"/></p><p>&nbsp;</p><h3><strong><span style=\"color: #000000\">4.结合设计趋势</span></strong></h3><p><span class=\"\">设计更轻量化，简洁，利用留白来强调图片和图片之间关系。</span></p><p><img class=\"alignnone size-full wp-image-119773\" src=\"/ueditor/php/upload/image/20180207/1517995452522405.jpg\" alt=\"jingpinfenxi_08\" width=\"1080\" height=\"597\"/></p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-119772\" src=\"/ueditor/php/upload/image/20180207/1517995453197085.jpg\" alt=\"jingpinfenxi_07\" width=\"686\" height=\"954\"/></p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-119779\" src=\"/ueditor/php/upload/image/20180207/1517995454951174.jpg\" alt=\"jingpinfenxi_14\" width=\"1080\" height=\"723\"/></p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-119778\" src=\"/ueditor/php/upload/image/20180207/1517995455124026.jpg\" alt=\"jingpinfenxi_13\" width=\"1080\" height=\"933\"/></p><p>&nbsp;</p><h3><span style=\"color: #ff6600\"><strong>设计策略产出&nbsp;</strong></span></h3><p><strong>设计技法1：根据不同场景，在需要明确页面风格，达到页面统一效果，在白色商品上增加灰色透明蒙版，形成页面栅格对齐。</strong></p><p><img class=\"alignnone size-full wp-image-119774\" src=\"/ueditor/php/upload/image/20180207/1517995456172128.jpg\" alt=\"jingpinfenxi_09\" width=\"644\" height=\"642\"/></p><p>&nbsp;</p><p><strong>设计技法2：内容左右留白的展示图片相关处理：商品图片叠加在底层背景。</strong></p><p><img class=\"alignnone size-full wp-image-119788\" src=\"/ueditor/php/upload/image/20180207/1517995456146308.jpeg\" alt=\"Visual analysis of competing products 01\" width=\"622\" height=\"232\"/></p><p><span class=\"\" style=\"color: #ff6600\"><span style=\"color: #999999\">上周边留出2px边框，解决白色背景的商品显示问题</span></span></p><p>&nbsp;</p><p><strong>设计技法3：根据具有可表现的业务，图片个性化效果，可以增加渐变效果来凸显业务特殊性。</strong></p><p><img class=\"alignnone size-full wp-image-119776\" src=\"/ueditor/php/upload/image/20180207/1517995457269206.jpg\" alt=\"jingpinfenxi_11\" width=\"610\" height=\"242\"/></p><p class=\"\"><span style=\"color: #999999\">▲&nbsp; 在原图上增加一层彩色蒙版,样式叠加为–线性光，增强图片特殊场景个性化</span></p><p class=\"\"><br/></p><p><span class=\"\">通过分析我们可以得出新的设计规范，以及不同场景处理分隔的技法，可以根据场景去得出设计的确定性，让你的设计更加科学。</span></p><p><span class=\"\">除了分析技法，其实分析产品，分析交互，分析功能大同小异，重点是要掌握这种分析路径，让我们更加了解产品！</span></p><p><br/></p>', 'article_show', '1', '1', '0', '', '0', '0', '0', '1517995475', '1517995475', 'MINGYU', '');
INSERT INTO `articles` VALUES ('73', '5', '1', 'admin', '一个可以很好屏蔽外界干扰的星球沙发 The Planet by MZPA', 'font-weight:normal;', '', '设计', '这是一件亮相于巴黎设计周上的作品，名为“The Planet”（星球沙发），由MZPA团队开发。这款多边形近似圆形的私密空间对外界干扰有着很好的物理屏障作用，内部舒适的半包围式软垫，让置身其中的人感到非常舒适。', '<p>这是一件亮相于巴黎设计周上的作品，名为“The Planet”（星球沙发），由<a href=\"https://mzpa.co/the-planet\" target=\"_blank\">MZPA</a>团队开发。这款多边形近似圆形的私密空间对外界干扰有着很好的物理屏障作用，内部舒适的半包围式软垫，让置身其中的人感到非常舒适。</p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-56841\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-13.jpg\" alt=\"\" width=\"800\" height=\"529\"/></p><p>&nbsp;</p><p>除此之外，内部还提供了LED照明、USB接口、无限对讲系统、平板电脑支架以及迷你咖啡桌甚至顶部的太阳能供电板等设施。仿佛一个微型太空旅行仓。</p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-56836\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-7.jpg\" alt=\"\" width=\"820\" height=\"462\"/></p><p><img class=\"alignnone size-full wp-image-56844\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-16.jpg\" alt=\"\" width=\"800\" height=\"530\"/></p><p><img class=\"alignnone size-full wp-image-56838\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-9.jpg\" alt=\"\" width=\"820\" height=\"462\"/></p><p>&nbsp;</p><p>如果你是一个喜欢安静、思考、独处的家伙，那么这件星球沙发一定太合适你了。在里面一定能够获得充足的灵感和创意。</p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-56843\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-15.jpg\" alt=\"\" width=\"800\" height=\"1120\"/></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-3.jpg\"><img class=\"alignnone size-full wp-image-56833\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-3.jpg\" alt=\"\" width=\"820\" height=\"462\"/></a></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-4.jpg\"><img class=\"alignnone size-full wp-image-56834\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-4.jpg\" alt=\"\" width=\"820\" height=\"462\"/></a></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-6.jpg\"><img class=\"alignnone size-full wp-image-56835\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-6.jpg\" alt=\"\" width=\"820\" height=\"462\"/></a></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-8.jpg\"><img class=\"alignnone size-full wp-image-56837\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-8.jpg\" alt=\"\" width=\"820\" height=\"462\"/></a></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-11.jpg\"><img class=\"alignnone size-full wp-image-56839\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-11.jpg\" alt=\"\" width=\"800\" height=\"529\"/></a></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-12.jpg\"><img class=\"alignnone size-full wp-image-56840\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-12.jpg\" alt=\"\" width=\"800\" height=\"529\"/></a></p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-56846\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA.jpg\" alt=\"\" width=\"820\" height=\"462\"/></p><p>&nbsp;</p><p><img class=\"alignnone size-full wp-image-56842\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-14.jpg\" alt=\"\" width=\"800\" height=\"529\"/></p><p>&nbsp;</p><p><a href=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-17.jpg\"><img class=\"alignnone size-full wp-image-56845\" src=\"http://www.ideamsg.com/wp-content/uploads/2017/12/The-Planet-by-MZPA-17.jpg\" alt=\"\" width=\"800\" height=\"1122\"/></a></p><p>&nbsp;</p><p><br/></p>', 'page_show', '1', '0', '0', '', '0', '0', '0', '1518056052', '1518056052', 'mingyu', '');
INSERT INTO `articles` VALUES ('74', '6', '1', 'admin', '上海国际旅游度假区全新logo发布', 'font-weight:normal;', '', '品牌', '2月1日下午，“上海国际旅游度假区品牌推广专家委员会”正式成立，并公布了上海国际旅游度假区全新视觉标识及首部官方形象推广片。 ', '<p style=\"line-height: 1.75em;\">2月1日下午，“上海国际旅游度假区品牌推广专家委员会”正式成立，并公布了上海国际旅游度假区全新视觉标识及首部官方形象推广片。标志着上海国际旅游度假区2018年度宣传推广工作正式启动，并向国际化、品牌化方向深入推进。</p><p style=\"text-align: center; line-height: 1.75em;\"><img src=\"http://img.cndesign.com/upload/news/20180207/ce581ce3d8df4b88be7480059eb5bc58.png\" title=\"上海国际旅游度假区新logo.png\" alt=\"上海国际旅游度假区新logo.png\"/></p><p style=\"line-height: 1.75em;\">LOGO由上海国际旅游度假区（Shanghai\r\n International Resort）英文缩写SHIR字母变形演绎成飘舞的彩带， \r\n其中H和I的形态显现为舞动的人物形象，在S和R的呵护之间，代表一家人在度假区里愉快美好的游玩心情。飘带灵动翻转、色彩变幻，表达了度假区多元化和多种文化融合的特点。</p><p style=\"text-align: center; line-height: 1.75em;\"><img src=\"http://img.cndesign.com/upload/news/20180207/c920bf4bf1c743bfaccb1f8e378b7fc2.gif\" title=\"上海.gif\" alt=\"上海.gif\"/></p><p style=\"line-height: 1.75em;\">主色调采用蓝橙绿三种颜色，绿色代表环保、蓝色代表科技、橙色代表人文，暗示了绿色生态科技结合的人文之美。同时，“梦·享之地”的品牌宣传口号契合了度假区打造理想、温情、多元国际化的休闲度假首选地目标。</p><p style=\"text-align: center; line-height: 1.75em;\"><img src=\"http://img.cndesign.com/upload/news/20180207/a366252809464cc9a95302cc10534048.png\" title=\"上海国际旅游度假区新logo1.png\" alt=\"上海国际旅游度假区新logo1.png\"/></p><p style=\"text-align: center; line-height: 1.75em;\"><img src=\"http://img.cndesign.com/upload/news/20180207/7f5c3aafa28f41338ca7b9e0ac7557e1.png\" title=\"上海国际旅游度假区新logo2.png\" alt=\"上海国际旅游度假区新logo2.png\"/></p><p style=\"text-align: center; line-height: 1.75em;\"><img src=\"http://img.cndesign.com/upload/news/20180207/3c43ccba20ac4be3b8fb21663ca5acb5.png\" title=\"上海国际旅游度假区新logo3.png\" alt=\"上海国际旅游度假区新logo3.png\"/></p><p style=\"line-height: 1.75em;\">度假区管委会联合度假区各大主体拍摄制作了度假区开放以来的首部官方形象推广片，以“爱情”、“友情”、“亲情”、“温情”为主线，围绕从清晨到夜晚的时间轴，串联起度假区内主要的游乐项目和服务设施，梳理回顾重要的文娱节庆活动，度假区的特色区域和游客市民的情感在宣传片中交织汇聚，诠释“梦·享之地”的品牌理念。</p><p><br/></p>', 'article_show', '1', '1', '0', '', '0', '0', '0', '1518062239', '1518062239', 'mingyu', '');

-- -----------------------------
-- Table structure for `attachment`
-- -----------------------------
DROP TABLE IF EXISTS `attachment`;
CREATE TABLE `attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` char(15) NOT NULL DEFAULT '' COMMENT '所属模块',
  `filename` char(50) NOT NULL DEFAULT '' COMMENT '文件名',
  `filepath` char(200) NOT NULL DEFAULT '' COMMENT '文件路径+文件名',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `fileext` char(10) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `uploadip` char(15) NOT NULL DEFAULT '' COMMENT '上传IP',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未审核1已审核-1不通过',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `manage_id` int(11) NOT NULL COMMENT '审核者id',
  `audit_time` int(11) NOT NULL COMMENT '审核时间',
  `use` varchar(200) DEFAULT NULL COMMENT '用处',
  `download` int(11) NOT NULL DEFAULT '0' COMMENT '下载量',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `filename` (`filename`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE,
  KEY `manage_id` (`manage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='附件表';

-- -----------------------------
-- Records of `attachment`
-- -----------------------------
INSERT INTO `attachment` VALUES ('11', 'manage', '1518139184.png', './uploads/avatar/1518139184.png', '417', 'png', '1', '127.0.0.1', '1', '1518139184', '1', '1518139184', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('25', 'manage', '1517458670.png', './uploads/avatar/1517458670.png', '15', 'png', '28', '127.0.0.1', '1', '1517458670', '28', '1517458670', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('26', 'manage', '1517534339.png', './uploads/avatar/1517534339.png', '1', 'png', '29', '127.0.0.1', '1', '1517534339', '29', '1517534339', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('27', 'manage', '1518060835.png', './uploads/avatar/1518060835.png', '845', 'png', '97', '127.0.0.1', '1', '1518060835', '97', '1518060835', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('28', 'manage', '1518060917.png', './uploads/avatar/1518060917.png', '522', 'png', '98', '127.0.0.1', '1', '1518060917', '98', '1518060917', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('29', 'manage', '1521290387.png', './uploads/avatar/1521290387.png', '215', 'png', '99', '127.0.0.1', '1', '1521290388', '99', '1521290388', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('30', 'manage', '1521290942.png', './uploads/avatar/1521290942.png', '182', 'png', '0', '127.0.0.1', '1', '1521290942', '0', '1521290942', 'manage_thumb', '0');
INSERT INTO `attachment` VALUES ('31', 'manage', '1521350183.png', './uploads/avatar/1521350183.png', '183', 'png', '0', '127.0.0.1', '1', '1521350183', '0', '1521350183', 'manage_thumb', '0');

-- -----------------------------
-- Table structure for `category`
-- -----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) NOT NULL DEFAULT '',
  `catdir` varchar(30) NOT NULL DEFAULT '',
  `parentdir` varchar(50) NOT NULL DEFAULT '',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `moduleid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `module` char(24) NOT NULL DEFAULT '',
  `arrparentid` varchar(255) NOT NULL DEFAULT '',
  `arrchildid` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `keywords` varchar(200) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `image` varchar(100) NOT NULL DEFAULT '',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `template_list` varchar(20) NOT NULL DEFAULT '',
  `template_show` varchar(20) NOT NULL DEFAULT '',
  `pagesize` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `listtype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `category`
-- -----------------------------
INSERT INTO `category` VALUES ('1', '新闻中心', 'news', '', '0', '2', 'article', '0', '1,5,6', '0', 'NEWS CENTER', '最新动态', '最新动态', '1', '0', '1', '0', '/public/themes/Home/images/tu33.jpg', '1', '', 'article_list', 'article_show', '14', '1,2,3', '0', '0');
INSERT INTO `category` VALUES ('2', '关于我们', 'about', '', '0', '13', 'page', '0', '2,33,34,35,36,37', '0', 'ABOUT US', 'CLTPHP内容管理系统，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。', 'CLTPHP内容管理系统，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。', '0', '0', '1', '0', '/public/themes/Home/Picture/2017-08-10/598c25402f788.jpg', '0', '', 'article_list', 'article_show', '1', '', '0', '0');
INSERT INTO `category` VALUES ('4', '采购平台', 'product', '', '0', '2', 'article', '0', '4,43,44,45', '0', 'purchasing platform', 'CLTPHP系统操作,CLTPHP,CLTPHP内容管理系统', 'CLTPHP系统操作,CLTPHP,CLTPHP内容管理系统', '3', '0', '1', '0', '/public/themes/Home/images/tu49.jpg', '0', '', 'article_list', 'article_show', '0', '1,2,3', '0', '0');
INSERT INTO `category` VALUES ('3', '主营业务', 'services', '', '0', '2', 'article', '0', '3,40,41,42', '0', 'product service', '产品服务,CLTPHP,CLTPHP内容管理系统', '产品服务', '2', '0', '1', '0', '/public/themes/Home/images/tu50.jpg', '0', '', 'article_list', 'article_show', '15', '1,2,3', '0', '0');
INSERT INTO `category` VALUES ('33', '组织架构', 'about', 'about/', '2', '13', 'page', '0,2', '33', '0', 'asdfasdf', 'asdfasdf', 'asdfasf', '2', '0', '1', '0', '', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('5', '集团新闻', 'news', 'news/', '1', '2', 'article', '0,1', '5', '0', 'CLTPHP动态', 'CLTPHP动态', 'CLTPHP动态', '1', '0', '1', '0', '/public/themes/Home/images/tu33.jpg', '0', '', 'article_list', 'article_show', '5', '1,2,3', '0', '0');
INSERT INTO `category` VALUES ('6', '公司新闻', 'news', 'news/', '1', '2', 'article', '0,1', '6', '0', 'CLTPHP相关知识1', 'CLTPHP相关知识', 'CLTPHP相关知识', '0', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '14', '', '0', '0');
INSERT INTO `category` VALUES ('34', '公司介绍', 'about', 'about/', '2', '13', 'page', '0,2', '34', '0', 'asdfasdf', 'asdfasdf', 'asdfasf', '0', '0', '1', '0', '', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('35', '领导致辞', 'about', 'about/', '2', '13', 'page', '0,2', '35', '0', 'asdfasdf', 'asdfasdfsdfs', 'asdfasf', '1', '0', '1', '0', '', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('36', '企业文化', 'about', 'about/', '2', '13', 'page', '0,2', '36', '0', 'asdfasdf', 'asdfasdf', 'asdfasfsdfsdf', '3', '0', '1', '0', '/public/themes/Home/Picture/2017-08-10/598c2580ea2a8.jpg', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('37', '发展历程', 'about', 'about/', '2', '2', 'article', '0,2', '37', '0', '发展历程', '发展历程', '发展历程', '4', '0', '1', '0', '', '0', '', 'article_show_time', 'article_show_time', '0', '', '0', '0');
INSERT INTO `category` VALUES ('38', '行业新闻', 'news', 'news/', '1', '2', 'article', '0,1', '38', '0', '', '', '', '2', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('39', '其他新闻', 'news', 'news/', '1', '2', 'article', '0,1', '39', '0', '', '', '', '3', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('40', '文创功能区开发建设', 'services', 'services/', '3', '2', 'article', '0,3', '40', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('41', '产业投资', 'services', 'services/', '3', '13', 'page', '0,3', '41', '0', '', '', '', '2', '0', '1', '0', '', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('42', '资产运营', 'services', 'services/', '3', '2', 'article', '0,3', '42', '0', '', '', '', '1', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('43', '招标公告', 'product', 'product/', '4', '2', 'article', '0,4', '43', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('44', '中标公告', 'product', 'product/', '4', '2', 'article', '0,4', '44', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('45', '监督举报', 'product', 'product/', '4', '13', 'page', '0,4', '45', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('46', '党群工作', 'worker', '', '0', '2', 'article', '0', '46', '0', 'MASSES WORK', '', '', '4', '0', '1', '0', '/public/themes/Home/images/tu51.jpg', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('47', '党建工作', 'worker', 'worker/', '46', '2', 'article', '0,46', '47', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('48', '职工之家', 'worker', 'worker/', '46', '2', 'article', '0,46', '48', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'article_list', 'article_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('49', '联系我们', 'contact', '', '0', '13', 'page', '0', '49', '0', 'CONTACT US', '', '', '5', '0', '1', '0', '/public/themes/Home/images/tu64.jpg', '0', '', 'page_show', 'page_show', '0', '', '0', '0');
INSERT INTO `category` VALUES ('50', '人才理念', 'contact', 'contact/', '49', '13', 'page', '0,49', '50', '0', '', '', '', '0', '0', '1', '0', '', '0', '', 'page_show_contact', 'page_show_contact', '0', '', '0', '0');
INSERT INTO `category` VALUES ('51', '工作机会', 'contact', 'contact/', '49', '13', 'page', '0,49', '51', '0', '', '', '', '1', '0', '1', '0', '/public/themes/Home/images/tu64.jpg', '0', '', 'page_show_contact', 'page_show_contact', '0', '', '0', '0');

-- -----------------------------
-- Table structure for `clt_article`
-- -----------------------------
DROP TABLE IF EXISTS `clt_article`;
CREATE TABLE `clt_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `title_style` varchar(225) NOT NULL DEFAULT '',
  `thumb` varchar(225) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `copyfrom` varchar(255) NOT NULL DEFAULT 'CLTPHP',
  `fromlink` varchar(255) NOT NULL DEFAULT 'http://www.cltphp.com/',
  `address` varchar(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`listorder`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `clt_article`
-- -----------------------------
INSERT INTO `clt_article` VALUES ('1', '3', '1', 'admin', '你可能忽略掉的后台小功能（一）', 'color:rgb(247, 184, 36);font-weight:normal;', '', '你可能忽略掉的后台小功能（一）', '你可能忽略掉的后台小功能（一）', '<p>刷新：刷新当前标签页</p><p>关闭当前：关闭当前标签页</p><p>关闭其他：除选中的标签页外，关闭其他全部标签页</p><p>关闭所有：关闭全部标签页</p><p><img src=\"/public/uploads/ueditor/image/20170907/1504764868495338.png\" title=\"1504764868495338.png\" alt=\"ac (1).png\"/></p>', '0', '2', '1', '1', '', '0', '0', '800', '1499760262', '1504764870', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('2', '3', '1', 'admin', 'CLTPHP开放式模型设计', 'color:rgb(255, 87, 34);font-weight:bold;', '', 'CLTPHP开放式模型设计', 'CLTPHP内容管理系统采用了区别于传统cms的开放式模型设计，让网站的栏目及内容随这站长的想法而设计、改变。', '<p>　　CLTPHP内容管理系统采用了区别于传统cms的开放式模型设计，让网站的栏目及内容随这站长的想法而设计、改变。</p><p>　　在网站建设中，我们会把不同的内容以不同的方式展示，传统网站得手动建立不同的数据表，然后通过编码，建立不同的后台栏目，在针对不同的栏目添加各自对应的内容，这期间，还得写不同的添加页面来适应各个分类，最后，再把不同的栏目展示到前台。</p><p>　　CLTPHP的解决方式是，通过后台添加模型，建立不同的表，</p><p><img src=\"/public/uploads/ueditor/image/20170907/1504764406381046.png\" title=\"1504764406381046.png\" alt=\"m (1).png\"/></p><p>模型是要和栏目绑定的，不同的栏目就会有不同的内容模型，或者是同一类栏目内容，会归纳到同一模型下。这里产品模型绑定为文章模型。</p><p><img src=\"/public/uploads/ueditor/image/20170907/1504764538131048.png\" title=\"1504764538131048.png\" alt=\"cm (1).png\"/></p><p>一个模型可以理解为一张表，模型字段即使这张表的字段。</p><p><img src=\"/public/uploads/ueditor/image/20170907/1504764618106985.png\" title=\"1504764618106985.png\" alt=\"mf (1).png\"/></p><p>每一个字段最终呈现的方式可能会不一样，所以，字段属性就应用而生了，</p><p><img src=\"/public/uploads/ueditor/image/20170907/1504764686677148.png\" title=\"1504764686677148.png\" alt=\"ef (1).png\"/></p><p>以标题举例，标题会对应自己显示颜色，及是否加粗显示，还有，是否对应一个缩略图。这些通过模型字段的设置，就可以在添加栏目里体现出来，参考下图</p><p><img src=\"/public/uploads/ueditor/image/20170907/1504764760851814.png\" title=\"1504764760851814.png\" alt=\"en (1).png\"/></p><p>通过上图，我们能很清楚知道，这个栏目对应的模型里，标题字段一定设置了标题图片和标题样式。最后，栏目或者某一篇内容可以绑定一个模版，用来前台展示。不同的模版有不同的展示风格，这里，开发者可以扩延出无限的前台展示模版。其规则是，列表页 &nbsp;<strong>表名-list-自定义&nbsp;</strong>&nbsp;内容页 &nbsp;<strong>表名-show-自定义</strong></p>', '0', '2', '1', '0', '', '0', '0', '1296', '1499760655', '1504764762', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('24', '5', '1', 'admin', 'CLTPHP5.1更新', 'color:rgb(0, 153, 102);font-weight:bold;', '', 'CLTPHP5.1更新', 'CLTPHP5.1更新', '<p>更新内容：</p><p>1.优化双编辑器（编辑器切换不兼容问题，layedit上传不了图片问题，layedit无法编辑问题）</p><p>2.添加自定义标签（参考首页）</p><p>3.修复前台手机兼容问题</p><p><br/></p><p>下载地址：<a target=\"_self\" href=\"http://o95ehky7c.bkt.clouddn.com/cltphp5.1.zip\">点击下载CLTPHP5.1</a></p><p>升级补丁：<a target=\"_self\" href=\"http://o95ehky7c.bkt.clouddn.com/CLTPHP5.0s%E5%8D%87%E7%BA%A75.1%E5%8C%85.zip\">CLTPHP5.0升级5.1</a></p>', '0', '0', '1', '0', '', '0', '0', '286', '1503307064', '1505264247', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('3', '5', '1', 'admin', '关于CLTPHP你错过了什么？', 'color:rgb(247, 184, 36);font-weight:normal;', '', '关于CLTPHP你错过了什么？', '关于CLTPHP你错过了什么？', '<p><a target=\"_blank\" href=\"http://www.cltphp.com\">CLTPHP</a>官方QQ群<a target=\"_blank\" title=\"点击加入\" href=\"http://shang.qq.com/wpa/qunwpa?idkey=003995f61e8bdf5e79e0241b3136b9803ea498833535bbb3aa14004966858349\">229455880</a>，来这里和大家一起讨论更多<a target=\"_blank\" href=\"http://www.cltphp.com\">CLTPHP</a>相关的问题和操作方法，同时可以掌握<a target=\"_self\" href=\"http://www.cltphp.com/home/news/index/catId/49.html\">CLTPHP的最新动态</a>。</p><p>另外，站长会在群里随时更新一些好玩的，或者好用的资源。</p>', '0', '1', '1', '0', '', '0', '0', '355', '1498035408', '1499834839', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('4', '5', '1', 'admin', 'CLTPHP4.0正式发布', 'color:rgb(95, 184, 120);font-weight:bold;', '/uploads/20170905/14d6955eda9e9019ba28f49cb02856b3.jpg', 'CLTPHP4.0正式发布', 'CLTPHP4.0正式发布', '<p><a target=\"_self\" href=\"http://www.cltphp.com/\">CLTPHP4.0</a>正式发布，<a target=\"_self\" href=\"http://www.cltphp.com/\">CLTPHP4.0</a>采用ThinkPHP+Layui+AngularJS实现完成。</p>', '0', '2', '1', '0', '', '0', '0', '1022', '1497949408', '1504597814', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('5', '5', '1', 'admin', 'CLTPHP4.2版本更新', 'color:rgb(95, 184, 120);font-weight:bold;', '', 'CLTPHP4.2版本更新,CLTPHP,CLTPHP内容管理系统', 'CLTPHP4.2版本更新', '<p>更新内容</p><p>1.升级ThinkPHP框架到5.0.10</p><p>2.后台栏目添加/编辑文章，点击返回按钮定位到当前栏目</p><p>3.后台增加主站捐献功能</p><p>4.微信管理调整，添加“生成菜单”功能</p><p><br></p><p>推荐环境：apache2.4+php5.5(以上)+mysql5.0(以上)</p><p>开发环境：phpStudy 2016 &nbsp;php5.5.38</p><div><br></div>', '0', '2', '1', '0', '', '0', '0', '617', '1499159138', '1499916031', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('6', '5', '1', 'admin', 'CLTPHP操作文档不断更新中', 'color:rgb(30, 159, 255);font-weight:bold;', '/uploads/20170905/6e9055437e213226c29c590ca82c9978.png', 'CLTPHP操作文档不断更新中', 'CLTPHP操作文档不断更新中', '<p>　　新版<a target=\"_self\" href=\"http://www.cltphp.com/\">CLTPHP</a>操作及开发手册不断更新中，欢迎大家购买学习。<img src=\"file:///C:/Users/ADMINI~1/AppData/Local/Temp/%W@GJ$ACOF(TYDYECOKVDYB.png\">https://www.kancloud.cn/chichu/cltphp。</p><p>　　文档的延迟更新，给各位爱好者带来的不便，我们深感抱歉，但也请大家理解我们的难处。</p><p>　　开发团队向大家保证，会尽快完善文档，尽量解决大家在开发过程中遇到的种种问题。</p><p>　　文档是收费的，开发的继续开发，骂娘的继续骂娘，收费的或许会越来越贵。</p><div><br></div>', '0', '2', '1', '0', '', '0', '0', '800', '1499677661', '1504597769', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('7', '6', '1', 'admin', 'ThinkPHP隐藏index.php', 'color:rgb(57, 61, 73);font-weight:bold;', '', 'ThinkPHP隐藏index.php,CLTPHP,CLTPHP内容管理系统,thinkphp,thinkphp内容管理系统', 'ThinkPHP隐藏index.php,CLTPHP,CLTPHP内容管理系统,thinkphp,thinkphp内容管理系统', '<p>可以通过URL重写隐藏应用的入口文件<code>index.php</code>,下面是相关服务器的配置参考：</p><h2 data-line=\"2\" class=\"line\"><a id=\"_Apache__2\"></a>[ Apache ]</h2><ol><li>httpd.conf配置文件中加载了mod_rewrite.so模块</li><li>AllowOverride None 将None改为 All</li><li>把下面的内容保存为.htaccess文件放到应用入口文件的同级目录下</li></ol><pre><code><span class=\"hljs-section\">&lt;IfModule mod_rewrite.c&gt;</span>\n<span class=\"hljs-attribute\"><span class=\"hljs-nomarkup\">Options</span></span> +FollowSymlinks -Multiviews\n<span class=\"hljs-attribute\"><span class=\"hljs-nomarkup\">RewriteEngine</span></span> <span class=\"hljs-literal\">on</span>\n\n<span class=\"hljs-attribute\"><span class=\"hljs-nomarkup\">RewriteCond</span></span> <span class=\"hljs-variable\">%{REQUEST_FILENAME}</span> !-d\n<span class=\"hljs-attribute\"><span class=\"hljs-nomarkup\">RewriteCond</span></span> <span class=\"hljs-variable\">%{REQUEST_FILENAME}</span> !-f\n<span class=\"hljs-attribute\"><span class=\"hljs-nomarkup\">RewriteRule</span></span> ^(.*)$ index.php?/<span class=\"hljs-number\">$1</span><span class=\"hljs-meta\"> [QSA,PT,L]</span>\n<span class=\"hljs-section\">&lt;/IfModule&gt;</span>\n</code></pre><h2 data-line=\"18\" class=\"line\"><a id=\"_IIS__18\"></a>[ IIS ]</h2><p>如果你的服务器环境支持ISAPI_Rewrite的话，可以配置httpd.ini文件，添加下面的内容：</p><pre><code><span class=\"hljs-attribute\"><span class=\"hljs-nomarkup\">RewriteRule</span></span> (.*)$ /index\\.php\\?s=<span class=\"hljs-number\">$1</span><span class=\"hljs-meta\"> [I]</span>\n</code></pre><p>在IIS的高版本下面可以配置web.Config，在中间添加rewrite节点：</p><pre><code><span class=\"xml\"><span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">rewrite</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">rules</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">rule</span> <span class=\"hljs-attr\">name</span>=<span class=\"hljs-string\">\"OrgPage\"</span> <span class=\"hljs-attr\">stopProcessing</span>=<span class=\"hljs-string\">\"true\"</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">match</span> <span class=\"hljs-attr\">url</span>=<span class=\"hljs-string\">\"^(.*)$\"</span> /&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">conditions</span> <span class=\"hljs-attr\">logicalGrouping</span>=<span class=\"hljs-string\">\"MatchAll\"</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">add</span> <span class=\"hljs-attr\">input</span>=<span class=\"hljs-string\">\"</span></span></span><span class=\"hljs-template-variable\">{HTTP_HOST}</span><span class=\"xml\"><span class=\"hljs-tag\"><span class=\"hljs-string\">\"</span> <span class=\"hljs-attr\">pattern</span>=<span class=\"hljs-string\">\"^(.*)$\"</span> /&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">add</span> <span class=\"hljs-attr\">input</span>=<span class=\"hljs-string\">\"</span></span></span><span class=\"hljs-template-variable\">{REQUEST_FILENAME}</span><span class=\"xml\"><span class=\"hljs-tag\"><span class=\"hljs-string\">\"</span> <span class=\"hljs-attr\">matchType</span>=<span class=\"hljs-string\">\"IsFile\"</span> <span class=\"hljs-attr\">negate</span>=<span class=\"hljs-string\">\"true\"</span> /&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">add</span> <span class=\"hljs-attr\">input</span>=<span class=\"hljs-string\">\"</span></span></span><span class=\"hljs-template-variable\">{REQUEST_FILENAME}</span><span class=\"xml\"><span class=\"hljs-tag\"><span class=\"hljs-string\">\"</span> <span class=\"hljs-attr\">matchType</span>=<span class=\"hljs-string\">\"IsDirectory\"</span> <span class=\"hljs-attr\">negate</span>=<span class=\"hljs-string\">\"true\"</span> /&gt;</span>\n <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">conditions</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;<span class=\"hljs-name\">action</span> <span class=\"hljs-attr\">type</span>=<span class=\"hljs-string\">\"Rewrite\"</span> <span class=\"hljs-attr\">url</span>=<span class=\"hljs-string\">\"index.php/</span></span></span><span class=\"hljs-template-variable\">{R:1}</span><span class=\"xml\"><span class=\"hljs-tag\"><span class=\"hljs-string\">\"</span> /&gt;</span>\n <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">rule</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">rules</span>&gt;</span>\n <span class=\"hljs-tag\">&lt;/<span class=\"hljs-name\">rewrite</span>&gt;</span>\n</span></code></pre><h2 data-line=\"42\" class=\"line\"><a id=\"_Nginx__42\"></a>[ Nginx ]</h2><p>在Nginx低版本中，是不支持PATHINFO的，但是可以通过在Nginx.conf中配置转发规则实现：</p><pre><code>  location / { // …..省略部分代码\n   <span class=\"hljs-keyword\">if</span> (!<span class=\"hljs-_\">-e</span> <span class=\"hljs-variable\">$request_filename</span>) {\n   rewrite  ^(.*)$  /index.php?s=/<span class=\"hljs-variable\">$1</span>  last;\n   <span class=\"hljs-built_in\">break</span>;\n    }\n }\n</code></pre><blockquote class=\"default\"><p>其实内部是转发到了ThinkPHP提供的兼容URL，利用这种方式，可以解决其他不支持PATHINFO的WEB服务器环境。</p></blockquote><p>如果你的应用安装在二级目录，<code>Nginx</code>的伪静态方法设置如下，其中<code>youdomain</code>是所在的目录名称。</p><pre><code><span class=\"hljs-attribute\">location</span> /youdomain/ {\n    <span class=\"hljs-attribute\">if</span> (!-e <span class=\"hljs-variable\">$request_filename</span>){\n        <span class=\"hljs-attribute\">rewrite</span> <span class=\"hljs-regexp\"> ^/youdomain/(.*)$</span>  /youdomain/index.php?s=/<span class=\"hljs-variable\">$1</span>  <span class=\"hljs-literal\">last</span>;\n    }\n}\n</code></pre><p>原来的访问URL：</p><pre><code><span class=\"hljs-link\">http://serverName/index.php/模块/控制器/操作/</span>[<span class=\"hljs-string\">参数名/参数值...</span>]\n</code></pre><p>设置后，我们可以采用下面的方式访问：</p><pre><code><span class=\"hljs-link\">http://serverName/模块/控制器/操作/</span>[<span class=\"hljs-string\">参数名/参数值...</span>]\n</code></pre><p>如果你没有修改服务器的权限，可以在index.php入口文件做修改，这不是正确的做法，并且不一定成功，视服务器而定，只是在框架执行前补全$_SERVER[‘PATH_INFO’]参数</p><pre><code><span class=\"hljs-meta\">$</span><span class=\"bash\">_SERVER[<span class=\"hljs-string\">\'PATH_INFO\'</span>] = <span class=\"hljs-variable\">$_SERVER</span>[<span class=\"hljs-string\">\'REQUEST_URI\'</span> ];</span></code></pre>', '0', '2', '1', '0', '', '0', '0', '866', '1499764536', '1500368732', '《ThinkPHP5.0路由完全指南》', '', '');
INSERT INTO `clt_article` VALUES ('8', '6', '1', 'admin', 'position属性absolute与relative', 'color:rgb(47, 64, 86);font-weight:bold;', '', 'position属性absolute与relative,CLTPHP,CLTPHP内容管理系统,thinkphp,thinkphp内容管理系统', '很多程序猿不清楚absolute与relative怎么区分，怎么用？我们都知道absolute是绝对定位，relative是相对定位，但是这个绝对 与相对是什么意思呢？', '<p>很多朋友问过我absolute与relative怎么区分，怎么用？我们都知道absolute是绝对定位，relative是相对定位，但是这个绝对 与相对是什么意思呢？绝对是什么地方的绝对，相对又是相对于什么地方而言的呢？那他们又有什么样的特性，可以做出什么样的效果呢？关于两者之间又有什么样 的技巧呢？下面我们就来一一解读。<br></p><p></p><p>Absolute，CSS中的写法是：position:absolute; 他的意思是绝对定位，他是参照浏览器的左上角，配合TOP、RIGHT、BOTTOM、LEFT(下面简称TRBL)进行定位，在没有设定TRBL，默认 依据父级的做标原始点为原始点。如果设定TRBL并且父级没有设定position属性，那么当前的absolute则以浏览器左上角为原始点进行定位， 位置将由TRBL决定。</p><p><img src=\"http://www.blueidea.com/articleimg/2006/11/4249/absolute.gif\" alt=\"\"></p><p>一般来讲，网页居中的话用Absolute就容易出错，因为网页一直是随着分辨率的大小自动适应的，而Absolute则会以浏览器的左上角为原始 点，不会应为分辨率的变化而变化位置。很多人出错就在于这点上出错。而网页居左其特性与Relative很相似，但是还是有本质的区别的。</p><p>Relative，CSS中的写法是：position:relative;&nbsp; 他的意思是绝对相对定位，他是参照父级的原始点为原始点，无父级则以BODY的原始点为原始点，配合TRBL进行定位，当父级内有padding等CSS属性时，当前级的原始点则参照父级内容区的原始点进行定位。</p><p><img src=\"http://www.blueidea.com/articleimg/2006/11/4249/relative.gif\" alt=\"\"></p><p>有时我们还需要依靠z-index来设定容器的上下关系，数值越大越在最上面，数值范围是自然数。当然有一点要注意，父子关系是无法用z-index来设定上下关系的，一定是子级在上父级在下。</p><p>二 详解定位与定位应用&nbsp;<a href=\"http://blog.sina.com.cn/u/4bcf4a5e010008o0\">http://blog.sina.com.cn/u/4bcf4a5e010008o0</a></p><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"ke-zeroborder layui-table\"><tbody><tr><td id=\"labeltag\" align=\"center\" valign=\"top\" width=\"60\"></td><td><a href=\"http://search.blog.sina.com.cn/blog/search?q=css&amp;tag=n&amp;t=tag\" target=\"_blank\">css</a>&nbsp;<a href=\"http://search.blog.sina.com.cn/blog/search?q=%BE%F8%B6%D4%B6%A8%CE%BB&amp;tag=n&amp;t=tag\" target=\"_blank\">绝对定位</a>&nbsp;<a href=\"http://search.blog.sina.com.cn/blog/search?q=%CF%E0%B6%D4%B6%A8%CE%BB&amp;tag=n&amp;t=tag\" target=\"_blank\">相对定位</a></td></tr></tbody></table><div>&nbsp;&nbsp;&nbsp; 定位一直是WEB标准应用中的难点，如果理不清楚定位那么可能应实现的效果实现不了，实现了的效果可能会走样。如果理清了定位的原理，那定位会让网页实现的更加完美。</div><div><strong>&nbsp;&nbsp;&nbsp; 定位的定义：</strong><p>在CSS中关于定位的内容是：</p></div><div align=\"center\"><strong>position:relative | absolute | static | fixed</strong></div><div align=\"left\"><strong>&nbsp;&nbsp;&nbsp; static(静态)</strong>&nbsp;没有特别的设定，遵循基本的定位规定，不能通过z-index进行层次分级。<br><strong>&nbsp;&nbsp;&nbsp; relative(相对定位)</strong>&nbsp;对象不可层叠、不脱离文档流，参考自身静态位置通过 top,bottom,left,right 定位，并且可以通过z-index进行层次分级。<br><strong>absolute(绝对定位)</strong>&nbsp;脱离文档流，通过 top,bottom,left,right 定位。选取其最近一个最有定位设置的父级对象进行绝对定位，如果对象的父级没有设置定位属性，absolute元素将以body坐标原点进行定位，可以通过z-index进行层次分级。<br><strong>&nbsp;&nbsp;&nbsp; fixed（固定定位）</strong>&nbsp;这里所固定的参照对像是<strong>可视窗口</strong>而并非是body或是父级元素。可通过z-index进行层次分级。<br><strong>注</strong>：<br>CSS中定位的层叠分级：<strong>z-index: auto | namber;</strong><p><strong>auto</strong>&nbsp;遵从其父对象的定位<br><strong>namber</strong>&nbsp;&nbsp;无单位的整数值。可为负数</p></div><div align=\"left\"><strong>定位的原理：</strong><p>1.可以位移的元素 （相对定位）</p><p>在本文流中，任何一个元素都被文本流所限制了自身的位置，但是通过CSS我们依然使得这些元素可以改变自己的位置，我们可以通过float来让元素浮 动，也可以通过margin来让元素产生位置移动。但事实上那并非是真实的位移，因为，那只是通过加大margin值来实现的障眼法。而真正意义上的位移 是通过top,right,bottom,left（下称TRBL，TRBL可以折分使用。）针对一个相对定位的元素所产生的。我们看下面的图：</p></div><div align=\"left\">我们看图中是一个相对定位的元素</div><pre class=\"prettyprint lang-css\"><span class=\"com\">#first {</span><span class=\"pln\">\nwidth</span><span class=\"pun\">:</span><span class=\"lit\">200px</span><span class=\"pun\">;</span><span class=\"pln\">\nheight</span><span class=\"pun\">:</span><span class=\"pln\"> </span><span class=\"lit\">50px</span><span class=\"pun\">;</span><span class=\"pln\">\nmargin</span><span class=\"pun\">:</span><span class=\"lit\">25px</span><span class=\"pun\">;</span><span class=\"pln\">\nborder</span><span class=\"pun\">:</span><span class=\"lit\">25px</span><span class=\"pln\"> solid </span><span class=\"com\">#333;</span><span class=\"pln\">\npadding</span><span class=\"pun\">:</span><span class=\"lit\">25px</span><span class=\"pun\">;</span><span class=\"pln\">\nposition</span><span class=\"pun\">:</span><span class=\"pln\">relative</span><span class=\"pun\">;</span><span class=\"pln\">\ntop</span><span class=\"pun\">:</span><span class=\"pln\"> </span><span class=\"lit\">50px</span><span class=\"pun\">;</span><span class=\"pln\">\nleft</span><span class=\"pun\">:</span><span class=\"pln\"> </span><span class=\"lit\">50px</span><span class=\"pun\">;</span><span class=\"pln\">\n</span><span class=\"pun\">}</span></pre><p>而下方是一块默认定位的黑色区块<br></p><pre class=\"prettyprint lang-css\"><span class=\"com\">#second {</span><span class=\"pln\">\nwidth</span><span class=\"pun\">:</span><span class=\"lit\">400px</span><span class=\"pun\">;</span><span class=\"pln\">\nheight</span><span class=\"pun\">:</span><span class=\"lit\">75px</span><span class=\"pun\">;</span><span class=\"pln\">\nmargin</span><span class=\"pun\">:</span><span class=\"lit\">0</span><span class=\"pun\">;</span><span class=\"pln\">\nborder</span><span class=\"pun\">:</span><span class=\"lit\">0</span><span class=\"pun\">;</span><span class=\"pln\">\npadding</span><span class=\"pun\">:</span><span class=\"lit\">0</span><span class=\"pun\">;</span><span class=\"pln\">\nbackgroud</span><span class=\"pun\">-</span><span class=\"pln\">color</span><span class=\"pun\">:</span><span class=\"com\">#333;</span><span class=\"pln\">\n</span><span class=\"pun\">}</span></pre><div align=\"left\">我们看到这个处在文本流的区块被上面的相对定位挡住了一部分，这说明：“当元素被设置相对定位或是绝对定位后，将自动产生层叠，他们的层叠级别自然的高于 文本流”。除非设置其z-index值为负值。并且我们发现当相对定位元素进行位移后，表现内容已经脱离了文本流，只是在本文流中还为原来的相对对定位留 下了原有的总宽与总高（内容的高度或是宽度加上 margin\\border\\padding的数值）。这说明在相对定位中，虽然表现区脱离了原来的文本流，但是在文本流中还还有此相对定位的老窩。这点 要特别注意，因为在实际应用中如果相对定位的位移数值过大，那么原有的区域就会形成一块空白。</div><div align=\"left\">&nbsp;&nbsp;&nbsp; 并且我们注意，定位元素的坐标点是在margin值的左上边缘点，即图中的B点。那么所有的位移的计算将以这个点为基础进行元素的推动。</div><p>2.可以在任意一个位置的元素（绝对定位）</p><p>如上所述：相对定位只可以在文本流中进行位置的上下左右的移动，同样存在一定的局限性，虽然他的表现区脱离了文本流，但是在文本流却依然为其保留了一席之 地，这就好比一个打工的人他到了外地，但是在老家依然有一个专属于他的位置，这个位置不随他的移动而改变。但是这样很明显就会空出一块空白来，如果希望文 本流抛弃这个部分就需要用到绝对定位。绝对定位不光脱离了文本流，而且在文本流中也不会给这个绝对定位元素留下专属空位。这就好比是一个工厂里的职位，如 果有一个工人走了自然会要有别的工人来填充这个位置。而移动出去的部分自然也就成为了自由体。绝对定位将可以通过TRBL来设置元素，使之处在任何一个位 置。在父层position属性为默认值时，TRBL的坐标原点以body的坐标原点为起始。</p><div align=\"left\">3.被关联的绝对定位<p>上面说的是单一的绝对定位，而在实际的应用中我们常常会需要用到一种特别的形式。即希望定位元素要有绝对定位的特性，但是又希望绝对定位的坐标原点可以固 定在网页中的某一个点，当这个点被移动时绝对位定元素能保证相对于这个原坐标的相对位置。也就是说需要这个绝对定位要跟着网页移动，而并且是因定在网页的 某一个固定位置。通常当网页是居中形式的时候这种效果就会显得特别的重要。要实现这种效果基本方式就是为这个绝对定位的父级设置为相对定位或是绝对定位。 那么绝对定位的坐标就会以父级为坐标起始点。</p><p>虽然是如此，但是这个坐标原点却并不是父级的坐标原点，这是一个很奇怪的坐标位置。我们看一下模型图示：</p></div><div align=\"left\"><p align=\"left\">我们看到，这个图中父级为黑灰色区块，子级为青色区块。父级是相对定位，子级是绝对定位。子级 设置了顶部位移50个像素，左倾位移50个像素。那么我们看，子级的坐标原点并不是从父级的坐标原点位移50个像素，而是从父级块的padding左上边 缘点为坐标起始点（即A 点）。而父级这里如果要产生位置移动，或是浏览器窗口大小有所变动都不会影响到这个绝对定位元素与父级的相对定位元素之间的位置关系。这个子级也不用调整 数值。</p><p>这是一种很特别并且也是非常实用的应用方式。如果你之前对于定位的控制并不自如的话，相信看完对这里对定位的解释一定可以把定位使用得随心所欲。</p><p>4.总在视线里的元素 （固定定位）</p><p><strong>&nbsp;&nbsp;&nbsp; position:fixed</strong>; 他的含义就是：固定定位。这个固定与绝对定位很像，唯一不同的是绝对定位是被固定在网页中的某一个位置，而固定定位则是固定在浏览器的视框位置。</p></div>', '0', '2', '1', '0', '', '0', '0', '285', '1499764652', '1499916156', '够过瘾——挨踢男的葵花宝典', '', '');
INSERT INTO `clt_article` VALUES ('9', '6', '1', 'admin', 'PHP实现长文章分页', 'color:rgb(57, 61, 73);font-weight:bold;', '', 'PHP实现长文章分页,CLTPHP,CLTPHP内容管理系统,thinkphp,thinkphp内容管理系统', 'cltphp,当文章内容特长时，为了方便阅读和页面展示我们一般将内容分页来显示，如织梦CMS。而一般分页处理是在后台发布文章的时候就将提交的内容生成多个分页后的静态文件。本文我们结合实例来讲解采用PHP动态将长文章内容进行分页处理。', '<h4>如何分页</h4><p>手动分页：一般在编辑内容时加入特殊分页标记，如{pages}，提交后，PHP程序会根据分页符处理分页，生成不同的静态页面。这种分页方法分页准确，但是需要人工手动添加分页符，工作量大。</p><p>自动分页：PHP程序会根据设置好的分页符将内容进行分页，然后生成不同的静态页面。该方法效率高，对处理不同的html代码标签要求高。</p><p>前端JS分页：使用Javascript将长文章内容截取分段，根据请求展示不同的分段内容，达到分页效果。这种方法一次将内容读取，由前端js处理分页，体验好。</p><p>本文实例代码讲解的是采用PHP将长文章内容分页，可以自动和手动分页。至于生成静态html页面不在本文讲解范围内，后面我们会专门讲解生成静态方面的文章介绍。</p><h4>分页类</h4><pre class=\"prettyprint lang-php\"><span class=\"pun\"><span class=\"pln\">php     \n</span><span class=\"com\">/*   \n*  长文章分页类      \n*/</span><span class=\"pln\">   \n    </span><span class=\"kwd\">class</span><span class=\"pln\"> cutpage</span><span class=\"pun\">{</span><span class=\"pln\">     \n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $pagestr</span><span class=\"pun\">;</span><span class=\"pln\">       </span><span class=\"com\">//被切分的内容     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $pagearr</span><span class=\"pun\">;</span><span class=\"pln\">       </span><span class=\"com\">//被切分文字的数组格式     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $sum_word</span><span class=\"pun\">;</span><span class=\"pln\">      </span><span class=\"com\">//总字数(UTF-8格式的中文字符也包括)     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $sum_page</span><span class=\"pun\">;</span><span class=\"pln\">      </span><span class=\"com\">//总页数     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $page_word</span><span class=\"pun\">;</span><span class=\"pln\">     </span><span class=\"com\">//一页多少字     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $cut_tag</span><span class=\"pun\">;</span><span class=\"pln\">       </span><span class=\"com\">//自动分页符     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $cut_custom</span><span class=\"pun\">;</span><span class=\"pln\">    </span><span class=\"com\">//手动分页符     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $ipage</span><span class=\"pun\">;</span><span class=\"pln\">         </span><span class=\"com\">//当前切分的页数，第几页     </span><span class=\"pln\">\n        </span><span class=\"kwd\">private</span><span class=\"pln\"> $url</span><span class=\"pun\">;</span><span class=\"pln\">     \n         \n        </span><span class=\"kwd\">function</span><span class=\"pln\"> __construct</span><span class=\"pun\">(</span><span class=\"pln\">$pagestr</span><span class=\"pun\">,</span><span class=\"pln\">$page_word</span><span class=\"pun\">=</span><span class=\"lit\">1000</span><span class=\"pun\">){</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word </span><span class=\"pun\">=</span><span class=\"pln\"> $page_word</span><span class=\"pun\">;</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_tag </span><span class=\"pun\">=</span><span class=\"pln\"> array</span><span class=\"pun\">(</span><span class=\"str\">\"\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"<p></p>\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"<br>\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"”。\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"。\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\".\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"！\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"……\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\"？\"</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"str\">\",\"</span><span class=\"pun\">);</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_custom </span><span class=\"pun\">=</span><span class=\"pln\"> </span><span class=\"str\">\"{nextpage}\"</span><span class=\"pun\">;</span><span class=\"pln\">     \n            $tmp_page </span><span class=\"pun\">=</span><span class=\"pln\"> intval</span><span class=\"pun\">(</span><span class=\"pln\">trim</span><span class=\"pun\">(</span><span class=\"pln\">$_GET</span><span class=\"pun\">[</span><span class=\"str\">\"ipage\"</span><span class=\"pun\">]));</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">ipage </span><span class=\"pun\">=</span><span class=\"pln\"> $tmp_page</span><span class=\"pun\">&gt;</span><span class=\"lit\">1</span><span class=\"pun\">?</span><span class=\"pln\">$tmp_page</span><span class=\"pun\">:</span><span class=\"lit\">1</span><span class=\"pun\">;</span><span class=\"pln\">  \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr </span><span class=\"pun\">=</span><span class=\"pln\"> $pagestr</span><span class=\"pun\">;</span><span class=\"pln\"> \n        </span><span class=\"pun\">}</span><span class=\"pln\">     \n         \n        </span><span class=\"kwd\">function</span><span class=\"pln\"> cut_str</span><span class=\"pun\">(){</span><span class=\"pln\">     \n            $str_len_word </span><span class=\"pun\">=</span><span class=\"pln\"> strlen</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">);</span><span class=\"pln\">     </span><span class=\"com\">//获取使用strlen得到的字符总数     </span><span class=\"pln\">\n            $i </span><span class=\"pun\">=</span><span class=\"pln\"> </span><span class=\"lit\">0</span><span class=\"pun\">;</span><span class=\"pln\">     \n            </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">$str_len_word</span><span class=\"pun\">&lt;=</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">){</span><span class=\"pln\">   </span><span class=\"com\">//如果总字数小于一页显示字数     </span><span class=\"pln\">\n                $page_arr</span><span class=\"pun\">[</span><span class=\"pln\">$i</span><span class=\"pun\">]</span><span class=\"pln\"> </span><span class=\"pun\">=</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">;</span><span class=\"pln\">     \n            </span><span class=\"pun\">}</span><span class=\"kwd\">else</span><span class=\"pun\">{</span><span class=\"pln\">     \n                </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">strpos</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">,</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_custom</span><span class=\"pun\">)){</span><span class=\"pln\">     \n                    $page_arr </span><span class=\"pun\">=</span><span class=\"pln\"> explode</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_custom</span><span class=\"pun\">,</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">);</span><span class=\"pln\">     \n                </span><span class=\"pun\">}</span><span class=\"kwd\">else</span><span class=\"pun\">{</span><span class=\"pln\">     \n                    $str_first </span><span class=\"pun\">=</span><span class=\"pln\"> substr</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"lit\">0</span><span class=\"pun\">,</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">);</span><span class=\"pln\">   </span><span class=\"com\">//0-page_word个文字    cutStr为func.global中的函数     </span><span class=\"pln\">\n                    </span><span class=\"kwd\">foreach</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_tag </span><span class=\"kwd\">as</span><span class=\"pln\"> $v</span><span class=\"pun\">){</span><span class=\"pln\">     \n                        $cut_start </span><span class=\"pun\">=</span><span class=\"pln\"> strrpos</span><span class=\"pun\">(</span><span class=\"pln\">$str_first</span><span class=\"pun\">,</span><span class=\"pln\"> $v</span><span class=\"pun\">);</span><span class=\"pln\">       </span><span class=\"com\">//逆向查找第一个分页符的位置     </span><span class=\"pln\">\n                        </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">$cut_start</span><span class=\"pun\">){</span><span class=\"pln\">     \n                            $page_arr</span><span class=\"pun\">[</span><span class=\"pln\">$i</span><span class=\"pun\">++]</span><span class=\"pln\"> </span><span class=\"pun\">=</span><span class=\"pln\"> substr</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"lit\">0</span><span class=\"pun\">,</span><span class=\"pln\"> $cut_start</span><span class=\"pun\">).</span><span class=\"pln\">$v</span><span class=\"pun\">;</span><span class=\"pln\">     \n                            $cut_start </span><span class=\"pun\">=</span><span class=\"pln\"> $cut_start </span><span class=\"pun\">+</span><span class=\"pln\"> strlen</span><span class=\"pun\">(</span><span class=\"pln\">$v</span><span class=\"pun\">);</span><span class=\"pln\">     \n                            </span><span class=\"kwd\">break</span><span class=\"pun\">;</span><span class=\"pln\">     \n                        </span><span class=\"pun\">}</span><span class=\"pln\">     \n                    </span><span class=\"pun\">}</span><span class=\"pln\">     \n                    </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">((</span><span class=\"pln\">$cut_start</span><span class=\"pun\">+</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">)&gt;=</span><span class=\"pln\">$str_len_word</span><span class=\"pun\">){</span><span class=\"pln\">  </span><span class=\"com\">//如果超过总字数     </span><span class=\"pln\">\n                        $page_arr</span><span class=\"pun\">[</span><span class=\"pln\">$i</span><span class=\"pun\">++]</span><span class=\"pln\"> </span><span class=\"pun\">=</span><span class=\"pln\"> substr</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">,</span><span class=\"pln\"> $cut_start</span><span class=\"pun\">,</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">);</span><span class=\"pln\">     \n                    </span><span class=\"pun\">}</span><span class=\"kwd\">else</span><span class=\"pun\">{</span><span class=\"pln\">     \n                        </span><span class=\"kwd\">while</span><span class=\"pln\"> </span><span class=\"pun\">((</span><span class=\"pln\">$cut_start</span><span class=\"pun\">+</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">)&lt;</span><span class=\"pln\">$str_len_word</span><span class=\"pun\">){</span><span class=\"pln\">     \n                            </span><span class=\"kwd\">foreach</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_tag </span><span class=\"kwd\">as</span><span class=\"pln\"> $v</span><span class=\"pun\">){</span><span class=\"pln\">     \n                                $str_tmp </span><span class=\"pun\">=</span><span class=\"pln\"> substr</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">,</span><span class=\"pln\"> $cut_start</span><span class=\"pun\">,</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">);</span><span class=\"pln\">        </span><span class=\"com\">//取第cut_start个字后的page_word个字符     </span><span class=\"pln\">\n                                $cut_tmp </span><span class=\"pun\">=</span><span class=\"pln\"> strrpos</span><span class=\"pun\">(</span><span class=\"pln\">$str_tmp</span><span class=\"pun\">,</span><span class=\"pln\"> $v</span><span class=\"pun\">);</span><span class=\"pln\">       </span><span class=\"com\">//找出从第cut_start个字之后，page_word个字之间，逆向查找第一个分页符的位置     </span><span class=\"pln\">\n                                </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">$cut_tmp</span><span class=\"pun\">){</span><span class=\"pln\">     \n                                    $page_arr</span><span class=\"pun\">[</span><span class=\"pln\">$i</span><span class=\"pun\">++]</span><span class=\"pln\"> </span><span class=\"pun\">=</span><span class=\"pln\"> substr</span><span class=\"pun\">(</span><span class=\"pln\">$str_tmp</span><span class=\"pun\">,</span><span class=\"pln\"> </span><span class=\"lit\">0</span><span class=\"pun\">,</span><span class=\"pln\"> $cut_tmp</span><span class=\"pun\">).</span><span class=\"pln\">$v</span><span class=\"pun\">;</span><span class=\"pln\">     \n                                    $cut_start </span><span class=\"pun\">=</span><span class=\"pln\"> $cut_start </span><span class=\"pun\">+</span><span class=\"pln\"> $cut_tmp </span><span class=\"pun\">+</span><span class=\"pln\"> strlen</span><span class=\"pun\">(</span><span class=\"pln\">$v</span><span class=\"pun\">);</span><span class=\"pln\">     \n                                    </span><span class=\"kwd\">break</span><span class=\"pun\">;</span><span class=\"pln\">     \n                                </span><span class=\"pun\">}</span><span class=\"pln\">     \n                            </span><span class=\"pun\">}</span><span class=\"pln\">       \n                        </span><span class=\"pun\">}</span><span class=\"pln\">     \n                        </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">((</span><span class=\"pln\">$cut_start</span><span class=\"pun\">+</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">)&gt;</span><span class=\"pln\">$str_len_word</span><span class=\"pun\">){</span><span class=\"pln\">     \n                            $page_arr</span><span class=\"pun\">[</span><span class=\"pln\">$i</span><span class=\"pun\">++]</span><span class=\"pln\"> </span><span class=\"pun\">=</span><span class=\"pln\"> substr</span><span class=\"pun\">(</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagestr</span><span class=\"pun\">,</span><span class=\"pln\"> $cut_start</span><span class=\"pun\">,</span><span class=\"pln\"> $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">page_word</span><span class=\"pun\">);</span><span class=\"pln\">     \n                        </span><span class=\"pun\">}</span><span class=\"pln\">     \n                    </span><span class=\"pun\">}</span><span class=\"pln\">     \n                </span><span class=\"pun\">}</span><span class=\"pln\">     \n            </span><span class=\"pun\">}</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">sum_page </span><span class=\"pun\">=</span><span class=\"pln\"> count</span><span class=\"pun\">(</span><span class=\"pln\">$page_arr</span><span class=\"pun\">);</span><span class=\"pln\">     </span><span class=\"com\">//总页数     </span><span class=\"pln\">\n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagearr </span><span class=\"pun\">=</span><span class=\"pln\"> $page_arr</span><span class=\"pun\">;</span><span class=\"pln\">   \n            </span><span class=\"kwd\">return</span><span class=\"pln\"> $page_arr</span><span class=\"pun\">;</span><span class=\"pln\"> \n        </span><span class=\"pun\">}</span><span class=\"pln\">     \n        </span><span class=\"com\">//显示上一条，下一条     </span><span class=\"pln\">\n        </span><span class=\"kwd\">function</span><span class=\"pln\"> pagenav</span><span class=\"pun\">(){</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">set_url</span><span class=\"pun\">();</span><span class=\"pln\">     \n            $str </span><span class=\"pun\">=</span><span class=\"pln\"> </span><span class=\"str\">\'\'</span><span class=\"pun\">;</span><span class=\"pln\"> \n             \n            </span><span class=\"com\">//$str .= $this-&gt;ipage.\'/\'.$this-&gt;sum_page; </span><span class=\"pln\">\n             \n            </span><span class=\"kwd\">for</span><span class=\"pun\">(</span><span class=\"pln\">$i</span><span class=\"pun\">=</span><span class=\"lit\">1</span><span class=\"pun\">;</span><span class=\"pln\">$i</span><span class=\"pun\">&lt;=</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">sum_page</span><span class=\"pun\">;</span><span class=\"pln\">$i</span><span class=\"pun\">++){</span><span class=\"pln\"> \n                </span><span class=\"kwd\">if</span><span class=\"pun\">(</span><span class=\"pln\">$i</span><span class=\"pun\">==</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">ipage</span><span class=\"pun\">)</span><span class=\"pln\"> </span><span class=\"pun\">{</span><span class=\"pln\"> \n                    $str</span><span class=\"pun\">.=</span><span class=\"pln\"> </span><span class=\"str\">\"<a href=\"http://cltphp.com/admin/article/edit.html?id=23&amp;catid=50#\" class=\"cur\">\"</a></span><a href=\"http://cltphp.com/admin/article/edit.html?id=23&amp;catid=50#\" class=\"cur\"><span class=\"pun\">.</span><span class=\"pln\">$i</span><span class=\"pun\">.</span><span class=\"str\">\"</span></a> \"</span><span class=\"pun\">;</span><span class=\"pln\"> \n                </span><span class=\"pun\">}</span><span class=\"kwd\">else</span><span class=\"pun\">{</span><span class=\"pln\"> \n                    $str</span><span class=\"pun\">.=</span><span class=\"pln\"> </span><span class=\"str\">\"<a href=\"http://cltphp.com/admin/article/edit.html?id=23&amp;catid=50\" <=\"\" span=\"\"><span class=\"pun\">.</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">url</span><span class=\"pun\">.</span><span class=\"pln\">$i</span><span class=\"pun\">.</span><span class=\"str\">\"\"&gt;\"</span></a></span><a href=\"http://cltphp.com/admin/article/edit.html?id=23&amp;catid=50\" <=\"\" span=\"\"><span class=\"pun\">.</span><span class=\"pln\">$this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">url</span><span class=\"pun\">.</span><span class=\"pln\">$i</span><span class=\"pun\">.</span><span class=\"str\">\"\"&gt;<span class=\"pun\">.</span><span class=\"pln\">$i</span><span class=\"pun\">.</span><span class=\"str\">\"</span></span></a> \"<span class=\"pun\">;</span><span class=\"pln\"> \n                </span><span class=\"pun\">}</span><span class=\"pln\"> \n            </span><span class=\"pun\">}</span><span class=\"pln\"> \n             \n                    \n            </span><span class=\"kwd\">return</span><span class=\"pln\"> $str</span><span class=\"pun\">;</span><span class=\"pln\">     \n        </span><span class=\"pun\">}</span><span class=\"pln\">     \n           \n        </span><span class=\"kwd\">function</span><span class=\"pln\"> set_url</span><span class=\"pun\">(){</span><span class=\"pln\">     \n            parse_str</span><span class=\"pun\">(</span><span class=\"pln\">$_SERVER</span><span class=\"pun\">[</span><span class=\"str\">\"QUERY_STRING\"</span><span class=\"pun\">],</span><span class=\"pln\"> $arr_url</span><span class=\"pun\">);</span><span class=\"pln\">     \n            unset</span><span class=\"pun\">(</span><span class=\"pln\">$arr_url</span><span class=\"pun\">[</span><span class=\"str\">\"ipage\"</span><span class=\"pun\">]);</span><span class=\"pln\">     \n            </span><span class=\"kwd\">if</span><span class=\"pln\"> </span><span class=\"pun\">(</span><span class=\"pln\">empty</span><span class=\"pun\">(</span><span class=\"pln\">$arr_url</span><span class=\"pun\">)){</span><span class=\"pln\">     \n                $str </span><span class=\"pun\">=</span><span class=\"pln\"> </span><span class=\"str\">\"ipage=\"</span><span class=\"pun\">;</span><span class=\"pln\">     \n            </span><span class=\"pun\">}</span><span class=\"kwd\">else</span><span class=\"pun\">{</span><span class=\"pln\">     \n                $str </span><span class=\"pun\">=</span><span class=\"pln\"> http_build_query</span><span class=\"pun\">(</span><span class=\"pln\">$arr_url</span><span class=\"pun\">).</span><span class=\"str\">\"&amp;ipage=\"</span><span class=\"pun\">;</span><span class=\"pln\">     \n            </span><span class=\"pun\">}</span><span class=\"pln\">     \n            $this</span><span class=\"pun\">-&gt;</span><span class=\"pln\">url </span><span class=\"pun\">=</span><span class=\"pln\"> </span><span class=\"str\">\"http://\"</span><span class=\"pun\">.</span><span class=\"pln\">$_SERVER</span><span class=\"pun\">[</span><span class=\"str\">\"HTTP_HOST\"</span><span class=\"pun\">].</span><span class=\"pln\">$_SERVER</span><span class=\"pun\">[</span><span class=\"str\">\"PHP_SELF\"</span><span class=\"pun\">].</span><span class=\"str\">\"?\"</span><span class=\"pun\">.</span><span class=\"pln\">$str</span><span class=\"pun\">;</span><span class=\"pln\">     \n        </span><span class=\"pun\">}</span><span class=\"pln\">     \n    </span><span class=\"pun\">}</span><span class=\"pln\">     \n</span><span class=\"pun\">?&gt;</span><span class=\"pln\"> </span></pre><p>以上cutpage类可以非常好的处理内容分页，能处理不同html标签给分页带来的麻烦。如果内容设置了分页符{nextpage}，则会优先自动将内容按分页符分页。</p><h4>调用分页类</h4><p>我们假设读取了文件text.txt的文章内容，实际项目中应该是表单提交长内容或者读取数据库相关表的内容。然后实例化分页类，然后根据当前页调用对应分页的内容并输出，以及输出分页条。</p><pre class=\"prettyprint lang-php\"><span class=\"pun\"><span class=\"pln\">php \n$content </span><span class=\"pun\">=</span><span class=\"pln\"> file_get_contents</span><span class=\"pun\">(</span><span class=\"str\">\'text.txt\'</span><span class=\"pun\">);</span><span class=\"pln\">     \n    $ipage </span><span class=\"pun\">=</span><span class=\"pln\"> $_GET</span><span class=\"pun\">[</span><span class=\"str\">\"ipage\"</span><span class=\"pun\">]?</span><span class=\"pln\"> intval</span><span class=\"pun\">(</span><span class=\"pln\">$_GET</span><span class=\"pun\">[</span><span class=\"str\">\"ipage\"</span><span class=\"pun\">]):</span><span class=\"lit\">1</span><span class=\"pun\">;</span><span class=\"pln\">     \n    $CP </span><span class=\"pun\">=</span><span class=\"pln\"> </span><span class=\"kwd\">new</span><span class=\"pln\"> cutpage</span><span class=\"pun\">(</span><span class=\"pln\">$content</span><span class=\"pun\">);</span><span class=\"pln\">     \n    $page </span><span class=\"pun\">=</span><span class=\"pln\"> $CP</span><span class=\"pun\">-&gt;</span><span class=\"pln\">cut_str</span><span class=\"pun\">();</span><span class=\"pln\">   \n    echo $page</span><span class=\"pun\">[</span><span class=\"pln\">$ipage</span><span class=\"pun\">-</span><span class=\"lit\">1</span><span class=\"pun\">];</span><span class=\"pln\">    \n    echo $CP</span><span class=\"pun\">-&gt;</span><span class=\"pln\">pagenav</span><span class=\"pun\">();</span><span class=\"pln\"> \n</span><span class=\"pun\">?&gt;</span><span class=\"pln\"> </span></span></pre><p>值得注意的是，使用统一UTF-8的文件编码，会让你的编码工作更加顺畅。</p>', '0', '2', '1', '0', '', '0', '0', '309', '1499764826', '1499916131', '够过瘾——挨踢男的葵花宝典', '', '');
INSERT INTO `clt_article` VALUES ('10', '6', '1', 'admin', 'PHP 汉字转拼音函数', 'color:rgb(0, 150, 136);font-weight:bold;', '', 'PHP 汉字转拼音函数,CLTPHP,CLTPHP内容管理系统,thinkphp,thinkphp内容管理系统', 'PHP 汉字转拼音函数,CLTPHP,CLTPHP内容管理系统,thinkphp,thinkphp内容管理系统', '<p><pre><span>function </span><span>Pinyin</span><span>(</span><span>$_String</span><span>, </span><span>$_Code</span><span>=</span><span>\'UTF8\'</span><span>){ </span><span>//GBK页面可改为gb2312，其他随意填写为UTF8<br></span><span>    </span><span>$_DataKey </span><span>= </span><span>\"a|ai|an|ang|ao|ba|bai|ban|bang|bao|bei|ben|beng|bi|bian|biao|bie|bin|bing|bo|bu|ca|cai|can|cang|cao|ce|ceng|cha\"</span><span>.<br></span><span>        </span><span>\"|chai|chan|chang|chao|che|chen|cheng|chi|chong|chou|chu|chuai|chuan|chuang|chui|chun|chuo|ci|cong|cou|cu|\"</span><span>.<br></span><span>        </span><span>\"cuan|cui|cun|cuo|da|dai|dan|dang|dao|de|deng|di|dian|diao|die|ding|diu|dong|dou|du|duan|dui|dun|duo|e|en|er\"</span><span>.<br></span><span>        </span><span>\"|fa|fan|fang|fei|fen|feng|fo|fou|fu|ga|gai|gan|gang|gao|ge|gei|gen|geng|gong|gou|gu|gua|guai|guan|guang|gui\"</span><span>.<br></span><span>        </span><span>\"|gun|guo|ha|hai|han|hang|hao|he|hei|hen|heng|hong|hou|hu|hua|huai|huan|huang|hui|hun|huo|ji|jia|jian|jiang\"</span><span>.<br></span><span>        </span><span>\"|jiao|jie|jin|jing|jiong|jiu|ju|juan|jue|jun|ka|kai|kan|kang|kao|ke|ken|keng|kong|kou|ku|kua|kuai|kuan|kuang\"</span><span>.<br></span><span>        </span><span>\"|kui|kun|kuo|la|lai|lan|lang|lao|le|lei|leng|li|lia|lian|liang|liao|lie|lin|ling|liu|long|lou|lu|lv|luan|lue\"</span><span>.<br></span><span>        </span><span>\"|lun|luo|ma|mai|man|mang|mao|me|mei|men|meng|mi|mian|miao|mie|min|ming|miu|mo|mou|mu|na|nai|nan|nang|nao|ne\"</span><span>.<br></span><span>        </span><span>\"|nei|nen|neng|ni|nian|niang|niao|nie|nin|ning|niu|nong|nu|nv|nuan|nue|nuo|o|ou|pa|pai|pan|pang|pao|pei|pen\"</span><span>.<br></span><span>        </span><span>\"|peng|pi|pian|piao|pie|pin|ping|po|pu|qi|qia|qian|qiang|qiao|qie|qin|qing|qiong|qiu|qu|quan|que|qun|ran|rang\"</span><span>.<br></span><span>        </span><span>\"|rao|re|ren|reng|ri|rong|rou|ru|ruan|rui|run|ruo|sa|sai|san|sang|sao|se|sen|seng|sha|shai|shan|shang|shao|\"</span><span>.<br></span><span>        </span><span>\"she|shen|sheng|shi|shou|shu|shua|shuai|shuan|shuang|shui|shun|shuo|si|song|sou|su|suan|sui|sun|suo|ta|tai|\"</span><span>.<br></span><span>        </span><span>\"tan|tang|tao|te|teng|ti|tian|tiao|tie|ting|tong|tou|tu|tuan|tui|tun|tuo|wa|wai|wan|wang|wei|wen|weng|wo|wu\"</span><span>.<br></span><span>        </span><span>\"|xi|xia|xian|xiang|xiao|xie|xin|xing|xiong|xiu|xu|xuan|xue|xun|ya|yan|yang|yao|ye|yi|yin|ying|yo|yong|you\"</span><span>.<br></span><span>        </span><span>\"|yu|yuan|yue|yun|za|zai|zan|zang|zao|ze|zei|zen|zeng|zha|zhai|zhan|zhang|zhao|zhe|zhen|zheng|zhi|zhong|\"</span><span>.<br></span><span>        </span><span>\"zhou|zhu|zhua|zhuai|zhuan|zhuang|zhui|zhun|zhuo|zi|zong|zou|zu|zuan|zui|zun|zuo\"</span><span>;<br></span><span>    </span><span>$_DataValue </span><span>= </span><span>\"-20319|-20317|-20304|-20295|-20292|-20283|-20265|-20257|-20242|-20230|-20051|-20036|-20032|-20026|-20002|-19990\"</span><span>.<br></span><span>        </span><span>\"|-19986|-19982|-19976|-19805|-19784|-19775|-19774|-19763|-19756|-19751|-19746|-19741|-19739|-19728|-19725\"</span><span>.<br></span><span>        </span><span>\"|-19715|-19540|-19531|-19525|-19515|-19500|-19484|-19479|-19467|-19289|-19288|-19281|-19275|-19270|-19263\"</span><span>.<br></span><span>        </span><span>\"|-19261|-19249|-19243|-19242|-19238|-19235|-19227|-19224|-19218|-19212|-19038|-19023|-19018|-19006|-19003\"</span><span>.<br></span><span>        </span><span>\"|-18996|-18977|-18961|-18952|-18783|-18774|-18773|-18763|-18756|-18741|-18735|-18731|-18722|-18710|-18697\"</span><span>.<br></span><span>        </span><span>\"|-18696|-18526|-18518|-18501|-18490|-18478|-18463|-18448|-18447|-18446|-18239|-18237|-18231|-18220|-18211\"</span><span>.<br></span><span>        </span><span>\"|-18201|-18184|-18183|-18181|-18012|-17997|-17988|-17970|-17964|-17961|-17950|-17947|-17931|-17928|-17922\"</span><span>.<br></span><span>        </span><span>\"|-17759|-17752|-17733|-17730|-17721|-17703|-17701|-17697|-17692|-17683|-17676|-17496|-17487|-17482|-17468\"</span><span>.<br></span><span>        </span><span>\"|-17454|-17433|-17427|-17417|-17202|-17185|-16983|-16970|-16942|-16915|-16733|-16708|-16706|-16689|-16664\"</span><span>.<br></span><span>        </span><span>\"|-16657|-16647|-16474|-16470|-16465|-16459|-16452|-16448|-16433|-16429|-16427|-16423|-16419|-16412|-16407\"</span><span>.<br></span><span>        </span><span>\"|-16403|-16401|-16393|-16220|-16216|-16212|-16205|-16202|-16187|-16180|-16171|-16169|-16158|-16155|-15959\"</span><span>.<br></span><span>        </span><span>\"|-15958|-15944|-15933|-15920|-15915|-15903|-15889|-15878|-15707|-15701|-15681|-15667|-15661|-15659|-15652\"</span><span>.<br></span><span>        </span><span>\"|-15640|-15631|-15625|-15454|-15448|-15436|-15435|-15419|-15416|-15408|-15394|-15385|-15377|-15375|-15369\"</span><span>.<br></span><span>        </span><span>\"|-15363|-15362|-15183|-15180|-15165|-15158|-15153|-15150|-15149|-15144|-15143|-15141|-15140|-15139|-15128\"</span><span>.<br></span><span>        </span><span>\"|-15121|-15119|-15117|-15110|-15109|-14941|-14937|-14933|-14930|-14929|-14928|-14926|-14922|-14921|-14914\"</span><span>.<br></span><span>        </span><span>\"|-14908|-14902|-14894|-14889|-14882|-14873|-14871|-14857|-14678|-14674|-14670|-14668|-14663|-14654|-14645\"</span><span>.<br></span><span>        </span><span>\"|-14630|-14594|-14429|-14407|-14399|-14384|-14379|-14368|-14355|-14353|-14345|-14170|-14159|-14151|-14149\"</span><span>.<br></span><span>        </span><span>\"|-14145|-14140|-14137|-14135|-14125|-14123|-14122|-14112|-14109|-14099|-14097|-14094|-14092|-14090|-14087\"</span><span>.<br></span><span>        </span><span>\"|-14083|-13917|-13914|-13910|-13907|-13906|-13905|-13896|-13894|-13878|-13870|-13859|-13847|-13831|-13658\"</span><span>.<br></span><span>        </span><span>\"|-13611|-13601|-13406|-13404|-13400|-13398|-13395|-13391|-13387|-13383|-13367|-13359|-13356|-13343|-13340\"</span><span>.<br></span><span>        </span><span>\"|-13329|-13326|-13318|-13147|-13138|-13120|-13107|-13096|-13095|-13091|-13076|-13068|-13063|-13060|-12888\"</span><span>.<br></span><span>        </span><span>\"|-12875|-12871|-12860|-12858|-12852|-12849|-12838|-12831|-12829|-12812|-12802|-12607|-12597|-12594|-12585\"</span><span>.<br></span><span>        </span><span>\"|-12556|-12359|-12346|-12320|-12300|-12120|-12099|-12089|-12074|-12067|-12058|-12039|-11867|-11861|-11847\"</span><span>.<br></span><span>        </span><span>\"|-11831|-11798|-11781|-11604|-11589|-11536|-11358|-11340|-11339|-11324|-11303|-11097|-11077|-11067|-11055\"</span><span>.<br></span><span>        </span><span>\"|-11052|-11045|-11041|-11038|-11024|-11020|-11019|-11018|-11014|-10838|-10832|-10815|-10800|-10790|-10780\"</span><span>.<br></span><span>        </span><span>\"|-10764|-10587|-10544|-10533|-10519|-10331|-10329|-10328|-10322|-10315|-10309|-10307|-10296|-10281|-10274\"</span><span>.<br></span><span>        </span><span>\"|-10270|-10262|-10260|-10256|-10254\"</span><span>;<br></span><span>    </span><span>$_TDataKey </span><span>= explode(</span><span>\'|\'</span><span>, </span><span>$_DataKey</span><span>)</span><span>;<br></span><span>    </span><span>$_TDataValue </span><span>= explode(</span><span>\'|\'</span><span>, </span><span>$_DataValue</span><span>)</span><span>;<br></span><span>    </span><span>$_Data </span><span>= array_combine(</span><span>$_TDataKey</span><span>, </span><span>$_TDataValue</span><span>)</span><span>;<br></span><span>    </span><span>arsort(</span><span>$_Data</span><span>)</span><span>;<br></span><span>    </span><span>reset(</span><span>$_Data</span><span>)</span><span>;<br></span><span>    </span><span>if</span><span>(</span><span>$_Code</span><span>!= </span><span>\'gb2312\'</span><span>) </span><span>$_String </span><span>= _U2_Utf8_Gb(</span><span>$_String</span><span>)</span><span>;<br></span><span>    </span><span>$_Res </span><span>= </span><span>\'\'</span><span>;<br></span><span>    </span><span>for</span><span>(</span><span>$i</span><span>=</span><span>0</span><span>; </span><span>$i$_P </span><span>= ord(substr(</span><span>$_String</span><span>, </span><span>$i</span><span>, </span><span>1</span><span>))</span><span>;<br></span><span>    </span><span>if</span><span>(</span><span>$_P</span><span>&gt;</span><span>160</span><span>) {<br></span><span>        </span><span>$_Q </span><span>= ord(substr(</span><span>$_String</span><span>, </span><span>++</span><span>$i</span><span>, </span><span>1</span><span>))</span><span>; </span><span>$_P </span><span>= </span><span>$_P</span><span>*</span><span>256 </span><span>+ </span><span>$_Q </span><span>- </span><span>65536</span><span>;<br></span><span>    </span><span>}<br></span><span>    </span><span>$_Res </span><span>.= _Pinyin(</span><span>$_P</span><span>, </span><span>$_Data</span><span>)</span><span>;<br></span><span>}<br></span><span>return </span><span>preg_replace(</span><span>\"/[^a-z0-9]*/\"</span><span>, </span><span>\'\'</span><span>, </span><span>$_Res</span><span>)</span><span>;<br></span><span>}<br></span><span>function </span><span>_Pinyin</span><span>(</span><span>$_Num</span><span>, </span><span>$_Data</span><span>){<br></span><span>    </span><span>if</span><span>(</span><span>$_Num</span><span>&gt;</span><span>0 </span><span>&amp;&amp; </span><span>$_Num</span><span>&lt;</span><span>160 </span><span>){<br></span><span>        </span><span>return </span><span>chr(</span><span>$_Num</span><span>)</span><span>;<br></span><span>    </span><span>}</span><span>elseif</span><span>(</span><span>$_Num</span><span>&lt;-</span><span>20319 </span><span>|| </span><span>$_Num</span><span>&gt;-</span><span>10247</span><span>){<br></span><span>        </span><span>return </span><span>\'\'</span><span>;<br></span><span>    </span><span>}</span><span>else</span><span>{<br></span><span>        </span><span>foreach</span><span>(</span><span>$_Data </span><span>as </span><span>$k</span><span>=&gt;</span><span>$v</span><span>){ </span><span>if</span><span>(</span><span>$v</span><span>&lt;=</span><span>$_Num</span><span>) </span><span>break</span><span>; </span><span>}<br></span><span>        </span><span>return </span><span>$k</span><span>;<br></span><span>    </span><span>}<br></span><span>}<br></span><span>function </span><span>_U2_Utf8_Gb</span><span>(</span><span>$_C</span><span>){<br></span><span>    </span><span>$_String </span><span>= </span><span>\'\'</span><span>;<br></span><span>    </span><span>if</span><span>(</span><span>$_C </span><span>&lt; </span><span>0x80</span><span>){<br></span><span>        </span><span>$_String </span><span>.= </span><span>$_C</span><span>;<br></span><span>    </span><span>}</span><span>elseif</span><span>(</span><span>$_C </span><span>&lt; </span><span>0x800</span><span>) {<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0xC0 </span><span>| </span><span>$_C</span><span>&gt;&gt;</span><span>6</span><span>)</span><span>;<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0x80 </span><span>| </span><span>$_C </span><span>&amp; </span><span>0x3F</span><span>)</span><span>;<br></span><span>    </span><span>}</span><span>elseif</span><span>(</span><span>$_C </span><span>&lt; </span><span>0x10000</span><span>){<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0xE0 </span><span>| </span><span>$_C</span><span>&gt;&gt;</span><span>12</span><span>)</span><span>;<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0x80 </span><span>| </span><span>$_C</span><span>&gt;&gt;</span><span>6 </span><span>&amp; </span><span>0x3F</span><span>)</span><span>;<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0x80 </span><span>| </span><span>$_C </span><span>&amp; </span><span>0x3F</span><span>)</span><span>;<br></span><span>    </span><span>}</span><span>elseif</span><span>(</span><span>$_C </span><span>&lt; </span><span>0x200000</span><span>) {<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0xF0 </span><span>| </span><span>$_C</span><span>&gt;&gt;</span><span>18</span><span>)</span><span>;<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0x80 </span><span>| </span><span>$_C</span><span>&gt;&gt;</span><span>12 </span><span>&amp; </span><span>0x3F</span><span>)</span><span>;<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0x80 </span><span>| </span><span>$_C</span><span>&gt;&gt;</span><span>6 </span><span>&amp; </span><span>0x3F</span><span>)</span><span>;<br></span><span>        </span><span>$_String </span><span>.= chr(</span><span>0x80 </span><span>| </span><span>$_C </span><span>&amp; </span><span>0x3F</span><span>)</span><span>;<br></span><span>    </span><span>}<br></span><span>    </span><span>return </span><span>iconv(</span><span>\'UTF-8\'</span><span>, </span><span>\'GB2312\'</span><span>, </span><span>$_String</span><span>)</span><span>;<br></span><span>}<br></span><span><br></span><span><br></span><span>//echo Pinyin(\'汉字\');<br></span><span>//测试<br></span><span>echo </span><span>Pinyin(</span><span>\'中文字\'</span><span>,</span><span>\'gb2312\'</span><span>)</span><span>; </span><span>//第二个参数“1”可随意设置即为utf8编码</span></pre></p><p><strlen($_string); $i++)=\"\" { <br=\"\"></strlen($_string);></p>', '0', '2', '1', '0', '1,2,3,4', '0', '0', '740', '1499828506', '1501139662', '博客园', '', '');
INSERT INTO `clt_article` VALUES ('11', '5', '1', 'admin', 'CLTPHP4.3版本更新', 'color:rgb(255, 87, 34);font-weight:bold;', '', 'CLTPHP4.3版本更新,CLTPHP,CLTPHP内容管理系统', 'CLTPHP4.3版本更新,CLTPHP,CLTPHP内容管理系统', '<p>更新内容</p><p>1.后台模型建立重构</p><p>2.新增文件上传</p><p>3.更改标题样式和缩略图数据库存放方式</p><p>4.后台文章栏目标题样式添加</p><p>5.修改部分bug，删减了系统冗余内容</p><p><strong><em>注意：本次修改重构了模型，4.2及以前版本不可直接覆盖代码</em></strong></p><p>推荐环境：apache2.4+php5.5(以上)+mysql5.0(以上)</p><p>开发环境：phpStudy 2016 &nbsp;php5.5.38</p>', '0', '0', '1', '0', '', '0', '0', '806', '1499828638', '1505264287', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('12', '5', '1', 'admin', 'CLTPHP手册栏目管理更新，CLTPHP核心价值，尽在其中！', 'color:rgb(255, 87, 34);font-weight:bold;', '', 'CLTPHP手册栏目管理更新，CLTPHP核心价值，尽在其中！', 'CLTPHP手册栏目管理更新，CLTPHP核心价值，尽在其中！', '<p><a target=\"_self\" href=\"http://www.cltphp.com/\">CLTPHP</a>手册栏目管理更新，CLTPHP核心价值，尽在其中。</p><p>喜欢的朋友可以购买参考</p><p>同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p>手册地址：https://www.kancloud.cn/chichu/cltphp/</p>', '0', '2', '1', '0', '', '0', '0', '759', '1500014331', '1501031503', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('13', '6', '1', 'admin', 'PHP获取客户端浏览器类型以及版本号', 'color:rgb(30, 159, 255);font-weight:bold;', '', 'PHP获取客户端浏览器类型以及版本号', 'PHP获取客户端浏览器类型以及版本号', '<article class=\"post-item clearfix\"><section class=\"post-entry\"><pre class=\"prettyprint lang-php\"><div class=\"line number1 index0 alt2\"><code class=\"php comments\">/**</code></div><div class=\"line number2 index1 alt1\"><code class=\"php spaces\">&nbsp;</code><code class=\"php comments\">*&nbsp;获取客户端浏览器类型</code></div><div class=\"line number3 index2 alt2\"><code class=\"php spaces\">&nbsp;</code><code class=\"php comments\">*&nbsp;@param&nbsp;&nbsp;string&nbsp;$glue&nbsp;浏览器类型和版本号之间的连接符</code></div><div class=\"line number4 index3 alt1\"><code class=\"php spaces\">&nbsp;</code><code class=\"php comments\">*&nbsp;@return&nbsp;string|array&nbsp;传递连接符则连接浏览器类型和版本号返回字符串否则直接返回数组&nbsp;false为未知浏览器类型</code></div><div class=\"line number5 index4 alt2\"><code class=\"php spaces\">&nbsp;</code><code class=\"php comments\">*/</code></div><div class=\"line number6 index5 alt1\"><code class=\"php spaces\">&nbsp;</code><code class=\"php keyword\">function</code>&nbsp;<code class=\"php plain\">get_client_browser(</code><code class=\"php variable\">$glue</code>&nbsp;<code class=\"php plain\">=&nbsp;null)&nbsp;{</code></div><div class=\"line number7 index6 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php variable\">$browser</code>&nbsp;<code class=\"php plain\">=&nbsp;</code><code class=\"php keyword\">array</code><code class=\"php plain\">();</code></div><div class=\"line number8 index7 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php variable\">$agent</code>&nbsp;<code class=\"php plain\">=&nbsp;</code><code class=\"php variable\">$_SERVER</code><code class=\"php plain\">[</code><code class=\"php string\">\'HTTP_USER_AGENT\'</code><code class=\"php plain\">];&nbsp;</code><code class=\"php comments\">//获取客户端信息</code></div><div class=\"line number9 index8 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php comments\">/*&nbsp;定义浏览器特性正则表达式&nbsp;*/</code></div><div class=\"line number10 index9 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php variable\">$regex</code>&nbsp;<code class=\"php plain\">=&nbsp;</code><code class=\"php keyword\">array</code><code class=\"php plain\">(</code></div><div class=\"line number11 index10 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php string\">\'ie\'</code>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<code class=\"php plain\">=&gt;&nbsp;</code><code class=\"php string\">\'/(MSIE)&nbsp;(\\d+\\.\\d)/\'</code><code class=\"php plain\">,</code></div><div class=\"line number12 index11 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php string\">\'chrome\'</code>&nbsp;&nbsp;<code class=\"php plain\">=&gt;&nbsp;</code><code class=\"php string\">\'/(Chrome)\\/(\\d+\\.\\d+)/\'</code><code class=\"php plain\">,</code></div><div class=\"line number13 index12 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php string\">\'firefox\'</code>&nbsp;<code class=\"php plain\">=&gt;&nbsp;</code><code class=\"php string\">\'/(Firefox)\\/(\\d+\\.\\d+)/\'</code><code class=\"php plain\">,</code></div><div class=\"line number14 index13 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php string\">\'opera\'</code>&nbsp;&nbsp;&nbsp;<code class=\"php plain\">=&gt;&nbsp;</code><code class=\"php string\">\'/(Opera)\\/(\\d+\\.\\d+)/\'</code><code class=\"php plain\">,</code></div><div class=\"line number15 index14 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php string\">\'safari\'</code>&nbsp;&nbsp;<code class=\"php plain\">=&gt;&nbsp;</code><code class=\"php string\">\'/Version\\/(\\d+\\.\\d+\\.\\d)&nbsp;(Safari)/\'</code><code class=\"php plain\">,</code></div><div class=\"line number16 index15 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php plain\">);</code></div><div class=\"line number17 index16 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php keyword\">foreach</code><code class=\"php plain\">(</code><code class=\"php variable\">$regex</code>&nbsp;<code class=\"php keyword\">as</code>&nbsp;<code class=\"php variable\">$type</code>&nbsp;<code class=\"php plain\">=&gt;&nbsp;</code><code class=\"php variable\">$reg</code><code class=\"php plain\">)&nbsp;{</code></div><div class=\"line number18 index17 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php plain\">preg_match(</code><code class=\"php variable\">$reg</code><code class=\"php plain\">,&nbsp;</code><code class=\"php variable\">$agent</code><code class=\"php plain\">,&nbsp;</code><code class=\"php variable\">$data</code><code class=\"php plain\">);</code></div><div class=\"line number19 index18 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php keyword\">if</code><code class=\"php plain\">(!</code><code class=\"php functions\">empty</code><code class=\"php plain\">(</code><code class=\"php variable\">$data</code><code class=\"php plain\">)&nbsp;&amp;&amp;&nbsp;</code><code class=\"php functions\">is_array</code><code class=\"php plain\">(</code><code class=\"php variable\">$data</code><code class=\"php plain\">)){</code></div><div class=\"line number20 index19 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php variable\">$browser</code>&nbsp;<code class=\"php plain\">=&nbsp;</code><code class=\"php variable\">$type</code>&nbsp;<code class=\"php plain\">===&nbsp;</code><code class=\"php string\">\'safari\'</code>&nbsp;<code class=\"php plain\">?&nbsp;</code><code class=\"php keyword\">array</code><code class=\"php plain\">(</code><code class=\"php variable\">$data</code><code class=\"php plain\">[2],&nbsp;</code><code class=\"php variable\">$data</code><code class=\"php plain\">[1])&nbsp;:&nbsp;</code><code class=\"php keyword\">array</code><code class=\"php plain\">(</code><code class=\"php variable\">$data</code><code class=\"php plain\">[1],&nbsp;</code><code class=\"php variable\">$data</code><code class=\"php plain\">[2]);</code></div><div class=\"line number21 index20 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php keyword\">break</code><code class=\"php plain\">;</code></div><div class=\"line number22 index21 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php plain\">}</code></div><div class=\"line number23 index22 alt2\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php plain\">}</code></div><div class=\"line number24 index23 alt1\"><code class=\"php spaces\">&nbsp;&nbsp;&nbsp;&nbsp;</code><code class=\"php keyword\">return</code>&nbsp;<code class=\"php functions\">empty</code><code class=\"php plain\">(</code><code class=\"php variable\">$browser</code><code class=\"php plain\">)&nbsp;?&nbsp;false&nbsp;:&nbsp;(</code><code class=\"php functions\">is_null</code><code class=\"php plain\">(</code><code class=\"php variable\">$glue</code><code class=\"php plain\">)&nbsp;?&nbsp;</code><code class=\"php variable\">$browser</code>&nbsp;<code class=\"php plain\">:&nbsp;implode(</code><code class=\"php variable\">$glue</code><code class=\"php plain\">,&nbsp;</code><code class=\"php variable\">$browser</code><code class=\"php plain\">));</code></div><div class=\"line number25 index24 alt2\"><code class=\"php spaces\">&nbsp;</code><code class=\"php plain\">}</code></div></pre><p><br></p><p></p></section></article>', '0', '2', '1', '0', '', '0', '0', '283', '1500432973', '1501031353', 'PHP博客', '', '');
INSERT INTO `clt_article` VALUES ('14', '6', '1', 'admin', 'CLTPHP产生随机字符串', 'color:;font-weight:normal;', '', 'CLTPHP产生随机字符串', 'CLTPHP产生随机字符串', '<p>CLTPHP产生随机字符串</p><pre><span>/**<br></span><span>+----------------------------------------------------------<br></span><span> * 产生随机字串，可用来自动生成密码 默认长度6位 字母和数字混合<br></span><span>+----------------------------------------------------------<br></span><span> * </span><span>@param </span><span>string $len 长度<br></span><span> * </span><span>@param </span><span>string $type 字串类型<br></span><span> * 0 字母 1 数字 其它 混合<br></span><span> * </span><span>@param </span><span>string $addChars 额外字符<br></span><span>+----------------------------------------------------------<br></span><span> * </span><span>@return </span><span>string<br></span><span>+----------------------------------------------------------<br></span><span> */<br></span><span>function </span><span>rand_string</span><span>(</span><span>$len</span><span>=</span><span>6</span><span>,</span><span>$type</span><span>=</span><span>\'\'</span><span>,</span><span>$addChars</span><span>=</span><span>\'\'</span><span>) {<br></span><span>    </span><span>$str </span><span>=</span><span>\'\'</span><span>;<br></span><span>    </span><span>switch</span><span>(</span><span>$type</span><span>) {<br></span><span>        </span><span>case </span><span>0</span><span>:<br></span><span>            </span><span>$chars</span><span>=</span><span>\'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz\'</span><span>.</span><span>$addChars</span><span>;<br></span><span>            </span><span>break</span><span>;<br></span><span>        </span><span>case </span><span>1</span><span>:<br></span><span>            </span><span>$chars</span><span>= str_repeat(</span><span>\'0123456789\'</span><span>,</span><span>3</span><span>)</span><span>;<br></span><span>            </span><span>break</span><span>;<br></span><span>        </span><span>case </span><span>2</span><span>:<br></span><span>            </span><span>$chars</span><span>=</span><span>\'ABCDEFGHIJKLMNOPQRSTUVWXYZ\'</span><span>.</span><span>$addChars</span><span>;<br></span><span>            </span><span>break</span><span>;<br></span><span>        </span><span>case </span><span>3</span><span>:<br></span><span>            </span><span>$chars</span><span>=</span><span>\'abcdefghijklmnopqrstuvwxyz\'</span><span>.</span><span>$addChars</span><span>;<br></span><span>            </span><span>break</span><span>;<br></span><span>        </span><span>case </span><span>4</span><span>:<br></span><span>            </span><span>$chars </span><span>= </span><span>\"们以我到他会作时要动国产的一是工就年阶义发成部民可出能方进在了不和有大这主中人上为来分生对于学下级地个用同行面说种过命度革而多子后自社加小机也经力线本电高量长党得实家定深法表着水理化争现所二起政三好十战无农使性前等反体合斗路图把结第里正新开论之物从当两些还天资事队批点育重其思与间内去因件日利相由压员气业代全组数果期导平各基或月毛然如应形想制心样干都向变关问比展那它最及外没看治提五解系林者米群头意只明四道马认次文通但条较克又公孔领军流入接席位情运器并飞原油放立题质指建区验活众很教决特此常石强极土少已根共直团统式转别造切九你取西持总料连任志观调七么山程百报更见必真保热委手改管处己将修支识病象几先老光专什六型具示复安带每东增则完风回南广劳轮科北打积车计给节做务被整联步类集号列温装即毫知轴研单色坚据速防史拉世设达尔场织历花受求传口断况采精金界品判参层止边清至万确究书术状厂须离再目海交权且儿青才证低越际八试规斯近注办布门铁需走议县兵固除般引齿千胜细影济白格效置推空配刀叶率述今选养德话查差半敌始片施响收华觉备名红续均药标记难存测士身紧液派准斤角降维板许破述技消底床田势端感往神便贺村构照容非搞亚磨族火段算适讲按值美态黄易彪服早班麦削信排台声该击素张密害侯草何树肥继右属市严径螺检左页抗苏显苦英快称坏移约巴材省黑武培著河帝仅针怎植京助升王眼她抓含苗副杂普谈围食射源例致酸旧却充足短划剂宣环落首尺波承粉践府鱼随考刻靠够满夫失包住促枝局菌杆周护岩师举曲春元超负砂封换太模贫减阳扬江析亩木言球朝医校古呢稻宋听唯输滑站另卫字鼓刚写刘微略范供阿块某功套友限项余倒卷创律雨让骨远帮初皮播优占死毒圈伟季训控激找叫云互跟裂粮粒母练塞钢顶策双留误础吸阻故寸盾晚丝女散焊功株亲院冷彻弹错散商视艺灭版烈零室轻血倍缺厘泵察绝富城冲喷壤简否柱李望盘磁雄似困巩益洲脱投送奴侧润盖挥距触星松送获兴独官混纪依未突架宽冬章湿偏纹吃执阀矿寨责熟稳夺硬价努翻奇甲预职评读背协损棉侵灰虽矛厚罗泥辟告卵箱掌氧恩爱停曾溶营终纲孟钱待尽俄缩沙退陈讨奋械载胞幼哪剥迫旋征槽倒握担仍呀鲜吧卡粗介钻逐弱脚怕盐末阴丰雾冠丙街莱贝辐肠付吉渗瑞惊顿挤秒悬姆烂森糖圣凹陶词迟蚕亿矩康遵牧遭幅园腔订香肉弟屋敏恢忘编印蜂急拿扩伤飞露核缘游振操央伍域甚迅辉异序免纸夜乡久隶缸夹念兰映沟乙吗儒杀汽磷艰晶插埃燃欢铁补咱芽永瓦倾阵碳演威附牙芽永瓦斜灌欧献顺猪洋腐请透司危括脉宜笑若尾束壮暴企菜穗楚汉愈绿拖牛份染既秋遍锻玉夏疗尖殖井费州访吹荣铜沿替滚客召旱悟刺脑措贯藏敢令隙炉壳硫煤迎铸粘探临薄旬善福纵择礼愿伏残雷延烟句纯渐耕跑泽慢栽鲁赤繁境潮横掉锥希池败船假亮谓托伙哲怀割摆贡呈劲财仪沉炼麻罪祖息车穿货销齐鼠抽画饲龙库守筑房歌寒喜哥洗蚀废纳腹乎录镜妇恶脂庄擦险赞钟摇典柄辩竹谷卖乱虚桥奥伯赶垂途额壁网截野遗静谋弄挂课镇妄盛耐援扎虑键归符庆聚绕摩忙舞遇索顾胶羊湖钉仁音迹碎伸灯避泛亡答勇频皇柳哈揭甘诺概宪浓岛袭谁洪谢炮浇斑讯懂灵蛋闭孩释乳巨徒私银伊景坦累匀霉杜乐勒隔弯绩招绍胡呼痛峰零柴簧午跳居尚丁秦稍追梁折耗碱殊岗挖氏刃剧堆赫荷胸衡勤膜篇登驻案刊秧缓凸役剪川雪链渔啦脸户洛孢勃盟买杨宗焦赛旗滤硅炭股坐蒸凝竟陷枪黎救冒暗洞犯筒您宋弧爆谬涂味津臂障褐陆啊健尊豆拔莫抵桑坡缝警挑污冰柬嘴啥饭塑寄赵喊垫丹渡耳刨虎笔稀昆浪萨茶滴浅拥穴覆伦娘吨浸袖珠雌妈紫戏塔锤震岁貌洁剖牢锋疑霸闪埔猛诉刷狠忽灾闹乔唐漏闻沈熔氯荒茎男凡抢像浆旁玻亦忠唱蒙予纷捕锁尤乘乌智淡允叛畜俘摸锈扫毕璃宝芯爷鉴秘净蒋钙肩腾枯抛轨堂拌爸循诱祝励肯酒绳穷塘燥泡袋朗喂铝软渠颗惯贸粪综墙趋彼届墨碍启逆卸航衣孙龄岭骗休借\"</span><span>.</span><span>$addChars</span><span>;<br></span><span>            </span><span>break</span><span>;<br></span><span>        </span><span>default </span><span>:<br></span><span>            </span><span>// 默认去掉了容易混淆的字符oOLl和数字01，要添加请使用addChars参数<br></span><span>            </span><span>$chars</span><span>=</span><span>\'ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789\'</span><span>.</span><span>$addChars</span><span>;<br></span><span>            </span><span>break</span><span>;<br></span><span>    </span><span>}<br></span><span>    </span><span>if</span><span>(</span><span>$len</span><span>&gt;</span><span>10 </span><span>) {</span><span>//位数过长重复字符串一定次数<br></span><span>        </span><span>$chars</span><span>= </span><span>$type</span><span>==</span><span>1</span><span>? str_repeat(</span><span>$chars</span><span>,</span><span>$len</span><span>) : str_repeat(</span><span>$chars</span><span>,</span><span>5</span><span>)</span><span>;<br></span><span>    </span><span>}<br></span><span>    </span><span>if</span><span>(</span><span>$type</span><span>!=</span><span>4</span><span>) {<br></span><span>        </span><span>$chars   </span><span>=   str_shuffle(</span><span>$chars</span><span>)</span><span>;<br></span><span>        </span><span>$str     </span><span>=   substr(</span><span>$chars</span><span>,</span><span>0</span><span>,</span><span>$len</span><span>)</span><span>;<br></span><span>    </span><span>}</span><span>else</span><span>{<br></span><span>        </span><span>// 中文随机字<br></span><span>        </span><span>for</span><span>(</span><span>$i</span><span>=</span><span>0</span><span>;</span><span>$i</span><span>&lt;</span><span>$len</span><span>;</span><span>$i</span><span>++){<br></span><span>            </span><span>$str</span><span>.= msubstr(</span><span>$chars</span><span>, </span><span>floor(mt_rand(</span><span>0</span><span>,</span><span>mb_strlen(</span><span>$chars</span><span>,</span><span>\'utf-8\'</span><span>)-</span><span>1</span><span>))</span><span>,</span><span>1</span><span>)</span><span>;<br></span><span>        </span><span>}<br></span><span>    }<br></span><span>    </span><span>return </span><span>$str</span><span>;<br></span><span>}</span></pre><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"syntaxhighlighter  php layui-table\"><tbody><tr><td class=\"gutter\"><br></td><td class=\"code\"><br></td></tr></tbody></table>', '0', '2', '1', '0', '', '0', '0', '428', '1500867996', '1501204238', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('15', '6', '1', 'admin', 'CLTPHP字符串截取', 'color:rgb(95, 184, 120);font-weight:bold;', '', 'CLTPHP字符串截取', 'CLTPHP字符串截取', '<pre><span>//字符串截取<br></span><span>function </span><span>str_cut</span><span>(</span><span>$sourcestr</span><span>,</span><span>$cutlength</span><span>,</span><span>$suffix</span><span>=</span><span>\'...\'</span><span>)<br></span><span>{<br></span><span>    </span><span>$returnstr</span><span>=</span><span>\'\'</span><span>;<br></span><span>    </span><span>$i</span><span>=</span><span>0</span><span>;<br></span><span>    </span><span>$n</span><span>=</span><span>0</span><span>;<br></span><span>    </span><span>$str_length</span><span>=strlen(</span><span>$sourcestr</span><span>)</span><span>;</span><span>//字符串的字节数<br></span><span>    </span><span>while </span><span>((</span><span>$n</span><span>&lt;</span><span>$cutlength</span><span>) </span><span>and </span><span>(</span><span>$i</span><span>&lt;=</span><span>$str_length</span><span>))<br></span><span>    {<br></span><span>        </span><span>$temp_str</span><span>=substr(</span><span>$sourcestr</span><span>,</span><span>$i</span><span>,</span><span>1</span><span>)</span><span>;<br></span><span>        </span><span>$ascnum</span><span>=Ord(</span><span>$temp_str</span><span>)</span><span>;</span><span>//得到字符串中第$i位字符的ascii码<br></span><span>        </span><span>if </span><span>(</span><span>$ascnum</span><span>&gt;=</span><span>224</span><span>)    </span><span>//如果ASCII位高与224，<br></span><span>        </span><span>{<br></span><span>            </span><span>$returnstr</span><span>=</span><span>$returnstr</span><span>.substr(</span><span>$sourcestr</span><span>,</span><span>$i</span><span>,</span><span>3</span><span>)</span><span>; </span><span>//根据UTF-8编码规范，将3个连续的字符计为单个字符<br></span><span>            </span><span>$i</span><span>=</span><span>$i</span><span>+</span><span>3</span><span>;            </span><span>//实际Byte计为3<br></span><span>            </span><span>$n</span><span>++</span><span>;            </span><span>//字串长度计1<br></span><span>        </span><span>}<br></span><span>        </span><span>elseif </span><span>(</span><span>$ascnum</span><span>&gt;=</span><span>192</span><span>) </span><span>//如果ASCII位高与192，<br></span><span>        </span><span>{<br></span><span>            </span><span>$returnstr</span><span>=</span><span>$returnstr</span><span>.substr(</span><span>$sourcestr</span><span>,</span><span>$i</span><span>,</span><span>2</span><span>)</span><span>; </span><span>//根据UTF-8编码规范，将2个连续的字符计为单个字符<br></span><span>            </span><span>$i</span><span>=</span><span>$i</span><span>+</span><span>2</span><span>;            </span><span>//实际Byte计为2<br></span><span>            </span><span>$n</span><span>++</span><span>;            </span><span>//字串长度计1<br></span><span>        </span><span>}<br></span><span>        </span><span>elseif </span><span>(</span><span>$ascnum</span><span>&gt;=</span><span>65 </span><span>&amp;&amp; </span><span>$ascnum</span><span>&lt;=</span><span>90</span><span>) </span><span>//如果是大写字母，<br></span><span>        </span><span>{<br></span><span>            </span><span>$returnstr</span><span>=</span><span>$returnstr</span><span>.substr(</span><span>$sourcestr</span><span>,</span><span>$i</span><span>,</span><span>1</span><span>)</span><span>;<br></span><span>            </span><span>$i</span><span>=</span><span>$i</span><span>+</span><span>1</span><span>;            </span><span>//实际的Byte数仍计1个<br></span><span>            </span><span>$n</span><span>++</span><span>;            </span><span>//但考虑整体美观，大写字母计成一个高位字符<br></span><span>        </span><span>}<br></span><span>        </span><span>else                </span><span>//其他情况下，包括小写字母和半角标点符号，<br></span><span>        </span><span>{<br></span><span>            </span><span>$returnstr</span><span>=</span><span>$returnstr</span><span>.substr(</span><span>$sourcestr</span><span>,</span><span>$i</span><span>,</span><span>1</span><span>)</span><span>;<br></span><span>            </span><span>$i</span><span>=</span><span>$i</span><span>+</span><span>1</span><span>;            </span><span>//实际的Byte数计1个<br></span><span>            </span><span>$n</span><span>=</span><span>$n</span><span>+</span><span>0.5</span><span>;        </span><span>//小写字母和半角标点等与半个高位字符宽...<br></span><span>        </span><span>}<br></span><span>    }<br></span><span>    </span><span>if </span><span>(</span><span>$n</span><span>&gt;</span><span>$cutlength</span><span>){<br></span><span>        </span><span>$returnstr </span><span>= </span><span>$returnstr </span><span>. </span><span>$suffix</span><span>;</span><span>//超过长度时在尾处加上省略号<br></span><span>    </span><span>}<br></span><span>    </span><span>return </span><span>$returnstr</span><span>;<br></span><span>}</span></pre>', '0', '2', '1', '0', '', '0', '0', '334', '1501031299', '1502067767', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('16', '5', '1', 'admin', 'CLTPHP操作开发手册已完全更新', 'color:rgb(255, 87, 34);font-weight:bold;', '', 'CLTPHP操作开发手册已完全更新', 'CLTPHP操作开发手册已完全更新', '<p>CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p>喜欢的朋友可以购买参考</p><p>同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p>手册地址：https://www.kancloud.cn/chichu/cltphp/</p>', '0', '2', '1', '0', '', '0', '0', '1893', '1501031404', '1502068026', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('17', '6', '1', 'admin', 'CLTPHP判断当前访问的用户是  PC端  还是 手机端', 'color:rgb(51, 51, 153);font-weight:bold;', '', 'CLTPHP判断当前访问的用户是  PC端  还是 手机端', 'CLTPHP判断当前访问的用户是  PC端  还是 手机端', '<pre><span>/**<br></span><span> * 判断当前访问的用户是  PC端  还是 手机端  返回true 为手机端  false 为PC 端<br></span><span> *  是否移动端访问访问<br></span><span> * </span><span>@return </span><span>boolean<br></span><span> */<br></span><span>function </span><span>isMobile</span><span>()<br></span><span>{<br></span><span>    </span><span>// 如果有HTTP_X_WAP_PROFILE则一定是移动设备<br></span><span>    </span><span>if </span><span>(</span><span>isset </span><span>(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_X_WAP_PROFILE\'</span><span>]))<br></span><span>        </span><span>return true</span><span>;<br></span><span><br></span><span>    </span><span>// 如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息<br></span><span>    </span><span>if </span><span>(</span><span>isset </span><span>(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_VIA\'</span><span>]))<br></span><span>    {<br></span><span>        </span><span>// 找不到为flase,否则为true<br></span><span>        </span><span>return </span><span>stristr(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_VIA\'</span><span>]</span><span>, </span><span>\"wap\"</span><span>) ? </span><span>true </span><span>: </span><span>false</span><span>;<br></span><span>    </span><span>}<br></span><span>    </span><span>// 脑残法，判断手机发送的客户端标志,兼容性有待提高<br></span><span>    </span><span>if </span><span>(</span><span>isset </span><span>(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_USER_AGENT\'</span><span>]))<br></span><span>    {<br></span><span>        </span><span>$clientkeywords </span><span>= </span><span>array </span><span>(</span><span>\'nokia\'</span><span>,</span><span>\'sony\'</span><span>,</span><span>\'ericsson\'</span><span>,</span><span>\'mot\'</span><span>,</span><span>\'samsung\'</span><span>,</span><span>\'htc\'</span><span>,</span><span>\'sgh\'</span><span>,</span><span>\'lg\'</span><span>,</span><span>\'sharp\'</span><span>,</span><span>\'sie-\'</span><span>,</span><span>\'philips\'</span><span>,</span><span>\'panasonic\'</span><span>,</span><span>\'alcatel\'</span><span>,</span><span>\'lenovo\'</span><span>,</span><span>\'iphone\'</span><span>,</span><span>\'ipod\'</span><span>,</span><span>\'blackberry\'</span><span>,</span><span>\'meizu\'</span><span>,</span><span>\'android\'</span><span>,</span><span>\'netfront\'</span><span>,</span><span>\'symbian\'</span><span>,</span><span>\'ucweb\'</span><span>,</span><span>\'windowsce\'</span><span>,</span><span>\'palm\'</span><span>,</span><span>\'operamini\'</span><span>,</span><span>\'operamobi\'</span><span>,</span><span>\'openwave\'</span><span>,</span><span>\'nexusone\'</span><span>,</span><span>\'cldc\'</span><span>,</span><span>\'midp\'</span><span>,</span><span>\'wap\'</span><span>,</span><span>\'mobile\'</span><span>)</span><span>;<br></span><span>        </span><span>// 从HTTP_USER_AGENT中查找手机浏览器的关键字<br></span><span>        </span><span>if </span><span>(preg_match(</span><span>\"/(\" </span><span>. implode(</span><span>\'|\'</span><span>, </span><span>$clientkeywords</span><span>) . </span><span>\")/i\"</span><span>, </span><span>strtolower(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_USER_AGENT\'</span><span>])))<br></span><span>            </span><span>return true</span><span>;<br></span><span>    </span><span>}<br></span><span>    </span><span>// 协议法，因为有可能不准确，放到最后判断<br></span><span>    </span><span>if </span><span>(</span><span>isset </span><span>(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_ACCEPT\'</span><span>]))<br></span><span>    {<br></span><span>        </span><span>// 如果只支持wml并且不支持html那一定是移动设备<br></span><span>        // 如果支持wml和html但是wml在html之前则是移动设备<br></span><span>        </span><span>if </span><span>((strpos(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_ACCEPT\'</span><span>]</span><span>, </span><span>\'vnd.wap.wml\'</span><span>) !== </span><span>false</span><span>) &amp;&amp; (strpos(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_ACCEPT\'</span><span>]</span><span>, </span><span>\'text/html\'</span><span>) === </span><span>false </span><span>|| (strpos(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_ACCEPT\'</span><span>]</span><span>, </span><span>\'vnd.wap.wml\'</span><span>) &lt; strpos(</span><span>$_SERVER</span><span>[</span><span>\'HTTP_ACCEPT\'</span><span>]</span><span>, </span><span>\'text/html\'</span><span>))))<br></span><span>        {<br></span><span>            </span><span>return true</span><span>;<br></span><span>        </span><span>}<br></span><span>    }<br></span><span>    </span><span>return false</span><span>;<br></span><span>}</span></pre>', '0', '2', '1', '0', '', '0', '0', '350', '1501204163', '1501204249', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('18', '3', '1', 'admin', '关于收费文档的误解', 'color:rgb(0, 153, 102);font-weight:bold;', '', '关于收费文档的误解', '关于收费文档的误解', '<p>　　cltphp的文档收费20，靠20块文档赚钱，有点夸大了，定2000，万一有一个人付费，那就是100个20，也能算挣点小钱。</p><p>　　不花钱的东西，没有价值，也无所谓去骂娘。花了钱，大多人会去看，有价值的部分，自然会学习到。没价值的部分，一些人会骂娘，骂娘的同时，或许会说：这里怎样改一下不久好了嘛！对于这样的骂娘，我们很是支持。</p><p>　　另外赋上文档的初始态度：<a href=\"http://cltphp.com/newsInfo-16-5.html\" target=\"_self\" style=\"text-decoration: none;\"><strong>CLTPHP操作文档不断更新中</strong></a></p><h4><br/></h4>', '0', '2', '1', '0', '', '0', '0', '1386', '1501552272', '1505373009', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('19', '3', '1', 'admin', '关于捐赠的一些说明', 'color:rgb(255, 87, 34);font-weight:bold;', '', '关于捐赠的一些说明', '关于捐赠的一些说明', '<p>首先非常感谢您对我们的支持。</p><p>近期发现，一部分朋友对我们捐赠时，并未留下名称或者其他称呼。</p><p>目前官网只接受微信扫码捐赠，所以，请您务必点击留言，留下您的大名，便于我们做捐赠名的展示。<img src=\"/public/uploads/20170904/a1bb03cea85aafd3bca3287ef3ade719.png\" alt=\"20170904/a1bb03cea85aafd3bca3287ef3ade719.png\"></p>', '0', '0', '1', '0', '', '0', '0', '531', '1501827480', '1504516379', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('20', '6', '1', 'admin', 'PHP格式化字节大小', 'color:hsv(0, 0%, 0%);font-weight:bold;', '', 'PHP格式化字节大小', 'PHP格式化字节大小', '<pre><span>/**<br></span><span> * PHP格式化字节大小<br></span><span> * </span><span>@param  </span><span>number $size      字节数<br></span><span> * </span><span>@param  </span><span>string $delimiter 数字和单位分隔符<br></span><span> * </span><span>@return </span><span>string            格式化后的带单位的大小<br></span><span> */<br></span><span>function </span><span>format_bytes</span><span>(</span><span>$size</span><span>, </span><span>$delimiter </span><span>= </span><span>\'\'</span><span>) {<br></span><span>    </span><span>$units </span><span>= </span><span>array</span><span>(</span><span>\'B\'</span><span>, </span><span>\'KB\'</span><span>, </span><span>\'MB\'</span><span>, </span><span>\'GB\'</span><span>, </span><span>\'TB\'</span><span>, </span><span>\'PB\'</span><span>)</span><span>;<br></span><span>    </span><span>for </span><span>(</span><span>$i </span><span>= </span><span>0</span><span>; </span><span>$size </span><span>&gt;= </span><span>1024 </span><span>&amp;&amp; </span><span>$i </span><span>&lt; </span><span>5</span><span>; </span><span>$i</span><span>++) </span><span>$size </span><span>/= </span><span>1024</span><span>;<br></span><span>    </span><span>return </span><span>round(</span><span>$size</span><span>, </span><span>2</span><span>) . </span><span>$delimiter </span><span>. </span><span>$units</span><span>[</span><span>$i</span><span>]</span><span>;<br></span><span>}</span></pre>', '0', '1', '1', '0', '', '0', '0', '408', '1502067689', '1502067893', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('21', '5', '1', 'admin', 'CLTPHP4.5发布', 'color:rgb(0, 153, 102);font-weight:bold;', '', 'CLTPHP4.5发布', 'CLTPHP4.5发布', '<p>1.更新权限功能</p><p>2.增加微信关注回复和默认回复</p><p>3.增加后台页面过度效果</p><p>4.后台部分功能代码优化</p>', '0', '2', '1', '0', '', '0', '0', '356', '1502067980', '1502422491', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('22', '5', '1', 'admin', 'CLTPHP5.0发布', 'color:rgb(255, 87, 34);font-weight:bold;', '', 'CLTPHP5.0发布', 'CLTPHP5.0发布', '<p>CLTPHP5.0更新内容</p><p>1.增加前台会员模块，支持QQ登录注册</p><p>2.增加后台邮件发送配置</p><p>3.增加后台QQ登录配置</p><p>4.增加后台富文本编辑器选择（<span>layedit，</span><span>UEditor</span>）</p><p>5.增加后台上传logo</p><p>6.增加微信关注回复及默认回复</p><p>7.优化后台部分语言功能</p><p>8.简单实现home模块路由配置</p><p>9.增加home模块缓存机制</p><p>10.修复后台管理员无法添加的bug</p><p>11.修复4.5版本模版管理.html无法编辑的bug</p><p>12.更多细节修改及bug</p><p>下载地址：<a target=\"_self\" href=\"http://o95ehky7c.bkt.clouddn.com/CLTPHP5.0.zip\">CLTPHP5.0</a></p>', '0', '2', '1', '0', '', '0', '0', '927', '1502421726', '1503365682', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('23', '3', '1', 'admin', '清除缓存和添加字段的错误修正方法', 'color:;font-weight:normal;', '', '清除缓存和添加字段的错误修正方法', '清除缓存和添加字段的错误修正方法', '<p>问题：</p><pre>Deprecated:&nbsp;Automatically&nbsp;populating&nbsp;$HTTP_RAW_POST_DATA&nbsp;is&nbsp;deprecated&nbsp;and&nbsp;will&nbsp;be&nbsp;removed&nbsp;in&nbsp;a&nbsp;future&nbsp;version.&nbsp;To&nbsp;avoid&nbsp;this&nbsp;warning&nbsp;set&nbsp;&#39;always_populate_raw_post_data&#39;&nbsp;to&nbsp;&#39;-1&#39;&nbsp;in&nbsp;php.ini&nbsp;and&nbsp;use&nbsp;the&nbsp;php://input&nbsp;stream&nbsp;instead.&nbsp;in&nbsp;Unknown&nbsp;on&nbsp;line&nbsp;0</pre><p><br/></p><p>修正方法：</p><p>去掉php.in配置文件always_populate_raw_post_data前面的分号</p><p><br/></p><p><br/></p>', '0', '0', '1', '0', '', '0', '0', '252', '1502761583', '1504763357', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('25', '5', '1', 'admin', 'CLTPHP手册更新自定义标签', 'color:;font-weight:normal;', '', 'CLTPHP手册更新自定义标签', 'CLTPHP手册更新自定义标签', '<p>CLTPHP手册更新自定义标签，文档详细讲述了 {clt:list}{/clt:list} 和 {clt:info}{/clt:info} 两个标签的参数和调用方法。</p>', '0', '1', '1', '0', '', '0', '0', '1097', '1503365502', '0', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('36', '5', '1', 'admin', 'CLTPHP5.1.1更新', 'color:rgb(0, 153, 102);font-weight:bold;', '', 'CLTPHP5.1.1更新  cltphp cltphp内容管理系统 php', 'CLTPHP的目的是 让所有人都能 高效 简洁 的建立网站，虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。', '<p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(151, 151, 151); white-space: normal; background-color: rgb(255, 255, 255);\">更新内容</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(151, 151, 151); white-space: normal; background-color: rgb(255, 255, 255);\">1、前台自定义标签完善</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(151, 151, 151); white-space: normal; background-color: rgb(255, 255, 255);\">2、自定义分页，优化了系统分页（为了保持框架文件的纯净度，并没有改动TP原有分页代码）</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(151, 151, 151); white-space: normal; background-color: rgb(255, 255, 255);\">3、更新对应文档</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(151, 151, 151); white-space: normal; background-color: rgb(255, 255, 255);\">下载地址：<a target=\"_self\" href=\"http://qiniu.cltphp.com/cltphp5.1.1.zip\" style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; outline: 0px; color: rgb(146, 208, 80); text-decoration: none;\"><span style=\"color: rgb(146, 208, 80);\">CLTPHP5.1.1下载</span></a></p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(151, 151, 151); white-space: normal; background-color: rgb(255, 255, 255);\">更新包下载：<a target=\"_self\" href=\"http://qiniu.cltphp.com/CLTPHP5.1%E5%88%B05.1.1%E5%8D%87%E7%BA%A7.zip\" style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; outline: 0px; color: rgb(146, 208, 80); text-decoration: none;\"><span style=\"color: rgb(146, 208, 80);\">CLTPHP5.1到5.1.1更新</span></a></p><p><br/></p>', '0', '0', '1', '0', '', '0', '0', '223', '1504765025', '1505355804', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('37', '5', '1', 'admin', 'CLTPHP5.1.2发布', 'color:rgb(0, 153, 102);font-weight:bold;', '', 'CLTPHP5.1.2发布  cltphp cltphp内容管理系统 php', 'CLTPHP的目的是 让所有人都能 高效 简洁 的建立网站，虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。', '<p>更新内容</p><p>1、<strong>CLTPHP</strong>核心框架thinkphp升级</p><p>2、分类，广告，友链的前后台缓存机制</p><p>下载地址：<strong style=\"color: rgb(118, 146, 60); text-decoration: none;\"><span style=\"color: rgb(118, 146, 60);\"><a href=\"http://qiniu.cltphp.com/cltphp5.1.2.zip\" target=\"_self\" title=\"CLTPHP5.1.2下载\" style=\"color: rgb(118, 146, 60); text-decoration: none;\">CLTPHP5.1.2</a></span></strong></p><p><br/></p><p><br/></p>', '0', '0', '1', '0', '', '0', '0', '140', '1505264091', '1505355785', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('38', '3', '1', 'admin', '关于CLTPHP的一些琐碎事', 'color:rgb(51, 51, 153);font-weight:bold;', '', '关于CLTPHP的一些琐碎事 cltphp cltphp内容管理系统 php', 'CLTPHP的目的是 让所有人都能 高效 简洁 的建立网站，虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。', '<p>CLTPHP是开源的</p><p><a href=\"http://demo.cltphp.com\" target=\"_self\" title=\"CLTPHP演示站\">CLTPHP演示站</a>的后台用户名：admin &nbsp;密码：admin123</p><p>版本更新包的后台用户名：admin &nbsp;密码：admin123</p><p>新版本发布，请登录后台，清空缓存后再打开前台，不然，前台可能会报错。</p><p><span style=\"color: rgb(149, 55, 52);\">如果没有意外（睡眼忪惺）的时候，以上永久不变。</span></p>', '0', '1', '1', '0', '', '0', '0', '1204', '1505264319', '1517218472', 'CLTPHP', 'http://www.cltphp.com/', '4,54,532');
INSERT INTO `clt_article` VALUES ('40', '6', '1', 'admin', 'php验证输入的邮件地址是否合法', 'color:;font-weight:normal;', '', 'php验证输入的邮件地址是否合法', 'php验证输入的邮件地址是否合法', '<pre class=\"brush:php;toolbar:false\">/**\n&nbsp;*&nbsp;验证输入的邮件地址是否合法\n&nbsp;*/\nfunction&nbsp;is_email($user_email)\n{\n&nbsp;&nbsp;&nbsp;&nbsp;$chars&nbsp;=&nbsp;&quot;/^([a-z0-9+_]|\\\\-|\\\\.)+@(([a-z0-9_]|\\\\-)+\\\\.)+[a-z]{2,6}\\$/i&quot;;\n&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(strpos($user_email,&nbsp;&#39;@&#39;)&nbsp;!==&nbsp;false&nbsp;&amp;&amp;&nbsp;strpos($user_email,&nbsp;&#39;.&#39;)&nbsp;!==&nbsp;false)&nbsp;{\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(preg_match($chars,&nbsp;$user_email))&nbsp;{\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;true;\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;false;\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}\n&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;false;\n&nbsp;&nbsp;&nbsp;&nbsp;}\n}</pre><p><br/></p>', '0', '2', '1', '0', '', '0', '0', '174', '1505355407', '1505355561', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('39', '5', '1', 'admin', 'CLTPHP5.1.3发布', 'color:rgb(0, 153, 102);font-weight:bold;', '', 'CLTPHP5.1.3发布 cltphp cltphp内容管理系统 php', 'CLTPHP的目的是 让所有人都能 高效 简洁 的建立网站，虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。', '<p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">更新内容</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">1、修复多图上传bug</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">2、修复后台栏目二级目录下路径问题</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">3、修改TP自带提示文件正确状态下的图标</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">4、修改模型字段编辑表单显示与数据库不一致问题</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">5、修复QQ绑定bug</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">6、修复5.1.2版本数据库备份问题</p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">下载地址：<a href=\"http://qiniu.cltphp.com/CLTPHP5.1.3.zip\" target=\"_self\" title=\"CLTPHP5.1.3下载\" style=\"text-decoration: none;\"><strong><span style=\"color: rgb(0, 176, 80);\">CLTPHP5.1.3</span></strong><strong><span style=\"color: rgb(0, 176, 80);\"></span></strong></a></p><p style=\"box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; margin-top: 0px; margin-bottom: 0px; padding: 0px 0px 20px; color: rgb(102, 102, 102); white-space: normal; background-color: rgb(255, 255, 255);\">更新包下载：<a href=\"http://qiniu.cltphp.com/5.1.2%E5%8D%875.1.3%E8%A1%A5%E4%B8%81.zip\" target=\"_self\" title=\"CLTPHP5.1.2到5.1.3更新\" style=\"color: rgb(0, 176, 80); text-decoration: none;\"><strong><span style=\"color: rgb(0, 176, 80);\">CLTPHP5.1.2到5.1.3更新</span></strong></a></p><p><br/></p>', '0', '2', '1', '0', '', '0', '0', '700', '1505353199', '1505872972', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('41', '5', '1', 'admin', 'CLTPHP5.2发布', 'color:rgb(0, 153, 102);font-weight:bold;', '', 'CLTPHP5.2发布', 'CLTPHP5.2发布', '<p>更新内容</p><p>1.后台核心框架升级为ThinkPHP5.0.11版本</p><p>2.后台及会员中心UI框架升级为layui2.1.5版本</p><p>3.碎片修改为以碎片分类来管理</p><p>4.优化图片、文件上传</p><p>5.优化双编辑器切换</p><p>6.后台增加主题切换功能</p><p>7.后台全屏状态，点击全屏按钮可收起全屏</p><p><span style=\"color: rgb(255, 0, 0);\">注意事项</span></p><p><span style=\"color: rgb(255, 0, 0);\">1.遇到问题，先去官网找答案。</span></p><p><span style=\"color: rgb(255, 0, 0);\">2.CLTPHP5.2是一个大面积修改升级版，不支持之前任何版本的无缝升级。</span></p><p>下载地址：<a href=\"http://qiniu.cltphp.com/cltphp5.2.zip\" target=\"_self\" title=\"CLTPHP5.2\" style=\"color: rgb(0, 176, 80); text-decoration: none;\"><strong><span style=\"color: rgb(0, 176, 80);\">CLTPHP5.2</span></strong></a></p><p><br/></p>', '0', '2', '1', '0', '', '0', '0', '1552', '1505871918', '1507879183', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('42', '5', '1', 'admin', 'CLTPHP5.2.1发布', 'color:;font-weight:normal;', '', 'CLTPHP5.2.1发布 cltphp cltphp内容管理系统 php', 'CLTPHP的目的是 让所有人都能 高效 简洁 的建立网站，虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。', '<p style=\"margin-top: 0px; margin-bottom: 0px; white-space: normal; box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; padding: 0px 0px 20px; color: rgb(102, 102, 102); background-color: rgb(255, 255, 255);\">更新内容</p><p style=\"margin-top: 0px; margin-bottom: 0px; white-space: normal; box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; padding: 0px 0px 20px; color: rgb(102, 102, 102); background-color: rgb(255, 255, 255);\">1、修改会员中心无法解绑QQbug</p><p style=\"margin-top: 0px; margin-bottom: 0px; white-space: normal; box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; padding: 0px 0px 20px; color: rgb(102, 102, 102); background-color: rgb(255, 255, 255);\">2、修复后台多图上传bug</p><p style=\"margin-top: 0px; margin-bottom: 0px; white-space: normal; box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; padding: 0px 0px 20px; color: rgb(102, 102, 102); background-color: rgb(255, 255, 255);\">下载地址：<a href=\"http://qiniu.cltphp.com/CLTPHP5.2.1.zip\" target=\"_self\" title=\"CLTPHP5.2.1下载\"><strong style=\"text-decoration: none; white-space: normal; color: rgb(118, 146, 60);\">CLTPHP5.2.1</strong></a><a href=\"http://qiniu.cltphp.com/cltphp5.2.1.zip\" target=\"_self\" title=\"CLTPHP5.2.1下载\"><strong style=\"white-space: normal; color: rgb(118, 146, 60);\"></strong></a></p><p style=\"margin-top: 0px; margin-bottom: 0px; white-space: normal; box-sizing: border-box; border: 0px; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; vertical-align: baseline; padding: 0px 0px 20px; color: rgb(102, 102, 102); background-color: rgb(255, 255, 255);\"><span style=\"color: rgb(102, 102, 102); font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; background-color: rgb(255, 255, 255);\">补丁地址：</span><a href=\"http://qiniu.cltphp.com/CLTPHP5.2%E5%88%B05.2.1%E8%A1%A5%E4%B8%81.zip\" target=\"_self\" title=\"CLTPHP5.2升5.2.1补丁\" style=\"color: rgb(118, 146, 60); text-decoration: none;\"><strong><span style=\"color: rgb(146, 208, 80);\">CLTPHP5.2升5.2.1补丁</span></strong></a></p><p><br/></p>', '0', '0', '1', '0', '', '0', '0', '250', '1506475263', '1506475718', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('43', '6', '1', 'admin', '纯CSS实现页面的尖角、小三角、不同方向尖角的方法小结', 'color:;font-weight:normal;', '', '', '', '<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\">效果图：</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\">方法一的效果图：</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"/public/uploads/ueditor/image/20171008/1507425192923475.png\" alt=\"\"/></p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\">方法二的效果图：</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"/public/uploads/ueditor/image/20171008/1507425192357806.png\" alt=\"\"/></p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\">方法三的效果图：</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"/public/uploads/ueditor/image/20171008/1507425192288407.png\" alt=\"\"/></p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(255, 0, 0);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">方法1：因为有背景，所有实现起来比较方便，尖角的内部同个颜色就可以不用考虑遮挡问题</span></span></p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">html:</span></p><pre class=\"brush:xhtml;\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; overflow: auto; font-family: monospace, monospace; font-size: 1em; line-height: 1.42857; word-break: break-all; word-wrap: break-word; border: 1px solid rgb(204, 204, 204); border-radius: 4px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); background-color: rgb(245, 245, 245);\">&lt;div&nbsp;id=&quot;first&quot;&gt;&nbsp;&nbsp;\n&lt;p&gt;带背景颜色的小三角实现是比较简单的！&lt;/p&gt;&nbsp;&nbsp;\n&nbsp;&nbsp;&lt;span&nbsp;id=&quot;top&quot;&gt;&lt;/span&gt;&nbsp;&nbsp;\n&lt;/div&gt;</pre><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">css</span></p><pre class=\"brush:sql;\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; overflow: auto; font-family: monospace, monospace; font-size: 1em; line-height: 1.42857; word-break: break-all; word-wrap: break-word; border: 1px solid rgb(204, 204, 204); border-radius: 4px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); background-color: rgb(245, 245, 245);\">#top&nbsp;{&nbsp;&nbsp;\n&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;position:&nbsp;absolute;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;width:&nbsp;0px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;height:&nbsp;0px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;line-height:&nbsp;0px;/*为了防止ie下出现题型*/&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;border-bottom:&nbsp;10px&nbsp;solid&nbsp;#89b007;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;border-left:&nbsp;10px&nbsp;solid&nbsp;#fff;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;border-right:&nbsp;10px&nbsp;solid&nbsp;#fff;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;left:&nbsp;76px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;top:&nbsp;-10px;&nbsp;&nbsp;\n}&nbsp;&nbsp;\n#first&nbsp;{&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;border-radius:8px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;-moz-border-radius:8px;-ms-border-radius:8px;-o-border-radius:8px;-webkit-border-radius:8px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;position:&nbsp;absolute;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;height:&nbsp;150px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;width:&nbsp;300px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;background:&nbsp;#89b007;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;left:&nbsp;22px;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;top:&nbsp;33px;&nbsp;&nbsp;\n}&nbsp;&nbsp;\n#first&nbsp;p{&nbsp;padding:10px;&nbsp;line-height:1.5;&nbsp;color:#FFF;}</pre><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(255, 0, 0);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">方法2：</span></span></p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">html</span></p><pre class=\"brush:xhtml;\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; overflow: auto; font-family: monospace, monospace; font-size: 1em; line-height: 1.42857; word-break: break-all; word-wrap: break-word; border: 1px solid rgb(204, 204, 204); border-radius: 4px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); background-color: rgb(245, 245, 245);\">&lt;div&nbsp;class=&quot;w&quot;&gt;&nbsp;&nbsp;\n&nbsp;&nbsp;&lt;div&nbsp;class=&quot;x&quot;&gt;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;&lt;p&gt;&lt;a&nbsp;href=&quot;#&quot;&gt;用面向对象的思想去书写css,用面向对象的心态去书写css。&lt;/a&gt;&lt;/p&gt;&nbsp;&nbsp;\n&nbsp;&nbsp;&nbsp;&nbsp;&lt;span&nbsp;class=&quot;z&quot;&gt;◆&lt;/span&gt;&nbsp;&lt;span&nbsp;class=&quot;y&quot;&gt;◆&lt;/span&gt;&nbsp;&lt;/div&gt;&nbsp;&nbsp;\n&lt;/div&gt;</pre><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">css</span></p><pre class=\"brush:css;\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; overflow: auto; font-family: monospace, monospace; font-size: 1em; line-height: 1.42857; word-break: break-all; word-wrap: break-word; border: 1px solid rgb(204, 204, 204); border-radius: 4px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); background-color: rgb(245, 245, 245);\">*&nbsp;{&nbsp;&nbsp;\nmargin:&nbsp;0;&nbsp;&nbsp;\npadding:&nbsp;0;&nbsp;&nbsp;\n}&nbsp;&nbsp;\na{&nbsp;color:#666;&nbsp;text-decoration:none;&nbsp;line-height:25px;&nbsp;text-indent:24px;}&nbsp;&nbsp;\n.w{&nbsp;width:200px;&nbsp;position:absolute;&nbsp;background:#999;&nbsp;left:400px;&nbsp;top:200px;&nbsp;font-size:12px;&nbsp;text-align:left}/*模拟灰色阴影背景层*/&nbsp;&nbsp;\n.x{&nbsp;width:180px;&nbsp;position:relative;&nbsp;background:#fff;&nbsp;&nbsp;border:1px&nbsp;solid&nbsp;#ccc;&nbsp;padding:10px;&nbsp;left:-4px;&nbsp;top:-4px;}/*内容div*/&nbsp;&nbsp;\n.y&nbsp;,&nbsp;.z{&nbsp;&nbsp;\nposition:&nbsp;absolute;&nbsp;&nbsp;\nleft:&nbsp;141px;&nbsp;&nbsp;\n}&nbsp;&nbsp;\n.y{&nbsp;&nbsp;\ncolor:&nbsp;#ccc;&nbsp;&nbsp;\nfont-size:&nbsp;19px;&nbsp;&nbsp;\ntop:-12px;&nbsp;&nbsp;\nz-index:1;&nbsp;&nbsp;\n}/*模拟小三角*/&nbsp;&nbsp;\n.z{&nbsp;&nbsp;\ncolor:&nbsp;#fff;&nbsp;&nbsp;\nfont-size:&nbsp;19px;&nbsp;&nbsp;\ntop:-11px;&nbsp;&nbsp;z-index:3;&nbsp;&nbsp;\n}/*模拟小三角*/</pre><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(51, 51, 51); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 19.5px; white-space: normal; background-color: rgb(255, 255, 255);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); color: rgb(255, 0, 0);\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: 700; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\">方法3：</span></span></p><pre class=\"brush:xhtml;\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; overflow: auto; font-family: monospace, monospace; font-size: 1em; line-height: 1.42857; word-break: break-all; word-wrap: break-word; border: 1px solid rgb(204, 204, 204); border-radius: 4px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); background-color: rgb(245, 245, 245);\">&lt;div&nbsp;id=&quot;content&quot;&gt;&nbsp;&lt;span&nbsp;class=&quot;out&quot;&gt;&lt;/span&gt;&lt;span&nbsp;class=&quot;iner&quot;&gt;&lt;/span&gt;&nbsp;&lt;span&nbsp;class=&quot;right&quot;&gt;&lt;/span&gt;&nbsp;&nbsp;\n&nbsp;&nbsp;&lt;p&gt;不管写什么内容，总之就是要实现无图小三角，要是有背景颜色那倒是极好的，没有的话也可以，就是稍微麻烦一点&lt;/p&gt;&nbsp;&nbsp;\n&lt;/div&gt;</pre><pre class=\"brush:css;\" style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 0px; padding: 0px; overflow: auto; font-family: monospace, monospace; font-size: 1em; line-height: 1.42857; word-break: break-all; word-wrap: break-word; border: 1px solid rgb(204, 204, 204); border-radius: 4px; outline: 0px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); background-color: rgb(245, 245, 245);\">#content&nbsp;{&nbsp;&nbsp;\ntext-indent:&nbsp;2em;&nbsp;&nbsp;\nbox-shadow:&nbsp;0px&nbsp;0px&nbsp;10px&nbsp;#999;&nbsp;&nbsp;\npadding:&nbsp;10px;&nbsp;&nbsp;\nfont-size:&nbsp;12px;&nbsp;&nbsp;\nline-height:&nbsp;1.5;&nbsp;&nbsp;\nborder-radius:&nbsp;5px;&nbsp;&nbsp;\nheight:&nbsp;100px;&nbsp;&nbsp;\nwidth:&nbsp;250px;&nbsp;&nbsp;\nposition:&nbsp;relative;&nbsp;&nbsp;\nmargin:&nbsp;200px&nbsp;auto;&nbsp;&nbsp;\nborder:&nbsp;1px&nbsp;solid&nbsp;#CCC;&nbsp;&nbsp;\n}&nbsp;&nbsp;\nspan&nbsp;{&nbsp;&nbsp;\nposition:&nbsp;absolute;&nbsp;&nbsp;\nleft:&nbsp;25px;&nbsp;&nbsp;\nheight:&nbsp;0px;&nbsp;&nbsp;\nwidth:&nbsp;0px;&nbsp;&nbsp;\n}&nbsp;&nbsp;\n/*上部小三角实现样式开始*/&nbsp;&nbsp;\nspan.out&nbsp;{&nbsp;&nbsp;\nline-height:&nbsp;0;&nbsp;&nbsp;\nborder-width:&nbsp;10px;&nbsp;&nbsp;\nborder-color:&nbsp;transparent&nbsp;transparent&nbsp;#CCC&nbsp;transparent;&nbsp;&nbsp;\nborder-style:&nbsp;dashed&nbsp;dashed&nbsp;solid&nbsp;dashed;&nbsp;&nbsp;\ntop:&nbsp;-20px;&nbsp;&nbsp;\n}&nbsp;&nbsp;\nspan.iner&nbsp;{&nbsp;&nbsp;\nborder-width:&nbsp;10px;&nbsp;&nbsp;\nborder-color:&nbsp;#fff&nbsp;transparent&nbsp;#FFF&nbsp;transparent;&nbsp;&nbsp;\nborder-style:&nbsp;dashed&nbsp;dashed&nbsp;solid&nbsp;dashed;&nbsp;&nbsp;\ntop:&nbsp;-19px;&nbsp;&nbsp;\nline-height:&nbsp;0;&nbsp;&nbsp;\n}&nbsp;&nbsp;\n/*右部小三角实现样式开始*/&nbsp;&nbsp;\nspan.right&nbsp;{&nbsp;&nbsp;\nbackground:&nbsp;#FFF;&nbsp;&nbsp;\nborder-width:&nbsp;1px;&nbsp;&nbsp;\nwidth:&nbsp;16px;&nbsp;&nbsp;\nheight:&nbsp;16px;&nbsp;&nbsp;\nborder-color:&nbsp;#CCC&nbsp;#CCC&nbsp;transparent&nbsp;transparent;&nbsp;&nbsp;\nborder-style:&nbsp;solid&nbsp;solid&nbsp;dashed&nbsp;dashed;&nbsp;&nbsp;\nleft:&nbsp;270px;&nbsp;&nbsp;\ntop:&nbsp;30px;&nbsp;&nbsp;\nborder-radius:&nbsp;0&nbsp;0&nbsp;100%&nbsp;0;/*这里radius的值不要选取绝对值因为在放大或者缩小的过程中会产生封不住口的现象*/&nbsp;&nbsp;\nline-height:&nbsp;0;&nbsp;&nbsp;\nbox-shadow:&nbsp;5px&nbsp;0&nbsp;10px&nbsp;#aaa;&nbsp;&nbsp;\n}</pre><p><br/></p>', '0', '0', '1', '0', '', '0', '0', '102', '1507425169', '0', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('44', '5', '1', 'admin', 'CLTPHP5.2.2发布', 'color:;font-weight:normal;', '', 'CLTPHP5.2.2发布', 'CLTPHP5.2.2发布', '<p><span style=\"color:#666666;font-family:Microsoft yahei, Arial, Tahoma, Verdana\"><span style=\"font-size: 14px; line-height: 24px; background-color: rgb(255, 255, 255);\">修改bug若干</span></span></p><p><span style=\"color: rgb(102, 102, 102); font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; background-color: rgb(255, 255, 255);\">下载地址：</span><strong><span style=\"color: rgb(102, 102, 102); font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; text-decoration: none; background-color: rgb(255, 255, 255);\"><a href=\"http://qiniu.cltphp.com/cltphp5.2.2.zip\" target=\"_self\" title=\"CLTPHP5.2.2\" style=\"color: rgb(0, 176, 80);\"><span style=\"text-decoration: none; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; color: rgb(0, 176, 80); background-color: rgb(255, 255, 255);\">CLTPHP5.2.2</span></a></span></strong></p><p><span style=\"color: rgb(102, 102, 102); font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; background-color: rgb(255, 255, 255);\">补丁地址：</span><span style=\"color: rgb(102, 102, 102); font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; text-decoration: none; background-color: rgb(255, 255, 255);\"><a href=\"http://qiniu.cltphp.com/CLTPHP5.2.1%E5%88%B05.2.2%E8%A1%A5%E4%B8%81.zip\" target=\"_self\" style=\"color: rgb(0, 176, 80);\"><strong><span style=\"text-decoration: none; font-family: &#39;Microsoft yahei&#39;, Arial, Tahoma, Verdana; font-size: 14px; line-height: 24px; color: rgb(0, 176, 80); background-color: rgb(255, 255, 255);\">CLTPHP5.2.1到5.2.2升级</span></strong></a></span></p>', '0', '1', '1', '0', '', '0', '0', '1654', '1507877194', '1507879172', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('45', '5', '1', 'admin', '给我们一点点时间  我们给你一个新突破', 'color:;font-weight:normal;', '', '给我们一点点时间  我们给你一个新突破', '给我们一点点时间  我们给你一个新突破', '<p style=\"text-indent: 2em;\">说实话，最近这段时间我们太忙了<img src=\"http://img.baidu.com/hi/jx2/j_0016.gif\"/>，cltphp的开发，甚至可以说是搁浅了一段时间。不过，各位请耐心等待一下啊，给我们一点点时间，或许不止一点点，我们给你一个新突破。</p>', '0', '1', '1', '0', '', '0', '0', '97', '1512032568', '1512032865', 'CLTPHP', 'http://www.cltphp.com/', '');
INSERT INTO `clt_article` VALUES ('46', '3', '1', 'admin', '测试', 'color:;font-weight:normal;', '', '测试', '测试', '', '0', '0', '1', '0', '', '0', '0', '0', '1517218576', '0', 'CLTPHP', 'http://www.cltphp.com/', '4,57,560');

-- -----------------------------
-- Table structure for `config`
-- -----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `siteid` int(11) DEFAULT NULL COMMENT '站点ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `group` (`group`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `config`
-- -----------------------------
INSERT INTO `config` VALUES ('1', '0', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1517387079', '1', 'Mingyu权限系统', '0');
INSERT INTO `config` VALUES ('2', '0', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'Mingyu权限系统是一个开源免费的权限系统\nMingyu权限系统是基于ThinkPHP5框架开的多模块权限系统', '2');
INSERT INTO `config` VALUES ('3', '0', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1517994741', '1', 'Mingyu权限系统，开源免费权限系统，ThinkPHP5开源系统', '1');
INSERT INTO `config` VALUES ('4', '0', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '5');
INSERT INTO `config` VALUES ('10', '0', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号', '1378900335', '1379235859', '1', '34234234234234444412222234234234234234', '9');
INSERT INTO `config` VALUES ('26', '0', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `config` VALUES ('28', '0', 'DATA_BACKUP_PATH', '1', '备份根路径', '2', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `config` VALUES ('29', '0', 'DATA_BACKUP_PART_SIZE', '0', '备份卷大小', '2', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `config` VALUES ('30', '0', 'DATA_BACKUP_COMPRESS', '4', '备份是否压缩', '2', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '0', '9');
INSERT INTO `config` VALUES ('31', '0', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '备份压缩级别', '2', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '4', '10');
INSERT INTO `config` VALUES ('36', '0', 'DENY_IP', '2', '禁止访问IP', '2', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '12312234234234', '12');
INSERT INTO `config` VALUES ('89', '0', 'SITELOGO', '5', '网站LOGO', '1', '', '尺寸：300*70(px)', '1516150910', '1516150910', '1', '/public/themes/Home/images/logo.jpg', '4');
INSERT INTO `config` VALUES ('90', '0', 'IS_LOG', '4', '是否开户日志', '2', '0:关闭,1:开启', '是否开户日志', '1516249072', '1516249072', '1', '1', '5');
INSERT INTO `config` VALUES ('102', '0', 'WEB_SITE_URL', '1', '网站地址', '1', '', '网站访问url地址', '1521693832', '1521693878', '1', 'http://d.com', '0');
INSERT INTO `config` VALUES ('103', '0', 'HTML_CACHE', '4', '开启静态缓存', '2', '0:关闭\n1:开启', '是否开启静态缓存;1开0关', '1522203017', '1522203511', '1', '0', '4');

-- -----------------------------
-- Table structure for `field`
-- -----------------------------
DROP TABLE IF EXISTS `field`;
CREATE TABLE `field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '' COMMENT '字段名',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段k中文名称',
  `tips` varchar(150) NOT NULL DEFAULT '' COMMENT '默认输入提示',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:不必填;1必填',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL DEFAULT '' COMMENT '验证类型',
  `errormsg` varchar(255) NOT NULL DEFAULT '' COMMENT '验证错误提示',
  `class` varchar(20) NOT NULL DEFAULT '' COMMENT 'id标识',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '字段类型',
  `setup` mediumtext NOT NULL,
  `ispost` tinyint(1) NOT NULL DEFAULT '0',
  `unpostgroup` varchar(60) NOT NULL DEFAULT '',
  `listorder` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:正常;1:不可写;2:隐藏',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=226 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `field`
-- -----------------------------
INSERT INTO `field` VALUES ('186', '11', 'kinds', '广告类型', '', '1', '0', '0', 'defaul', '', '', 'select', 'array(\'options\'=>\'首页Banner|1\r\n友情链接|2\',\'fieldlength\'=>\'2\',\'fieldtype\'=>\'int\',\'default\' => \'1\',)', '0', '', '1', '0', '0');
INSERT INTO `field` VALUES ('187', '11', 'title', '广告标题', '', '1', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'40\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '2', '0', '0');
INSERT INTO `field` VALUES ('188', '11', 'image', '图片', '', '1', '0', '0', 'defaul', '', '', 'file', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '3', '0', '0');
INSERT INTO `field` VALUES ('189', '11', 'url', '链接地址', '', '1', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '4', '0', '0');
INSERT INTO `field` VALUES ('190', '11', 'sort', '排序', '', '1', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'2\', \'fieldtype\'=>\'smallint\', \'default\' => \'\')', '0', '', '5', '0', '0');
INSERT INTO `field` VALUES ('191', '11', 'addtime', '添加时间', '', '0', '0', '0', 'defaul', '', 'create_time', 'datetime', 'array(\'fieldlength\'=>\'11\', \'fieldtype\'=>\'int\', \'default\' => \'\')', '0', '', '7', '0', '0');
INSERT INTO `field` VALUES ('197', '11', 'status', '是否显示', '', '1', '0', '0', 'defaul', '', '', 'radio', 'array(\'options\'=>\'是|1\r\n否|0\',\'fieldlength\'=>\'2\',\'fieldtype\'=>\'int\',\'default\' => \'\',)', '0', '', '6', '0', '0');
INSERT INTO `field` VALUES ('225', '2', 'posid', '推荐位', '', '0', '0', '0', 'defaul', '', '', 'checkbox', 'array(\'options\'=>\'热门|1\r\n精华|2\r\n置顶|3\',\'fieldlength\'=>\'255\',\'fieldtype\'=>\'varchar\',\'default\' => \'\',)', '0', '', '10', '0', '0');
INSERT INTO `field` VALUES ('203', '12', 'catid', '分类选择', '', '0', '0', '0', 'defaul', '', '', 'catid', 'array(\'fieldlength\'=>\'2\', \'fieldtype\'=>\'int\', \'default\' => \'\')', '0', '', '1', '0', '0');
INSERT INTO `field` VALUES ('204', '12', 'title', '标题', '', '1', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '2', '0', '0');
INSERT INTO `field` VALUES ('205', '13', 'catid', '栏目选择', '栏目选择', '0', '0', '0', 'defaul', '', '', 'catid', 'array(\'fieldlength\'=>\'2\', \'fieldtype\'=>\'int\', \'default\' => \'\')', '0', '', '1', '2', '0');
INSERT INTO `field` VALUES ('206', '13', 'title', '标题', '请输入标题', '0', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '2', '1', '0');
INSERT INTO `field` VALUES ('207', '13', 'entitle', '英文标题', '请输入英文标题', '0', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '3', '0', '0');
INSERT INTO `field` VALUES ('208', '13', 'fontstyle', '标题加粗', '', '0', '0', '0', 'defaul', '', '', 'checkbox', 'array(\'options\'=>\'加粗|font-weight:bold;\',\'fieldlength\'=>\'255\',\'fieldtype\'=>\'varchar\',\'default\' => \'\',)', '0', '', '4', '0', '0');
INSERT INTO `field` VALUES ('209', '13', 'thumb', '缩略图', '', '0', '0', '0', 'defaul', '', '', 'file', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '5', '0', '0');
INSERT INTO `field` VALUES ('210', '13', 'keyword', '关键词', '', '0', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '6', '0', '0');
INSERT INTO `field` VALUES ('211', '13', 'description', '描述', '', '0', '0', '0', 'defaul', '', '', 'textarea', 'array(\'fieldlength\'=>\'\', \'fieldtype\'=>\'text\', \'default\' => \'\')', '0', '', '7', '0', '0');
INSERT INTO `field` VALUES ('212', '13', 'content', '内容', '', '0', '0', '0', 'defaul', '', 'container', 'textarea', 'array(\'fieldlength\'=>\'\', \'fieldtype\'=>\'mediumtext\', \'default\' => \'\')', '0', '', '8', '0', '0');
INSERT INTO `field` VALUES ('213', '13', 'status', '状态', '', '0', '0', '0', 'defaul', '', '', 'open', 'array(\'options\'=>\'开|关\',\'fieldlength\'=>\'2\',\'fieldtype\'=>\'int\',\'default\' => \'\',)', '0', '', '9', '0', '0');
INSERT INTO `field` VALUES ('214', '2', 'catid', '栏目分类', '请选择栏目', '1', '0', '0', 'defaul', '', '', 'catid', 'array(\'fieldlength\'=>\'2\', \'fieldtype\'=>\'int\', \'default\' => \'\')', '0', '', '1', '0', '1');
INSERT INTO `field` VALUES ('215', '2', 'title', '文章标题', '请输入标题', '1', '0', '0', 'defaul', '', '', 'text', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '2', '0', '1');
INSERT INTO `field` VALUES ('216', '2', 'titlecolor', '标题颜色', '请输入标题', '0', '0', '0', 'defaul', '', '', 'color', 'array(\'fieldlength\'=>\'255\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '3', '0', '0');
INSERT INTO `field` VALUES ('217', '2', 'fontstyle', '加粗', '请输入标题', '0', '0', '0', 'defaul', '', '', 'checkbox', 'array(\'options\'=>\'加粗|font-weight:bold;\',\'fieldlength\'=>\'255\',\'fieldtype\'=>\'varchar\',\'default\' => \'\',)', '0', '', '4', '0', '0');
INSERT INTO `field` VALUES ('218', '2', 'thumb', '缩略图', '', '0', '0', '0', 'defaul', '', '', 'file', 'array(\'options\'=>\'加粗|font-weight:bold;\',\'fieldlength\'=>\'255\',\'fieldtype\'=>\'varchar\',\'default\' => \'\',)', '0', '', '5', '0', '0');
INSERT INTO `field` VALUES ('219', '2', 'keywords', '关键字', '请输入关键字', '0', '0', '200', 'defaul', '长度在0-200个字符', '', 'text', 'array(\'fieldlength\'=>\'200\', \'fieldtype\'=>\'varchar\', \'default\' => \'\')', '0', '', '6', '0', '0');
INSERT INTO `field` VALUES ('220', '2', 'description', '描述', '请输入描述', '0', '0', '0', 'defaul', '', '', 'textarea', 'array(\'fieldlength\'=>\'\', \'fieldtype\'=>\'text\', \'default\' => \'\')', '0', '', '7', '0', '0');
INSERT INTO `field` VALUES ('221', '2', 'content', '内容', '请输入内容', '0', '0', '0', 'defaul', '', 'container', 'textarea', 'array(\'fieldlength\'=>\'\', \'fieldtype\'=>\'mediumtext\', \'default\' => \'\')', '0', '', '8', '0', '0');
INSERT INTO `field` VALUES ('222', '2', 'status', '发布状态', '', '0', '0', '0', 'defaul', '', '', 'open', 'array(\'options\'=>\'发布|审核\',\'fieldlength\'=>\'2\',\'fieldtype\'=>\'int\',\'default\' => \'0\',)', '0', '', '9', '0', '1');
INSERT INTO `field` VALUES ('223', '2', 'addtime', '发布时间', '', '0', '0', '0', 'defaul', '', 'create_time', 'datetime', 'array(\'fieldlength\'=>\'11\', \'fieldtype\'=>\'int\', \'default\' => \'\')', '0', '', '10', '0', '1');
INSERT INTO `field` VALUES ('224', '2', 'hits', '点击量', '', '0', '0', '0', 'defaul', '', 'create_time', 'text', 'array(\'fieldlength\'=>\'11\', \'fieldtype\'=>\'int\', \'default\' => \'0\')', '0', '', '11', '0', '0');

-- -----------------------------
-- Table structure for `manage`
-- -----------------------------
DROP TABLE IF EXISTS `manage`;
CREATE TABLE `manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `thumb` int(11) NOT NULL DEFAULT '1' COMMENT '管理员头像',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '修改时间',
  `login_time` int(11) DEFAULT NULL COMMENT '最后登录时间',
  `login_ip` varchar(100) DEFAULT NULL COMMENT '最后登录ip',
  `manage_cate_id` int(2) NOT NULL DEFAULT '1' COMMENT '管理员分组',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `nickname` (`nickname`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE,
  KEY `manage_cate_id` (`manage_cate_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `manage`
-- -----------------------------
INSERT INTO `manage` VALUES ('1', 'Tplay3', 'admin', '31c64b511d1e90fcda8519941c1bd660', '11', '1510885948', '1515046061', '1523510917', '127.0.0.1', '1');
INSERT INTO `manage` VALUES ('97', 'mingyu', 'mingyu', '545aaa8d240edc1c0a885576ffd8f7aa', '27', '1518060858', '1518060858', '0', '', '1');
INSERT INTO `manage` VALUES ('98', 'angle', 'Angle', '9eb2b9ad495a75f80f9cf67ed08bbaae', '28', '1518060944', '1518060944', '0', '', '20');
INSERT INTO `manage` VALUES ('99', 'test', 'test', '9eb2b9ad495a75f80f9cf67ed08bbaae', '29', '1521290405', '1521290405', '1521291534', '127.0.0.1', '20');

-- -----------------------------
-- Table structure for `manage_cate`
-- -----------------------------
DROP TABLE IF EXISTS `manage_cate`;
CREATE TABLE `manage_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `permissions` text COMMENT '权限菜单',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `desc` text COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `manage_cate`
-- -----------------------------
INSERT INTO `manage_cate` VALUES ('1', '超级管理员', '1,130,131,132,133,135,136,2,76,77,78,80,3,72,73,74,134,31,29,30,4,46,5,36,37,38,39,40,41,85,86,62,6,48,49,50,51,52,53,54,137,138,139,140,141,142,143', '0', '1515044109', '超级管理员，拥有最高权限！');
INSERT INTO `manage_cate` VALUES ('20', '管理员', '1,130,131,132,133,135,136,139,140,141,142,143', '0', '0', '22222');

-- -----------------------------
-- Table structure for `manage_log`
-- -----------------------------
DROP TABLE IF EXISTS `manage_log`;
CREATE TABLE `manage_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manage_menu_id` int(11) NOT NULL COMMENT '操作菜单id',
  `manage_id` int(11) NOT NULL COMMENT '操作者id',
  `ip` varchar(100) DEFAULT NULL COMMENT '操作ip',
  `operation_id` varchar(200) DEFAULT NULL COMMENT '操作关联id',
  `create_time` int(11) NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE,
  KEY `manage_id` (`manage_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=234 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `manage_log`
-- -----------------------------
INSERT INTO `manage_log` VALUES ('1', '49', '1', '127.0.0.1', '', '1517385408');
INSERT INTO `manage_log` VALUES ('2', '73', '1', '127.0.0.1', '25', '1517385478');
INSERT INTO `manage_log` VALUES ('3', '131', '1', '127.0.0.1', '', '1517385877');
INSERT INTO `manage_log` VALUES ('4', '133', '1', '127.0.0.1', '', '1517385994');
INSERT INTO `manage_log` VALUES ('5', '131', '1', '127.0.0.1', '', '1517386017');
INSERT INTO `manage_log` VALUES ('6', '131', '1', '127.0.0.1', '', '1517386017');
INSERT INTO `manage_log` VALUES ('7', '136', '1', '127.0.0.1', '101', '1517386138');
INSERT INTO `manage_log` VALUES ('8', '66', '1', '127.0.0.1', 'admin', '1517386405');
INSERT INTO `manage_log` VALUES ('9', '66', '25', '127.0.0.1', 'mingyu', '1517386598');
INSERT INTO `manage_log` VALUES ('10', '66', '1', '127.0.0.1', 'admin', '1517386638');
INSERT INTO `manage_log` VALUES ('11', '66', '1', '127.0.0.1', 'admin', '1517386991');
INSERT INTO `manage_log` VALUES ('12', '131', '1', '127.0.0.1', '', '1517387079');
INSERT INTO `manage_log` VALUES ('13', '131', '1', '127.0.0.1', '', '1517387079');
INSERT INTO `manage_log` VALUES ('14', '66', '1', '127.0.0.1', 'admin', '1517387782');
INSERT INTO `manage_log` VALUES ('15', '66', '1', '127.0.0.1', 'admin', '1517389311');
INSERT INTO `manage_log` VALUES ('16', '66', '1', '127.0.0.1', 'admin', '1517389876');
INSERT INTO `manage_log` VALUES ('17', '66', '1', '127.0.0.1', 'admin', '1517447344');
INSERT INTO `manage_log` VALUES ('18', '66', '1', '127.0.0.1', 'admin', '1517448280');
INSERT INTO `manage_log` VALUES ('19', '66', '1', '127.0.0.1', 'admin', '1517448778');
INSERT INTO `manage_log` VALUES ('20', '66', '1', '127.0.0.1', 'admin', '1517448998');
INSERT INTO `manage_log` VALUES ('21', '66', '1', '127.0.0.1', 'admin', '1517449111');
INSERT INTO `manage_log` VALUES ('22', '66', '1', '127.0.0.1', 'admin', '1517449997');
INSERT INTO `manage_log` VALUES ('23', '73', '1', '127.0.0.1', '1', '1517450214');
INSERT INTO `manage_log` VALUES ('24', '66', '1', '127.0.0.1', 'admin', '1517450773');
INSERT INTO `manage_log` VALUES ('25', '73', '1', '127.0.0.1', '1', '1517452874');
INSERT INTO `manage_log` VALUES ('26', '73', '1', '127.0.0.1', '26', '1517456758');
INSERT INTO `manage_log` VALUES ('27', '73', '1', '127.0.0.1', '27', '1517456934');
INSERT INTO `manage_log` VALUES ('28', '66', '1', '127.0.0.1', 'admin', '1517458060');
INSERT INTO `manage_log` VALUES ('29', '73', '1', '127.0.0.1', '28', '1517458677');
INSERT INTO `manage_log` VALUES ('30', '74', '1', '127.0.0.1', '28', '1517458717');
INSERT INTO `manage_log` VALUES ('31', '74', '1', '127.0.0.1', '27', '1517458719');
INSERT INTO `manage_log` VALUES ('32', '74', '1', '127.0.0.1', '26', '1517458721');
INSERT INTO `manage_log` VALUES ('33', '74', '1', '127.0.0.1', '25', '1517458723');
INSERT INTO `manage_log` VALUES ('34', '66', '1', '127.0.0.1', 'admin', '1517463655');
INSERT INTO `manage_log` VALUES ('35', '66', '1', '127.0.0.1', 'admin', '1517465639');
INSERT INTO `manage_log` VALUES ('36', '66', '1', '127.0.0.1', 'admin', '1517470113');
INSERT INTO `manage_log` VALUES ('37', '49', '1', '127.0.0.1', '', '1517473412');
INSERT INTO `manage_log` VALUES ('38', '66', '1', '127.0.0.1', 'admin', '1517534311');
INSERT INTO `manage_log` VALUES ('39', '73', '1', '127.0.0.1', '29', '1517534347');
INSERT INTO `manage_log` VALUES ('40', '77', '1', '127.0.0.1', '36', '1517536295');
INSERT INTO `manage_log` VALUES ('41', '66', '1', '127.0.0.1', 'admin', '1517541632');
INSERT INTO `manage_log` VALUES ('42', '66', '1', '127.0.0.1', 'admin', '1517542621');
INSERT INTO `manage_log` VALUES ('43', '66', '1', '127.0.0.1', 'admin', '1517549850');
INSERT INTO `manage_log` VALUES ('44', '74', '1', '127.0.0.1', '29', '1517556727');
INSERT INTO `manage_log` VALUES ('45', '66', '1', '127.0.0.1', 'admin', '1517557316');
INSERT INTO `manage_log` VALUES ('46', '66', '1', '127.0.0.1', 'admin', '1517557488');
INSERT INTO `manage_log` VALUES ('47', '66', '1', '127.0.0.1', 'admin', '1517564695');
INSERT INTO `manage_log` VALUES ('48', '66', '1', '127.0.0.1', 'admin', '1517792679');
INSERT INTO `manage_log` VALUES ('49', '66', '1', '127.0.0.1', 'admin', '1517820598');
INSERT INTO `manage_log` VALUES ('50', '66', '1', '127.0.0.1', 'admin', '1517878984');
INSERT INTO `manage_log` VALUES ('51', '66', '1', '127.0.0.1', 'admin', '1517881345');
INSERT INTO `manage_log` VALUES ('52', '66', '1', '127.0.0.1', 'admin', '1517883621');
INSERT INTO `manage_log` VALUES ('53', '66', '1', '127.0.0.1', 'admin', '1517890845');
INSERT INTO `manage_log` VALUES ('54', '66', '1', '127.0.0.1', 'admin', '1517898100');
INSERT INTO `manage_log` VALUES ('55', '66', '1', '127.0.0.1', 'admin', '1517905396');
INSERT INTO `manage_log` VALUES ('56', '66', '1', '127.0.0.1', 'admin', '1517966372');
INSERT INTO `manage_log` VALUES ('57', '66', '1', '127.0.0.1', 'admin', '1517973589');
INSERT INTO `manage_log` VALUES ('58', '66', '1', '127.0.0.1', 'admin', '1517976546');
INSERT INTO `manage_log` VALUES ('59', '78', '1', '127.0.0.1', '62', '1517976696');
INSERT INTO `manage_log` VALUES ('60', '78', '1', '127.0.0.1', '86', '1517976777');
INSERT INTO `manage_log` VALUES ('61', '78', '1', '127.0.0.1', '85', '1517976856');
INSERT INTO `manage_log` VALUES ('62', '78', '1', '127.0.0.1', '41', '1517976862');
INSERT INTO `manage_log` VALUES ('63', '78', '1', '127.0.0.1', '40', '1517976940');
INSERT INTO `manage_log` VALUES ('64', '78', '1', '127.0.0.1', '39', '1517977223');
INSERT INTO `manage_log` VALUES ('65', '66', '1', '127.0.0.1', 'admin', '1517977280');
INSERT INTO `manage_log` VALUES ('66', '49', '1', '127.0.0.1', '', '1517977288');
INSERT INTO `manage_log` VALUES ('67', '66', '1', '127.0.0.1', 'admin', '1517988651');
INSERT INTO `manage_log` VALUES ('68', '133', '1', '127.0.0.1', '', '1517994637');
INSERT INTO `manage_log` VALUES ('69', '131', '1', '127.0.0.1', '', '1517994741');
INSERT INTO `manage_log` VALUES ('70', '131', '1', '127.0.0.1', '', '1517994741');
INSERT INTO `manage_log` VALUES ('71', '66', '1', '127.0.0.1', 'admin', '1517995904');
INSERT INTO `manage_log` VALUES ('72', '66', '1', '127.0.0.1', 'admin', '1518054717');
INSERT INTO `manage_log` VALUES ('73', '66', '1', '127.0.0.1', 'admin', '1518055458');
INSERT INTO `manage_log` VALUES ('74', '73', '1', '127.0.0.1', '95', '1518059827');
INSERT INTO `manage_log` VALUES ('75', '73', '1', '127.0.0.1', '97', '1518060858');
INSERT INTO `manage_log` VALUES ('76', '73', '1', '127.0.0.1', '98', '1518060944');
INSERT INTO `manage_log` VALUES ('77', '66', '1', '127.0.0.1', 'admin', '1518062837');
INSERT INTO `manage_log` VALUES ('78', '66', '1', '127.0.0.1', 'admin', '1518070056');
INSERT INTO `manage_log` VALUES ('79', '49', '1', '127.0.0.1', '', '1518072703');
INSERT INTO `manage_log` VALUES ('80', '77', '1', '127.0.0.1', '37', '1518073012');
INSERT INTO `manage_log` VALUES ('81', '77', '1', '127.0.0.1', '37', '1518073235');
INSERT INTO `manage_log` VALUES ('82', '77', '1', '127.0.0.1', '144', '1518073308');
INSERT INTO `manage_log` VALUES ('83', '77', '1', '127.0.0.1', '145', '1518073357');
INSERT INTO `manage_log` VALUES ('84', '77', '1', '127.0.0.1', '144', '1518073388');
INSERT INTO `manage_log` VALUES ('85', '77', '1', '127.0.0.1', '146', '1518073431');
INSERT INTO `manage_log` VALUES ('86', '77', '1', '127.0.0.1', '147', '1518073498');
INSERT INTO `manage_log` VALUES ('87', '77', '1', '127.0.0.1', '148', '1518073578');
INSERT INTO `manage_log` VALUES ('88', '77', '1', '127.0.0.1', '147', '1518073595');
INSERT INTO `manage_log` VALUES ('89', '77', '1', '127.0.0.1', '149', '1518073660');
INSERT INTO `manage_log` VALUES ('90', '77', '1', '127.0.0.1', '150', '1518073799');
INSERT INTO `manage_log` VALUES ('91', '77', '1', '127.0.0.1', '151', '1518074424');
INSERT INTO `manage_log` VALUES ('92', '77', '1', '127.0.0.1', '152', '1518074488');
INSERT INTO `manage_log` VALUES ('93', '77', '1', '127.0.0.1', '153', '1518074536');
INSERT INTO `manage_log` VALUES ('94', '77', '1', '127.0.0.1', '154', '1518074574');
INSERT INTO `manage_log` VALUES ('95', '77', '1', '127.0.0.1', '155', '1518074620');
INSERT INTO `manage_log` VALUES ('96', '77', '1', '127.0.0.1', '156', '1518074698');
INSERT INTO `manage_log` VALUES ('97', '77', '1', '127.0.0.1', '157', '1518074741');
INSERT INTO `manage_log` VALUES ('98', '66', '1', '127.0.0.1', 'admin', '1518077542');
INSERT INTO `manage_log` VALUES ('99', '133', '1', '127.0.0.1', '', '1518077550');
INSERT INTO `manage_log` VALUES ('100', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('101', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('102', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('103', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('104', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('105', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('106', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('107', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('108', '133', '1', '127.0.0.1', '', '1518077727');
INSERT INTO `manage_log` VALUES ('109', '49', '1', '127.0.0.1', '', '1518077798');
INSERT INTO `manage_log` VALUES ('110', '66', '1', '127.0.0.1', 'admin', '1518138384');
INSERT INTO `manage_log` VALUES ('111', '66', '1', '127.0.0.1', 'admin', '1518141131');
INSERT INTO `manage_log` VALUES ('112', '66', '1', '127.0.0.1', 'admin', '1519804217');
INSERT INTO `manage_log` VALUES ('113', '66', '1', '127.0.0.1', 'admin', '1519806863');
INSERT INTO `manage_log` VALUES ('114', '66', '1', '127.0.0.1', 'admin', '1519998302');
INSERT INTO `manage_log` VALUES ('115', '77', '1', '127.0.0.1', '158', '1520002585');
INSERT INTO `manage_log` VALUES ('116', '77', '1', '127.0.0.1', '159', '1520002660');
INSERT INTO `manage_log` VALUES ('117', '77', '1', '127.0.0.1', '160', '1520004014');
INSERT INTO `manage_log` VALUES ('118', '66', '1', '127.0.0.1', 'admin', '1520005573');
INSERT INTO `manage_log` VALUES ('119', '66', '1', '127.0.0.1', 'admin', '1520064099');
INSERT INTO `manage_log` VALUES ('120', '66', '1', '127.0.0.1', 'admin', '1520067249');
INSERT INTO `manage_log` VALUES ('121', '66', '1', '127.0.0.1', 'admin', '1520074465');
INSERT INTO `manage_log` VALUES ('122', '66', '1', '127.0.0.1', 'admin', '1520083781');
INSERT INTO `manage_log` VALUES ('123', '66', '1', '127.0.0.1', 'admin', '1520661571');
INSERT INTO `manage_log` VALUES ('124', '66', '1', '127.0.0.1', 'admin', '1520668787');
INSERT INTO `manage_log` VALUES ('125', '66', '1', '127.0.0.1', 'admin', '1520745714');
INSERT INTO `manage_log` VALUES ('126', '66', '1', '127.0.0.1', 'admin', '1520824640');
INSERT INTO `manage_log` VALUES ('127', '66', '1', '127.0.0.1', 'admin', '1520833013');
INSERT INTO `manage_log` VALUES ('128', '77', '1', '127.0.0.1', '161', '1520836391');
INSERT INTO `manage_log` VALUES ('129', '66', '1', '127.0.0.1', 'admin', '1520840217');
INSERT INTO `manage_log` VALUES ('130', '66', '1', '127.0.0.1', 'admin', '1520847729');
INSERT INTO `manage_log` VALUES ('131', '49', '1', '127.0.0.1', '', '1520848844');
INSERT INTO `manage_log` VALUES ('132', '66', '1', '127.0.0.1', 'admin', '1520910011');
INSERT INTO `manage_log` VALUES ('133', '66', '1', '127.0.0.1', 'admin', '1520917865');
INSERT INTO `manage_log` VALUES ('134', '66', '1', '127.0.0.1', 'admin', '1520925421');
INSERT INTO `manage_log` VALUES ('135', '66', '1', '127.0.0.1', 'admin', '1520932722');
INSERT INTO `manage_log` VALUES ('136', '66', '1', '127.0.0.1', 'admin', '1520990248');
INSERT INTO `manage_log` VALUES ('137', '49', '1', '127.0.0.1', '', '1520990333');
INSERT INTO `manage_log` VALUES ('138', '66', '1', '127.0.0.1', 'admin', '1520998492');
INSERT INTO `manage_log` VALUES ('139', '66', '1', '127.0.0.1', 'admin', '1520998705');
INSERT INTO `manage_log` VALUES ('140', '66', '1', '127.0.0.1', 'admin', '1521006877');
INSERT INTO `manage_log` VALUES ('141', '66', '1', '127.0.0.1', 'admin', '1521014564');
INSERT INTO `manage_log` VALUES ('142', '66', '1', '127.0.0.1', 'admin', '1521021556');
INSERT INTO `manage_log` VALUES ('143', '66', '1', '127.0.0.1', 'admin', '1521076817');
INSERT INTO `manage_log` VALUES ('144', '66', '1', '127.0.0.1', 'admin', '1521084045');
INSERT INTO `manage_log` VALUES ('145', '66', '1', '127.0.0.1', 'admin', '1521092460');
INSERT INTO `manage_log` VALUES ('146', '77', '1', '127.0.0.1', '162', '1521094625');
INSERT INTO `manage_log` VALUES ('147', '66', '1', '127.0.0.1', 'admin', '1521095965');
INSERT INTO `manage_log` VALUES ('148', '66', '1', '127.0.0.1', 'admin', '1521103327');
INSERT INTO `manage_log` VALUES ('149', '66', '1', '127.0.0.1', 'admin', '1521104073');
INSERT INTO `manage_log` VALUES ('150', '66', '1', '127.0.0.1', 'admin', '1521162183');
INSERT INTO `manage_log` VALUES ('151', '66', '1', '127.0.0.1', 'admin', '1521169431');
INSERT INTO `manage_log` VALUES ('152', '66', '1', '127.0.0.1', 'admin', '1521191236');
INSERT INTO `manage_log` VALUES ('153', '53', '1', '127.0.0.1', '', '1521213013');
INSERT INTO `manage_log` VALUES ('154', '66', '1', '127.0.0.1', 'admin', '1521285050');
INSERT INTO `manage_log` VALUES ('155', '133', '1', '127.0.0.1', '', '1521285743');
INSERT INTO `manage_log` VALUES ('156', '66', '1', '127.0.0.1', 'admin', '1521290251');
INSERT INTO `manage_log` VALUES ('157', '73', '1', '127.0.0.1', '99', '1521290405');
INSERT INTO `manage_log` VALUES ('158', '66', '99', '127.0.0.1', 'test', '1521291534');
INSERT INTO `manage_log` VALUES ('159', '66', '1', '127.0.0.1', 'admin', '1521349961');
INSERT INTO `manage_log` VALUES ('160', '66', '1', '127.0.0.1', 'admin', '1521359710');
INSERT INTO `manage_log` VALUES ('161', '53', '1', '127.0.0.1', '', '1521509293');
INSERT INTO `manage_log` VALUES ('162', '66', '1', '127.0.0.1', 'admin', '1521515822');
INSERT INTO `manage_log` VALUES ('163', '66', '1', '127.0.0.1', 'admin', '1521525990');
INSERT INTO `manage_log` VALUES ('164', '66', '1', '127.0.0.1', 'admin', '1521533310');
INSERT INTO `manage_log` VALUES ('165', '66', '1', '127.0.0.1', 'admin', '1521537506');
INSERT INTO `manage_log` VALUES ('166', '66', '1', '127.0.0.1', 'admin', '1521594881');
INSERT INTO `manage_log` VALUES ('167', '66', '1', '127.0.0.1', 'admin', '1521602866');
INSERT INTO `manage_log` VALUES ('168', '66', '1', '127.0.0.1', 'admin', '1521610158');
INSERT INTO `manage_log` VALUES ('169', '49', '1', '127.0.0.1', '', '1521613722');
INSERT INTO `manage_log` VALUES ('170', '66', '1', '127.0.0.1', 'admin', '1521625418');
INSERT INTO `manage_log` VALUES ('171', '49', '1', '127.0.0.1', '', '1521625580');
INSERT INTO `manage_log` VALUES ('172', '66', '1', '127.0.0.1', 'admin', '1521680849');
INSERT INTO `manage_log` VALUES ('173', '66', '1', '127.0.0.1', 'admin', '1521693723');
INSERT INTO `manage_log` VALUES ('174', '131', '1', '127.0.0.1', '', '1521693832');
INSERT INTO `manage_log` VALUES ('175', '131', '1', '127.0.0.1', '', '1521693878');
INSERT INTO `manage_log` VALUES ('176', '131', '1', '127.0.0.1', '', '1521693878');
INSERT INTO `manage_log` VALUES ('177', '133', '1', '127.0.0.1', '', '1521693898');
INSERT INTO `manage_log` VALUES ('178', '66', '1', '127.0.0.1', 'admin', '1521696833');
INSERT INTO `manage_log` VALUES ('179', '66', '1', '127.0.0.1', 'admin', '1521701546');
INSERT INTO `manage_log` VALUES ('180', '66', '1', '127.0.0.1', 'admin', '1521709768');
INSERT INTO `manage_log` VALUES ('181', '66', '1', '127.0.0.1', 'admin', '1521766371');
INSERT INTO `manage_log` VALUES ('182', '66', '1', '127.0.0.1', 'admin', '1521773594');
INSERT INTO `manage_log` VALUES ('183', '66', '1', '127.0.0.1', 'admin', '1521780882');
INSERT INTO `manage_log` VALUES ('184', '66', '1', '127.0.0.1', 'admin', '1521792253');
INSERT INTO `manage_log` VALUES ('185', '49', '1', '127.0.0.1', '', '1521798478');
INSERT INTO `manage_log` VALUES ('186', '66', '1', '127.0.0.1', 'admin', '1522050970');
INSERT INTO `manage_log` VALUES ('187', '66', '1', '127.0.0.1', 'admin', '1522058211');
INSERT INTO `manage_log` VALUES ('188', '66', '1', '127.0.0.1', 'admin', '1522113449');
INSERT INTO `manage_log` VALUES ('189', '133', '1', '127.0.0.1', '', '1522114634');
INSERT INTO `manage_log` VALUES ('190', '66', '1', '127.0.0.1', 'admin', '1522122780');
INSERT INTO `manage_log` VALUES ('191', '66', '1', '127.0.0.1', 'admin', '1522144160');
INSERT INTO `manage_log` VALUES ('192', '49', '1', '127.0.0.1', '', '1522144201');
INSERT INTO `manage_log` VALUES ('193', '66', '1', '127.0.0.1', 'admin', '1522202862');
INSERT INTO `manage_log` VALUES ('194', '131', '1', '127.0.0.1', '', '1522203017');
INSERT INTO `manage_log` VALUES ('195', '131', '1', '127.0.0.1', '', '1522203469');
INSERT INTO `manage_log` VALUES ('196', '131', '1', '127.0.0.1', '', '1522203469');
INSERT INTO `manage_log` VALUES ('197', '131', '1', '127.0.0.1', '', '1522203511');
INSERT INTO `manage_log` VALUES ('198', '131', '1', '127.0.0.1', '', '1522203511');
INSERT INTO `manage_log` VALUES ('199', '133', '1', '127.0.0.1', '', '1522203897');
INSERT INTO `manage_log` VALUES ('200', '133', '1', '127.0.0.1', '', '1522203897');
INSERT INTO `manage_log` VALUES ('201', '133', '1', '127.0.0.1', '', '1522206018');
INSERT INTO `manage_log` VALUES ('202', '133', '1', '127.0.0.1', '', '1522206018');
INSERT INTO `manage_log` VALUES ('203', '133', '1', '127.0.0.1', '', '1522206018');
INSERT INTO `manage_log` VALUES ('204', '133', '1', '127.0.0.1', '', '1522206018');
INSERT INTO `manage_log` VALUES ('205', '133', '1', '127.0.0.1', '', '1522207897');
INSERT INTO `manage_log` VALUES ('206', '133', '1', '127.0.0.1', '', '1522207897');
INSERT INTO `manage_log` VALUES ('207', '133', '1', '127.0.0.1', '', '1522208241');
INSERT INTO `manage_log` VALUES ('208', '133', '1', '127.0.0.1', '', '1522208241');
INSERT INTO `manage_log` VALUES ('209', '66', '1', '127.0.0.1', 'admin', '1522210084');
INSERT INTO `manage_log` VALUES ('210', '66', '1', '127.0.0.1', 'admin', '1522217302');
INSERT INTO `manage_log` VALUES ('211', '49', '1', '127.0.0.1', '', '1522224350');
INSERT INTO `manage_log` VALUES ('212', '54', '1', '127.0.0.1', '1520746210', '1522224365');
INSERT INTO `manage_log` VALUES ('213', '54', '1', '127.0.0.1', '1520848816', '1522224369');
INSERT INTO `manage_log` VALUES ('214', '54', '1', '127.0.0.1', '1520990305', '1522224372');
INSERT INTO `manage_log` VALUES ('215', '54', '1', '127.0.0.1', '1521191245', '1522224376');
INSERT INTO `manage_log` VALUES ('216', '54', '1', '127.0.0.1', '1521364621', '1522224380');
INSERT INTO `manage_log` VALUES ('217', '54', '1', '127.0.0.1', '1521508666', '1522224384');
INSERT INTO `manage_log` VALUES ('218', '66', '1', '127.0.0.1', 'admin', '1522227124');
INSERT INTO `manage_log` VALUES ('219', '66', '1', '127.0.0.1', 'admin', '1522292106');
INSERT INTO `manage_log` VALUES ('220', '66', '1', '127.0.0.1', 'admin', '1522299311');
INSERT INTO `manage_log` VALUES ('221', '66', '1', '127.0.0.1', 'admin', '1522306280');
INSERT INTO `manage_log` VALUES ('222', '66', '1', '127.0.0.1', 'admin', '1522313807');
INSERT INTO `manage_log` VALUES ('223', '66', '1', '127.0.0.1', 'admin', '1522315353');
INSERT INTO `manage_log` VALUES ('224', '66', '1', '127.0.0.1', 'admin', '1522315587');
INSERT INTO `manage_log` VALUES ('225', '66', '1', '127.0.0.1', 'admin', '1522371869');
INSERT INTO `manage_log` VALUES ('226', '49', '1', '127.0.0.1', '', '1522377854');
INSERT INTO `manage_log` VALUES ('227', '66', '1', '127.0.0.1', 'admin', '1522379113');
INSERT INTO `manage_log` VALUES ('228', '66', '1', '127.0.0.1', 'admin', '1522386341');
INSERT INTO `manage_log` VALUES ('229', '66', '1', '127.0.0.1', 'admin', '1522386774');
INSERT INTO `manage_log` VALUES ('230', '66', '1', '127.0.0.1', 'admin', '1522630104');
INSERT INTO `manage_log` VALUES ('231', '66', '1', '127.0.0.1', 'admin', '1522743425');
INSERT INTO `manage_log` VALUES ('232', '66', '1', '127.0.0.1', 'admin', '1523332945');
INSERT INTO `manage_log` VALUES ('233', '66', '1', '127.0.0.1', 'admin', '1523510917');

-- -----------------------------
-- Table structure for `manage_menu`
-- -----------------------------
DROP TABLE IF EXISTS `manage_menu`;
CREATE TABLE `manage_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL COMMENT '模块',
  `controller` varchar(100) NOT NULL COMMENT '控制器',
  `function` varchar(100) NOT NULL COMMENT '方法',
  `parameter` varchar(50) DEFAULT NULL COMMENT '参数',
  `description` varchar(250) DEFAULT NULL COMMENT '描述',
  `is_display` int(1) NOT NULL DEFAULT '1' COMMENT '1显示在左侧菜单2只作为节点',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '1权限节点2普通节点',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '上级菜单0为顶级菜单',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `icon` varchar(100) DEFAULT NULL COMMENT '图标',
  `is_open` int(1) NOT NULL DEFAULT '0' COMMENT '0默认闭合1默认展开',
  `orders` int(11) NOT NULL DEFAULT '0' COMMENT '排序值，越小越靠前',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `controller` (`controller`) USING BTREE,
  KEY `function` (`function`) USING BTREE,
  KEY `is_display` (`is_display`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `manage_menu`
-- -----------------------------
INSERT INTO `manage_menu` VALUES ('1', '系统管理', 'Manage', 'Index', 'index', '', '管理软件的基础信息，包括个人的基本信息管理。', '1', '1', '0', '0', '0', 'fa-cogs', '0', '0');
INSERT INTO `manage_menu` VALUES ('2', '菜单管理', 'Manage', 'Menu', 'index', '', '菜单管理。', '1', '1', '0', '0', '0', 'fa-sitemap', '0', '0');
INSERT INTO `manage_menu` VALUES ('3', '会员管理', 'Manage', 'index', 'index', '', '后台管理员管理，包括后台权限组的管理。', '1', '2', '0', '1511015413', '1513558364', 'fa-user', '0', '2');
INSERT INTO `manage_menu` VALUES ('4', '日志管理', 'Manage', 'index', 'index', '', '日志管理。', '1', '2', '0', '1511940197', '1513396527', 'fa-book', '0', '4');
INSERT INTO `manage_menu` VALUES ('5', '门户管理', 'Manage', 'index', 'index', '', '门户内容管理', '1', '2', '0', '1511320705', '1513408714', 'fa-th', '0', '6');
INSERT INTO `manage_menu` VALUES ('6', '数据管理', 'Manage', 'index', 'index', '', '数据相关的管理。', '1', '2', '0', '1511940263', '1513402145', 'fa-cubes', '0', '5');
INSERT INTO `manage_menu` VALUES ('48', '数据库', 'Manage', 'databackup', 'index', '', '数据库管理', '1', '2', '6', '1511940334', '1513402218', 'fa-database', '0', '2');
INSERT INTO `manage_menu` VALUES ('52', '备份管理', 'Manage', 'databackup', 'importlist', '', '数据库备份文件管理。', '1', '2', '6', '1511940505', '1513402265', 'fa-bookmark', '0', '3');
INSERT INTO `manage_menu` VALUES ('49', '数据库备份', 'Manage', 'databackup', 'export', '', '数据库备份。', '2', '1', '48', '1511940383', '1513402229', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('50', '数据库优化', 'Manage', 'databackup', 'optimize', '', '数据库优化。', '2', '1', '48', '1511940422', '1513402239', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('51', '数据库修复', 'Manage', 'databackup', 'repair', '', '数据库修复', '2', '1', '48', '1511940450', '1513402248', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('53', '数据库备份还原', 'Manage', 'databackup', 'import', '', '数据库还原。', '2', '1', '52', '1511940554', '1513402275', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('54', '数据库备份删除', 'Manage', 'databackup', 'del', '', '数据库备份删除。', '2', '1', '52', '1511940587', '1513402284', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('76', '后台菜单', 'Manage', 'menu', 'index', '', '添加/修改菜单。', '1', '2', '2', '1513403248', '1513403248', 'fa-sliders', '0', '0');
INSERT INTO `manage_menu` VALUES ('77', '添加/修改菜单', 'Manage', 'menu', 'publish', '', '添加/修改菜单。', '2', '1', '76', '1513403367', '1513403367', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('78', '删除菜单', 'Manage', 'menu', 'delete', '', '删除菜单。', '2', '1', '76', '1513403393', '1513403393', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('80', '菜单排序', 'Manage', 'menu', 'orders', '', '后台菜单排序。', '2', '1', '76', '1513408418', '1513408418', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('36', '栏目列表', 'Manage', 'Category', 'index', '', '栏目列表', '1', '2', '5', '1511320748', '1513402018', 'fa-tags', '0', '0');
INSERT INTO `manage_menu` VALUES ('37', '添加分类', 'Manage', 'category', 'add', '', '添加分类页面。', '2', '1', '36', '1511320794', '1513402031', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('38', '删除分类', 'Manage', 'articlecate', 'delete', '', '删除分类操作。', '2', '1', '36', '1511320824', '1513402041', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('130', '基本设置', 'Manage', 'Index', 'system', '', '基本设置', '1', '1', '1', '0', '0', 'fa-desktop', '0', '0');
INSERT INTO `manage_menu` VALUES ('131', '添加/修改配置项', 'Manage', 'Index', 'Systemadd', '', '添加/修改配置项', '2', '1', '130', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('132', '配置页面切换', 'Manage', 'Index', 'Systempage', '', '配置页面切换', '2', '1', '130', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('133', '保存配置', 'Manage', 'Index', 'save', '', '保存配置', '2', '1', '130', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('72', '管理员', 'Manage', 'manage', 'index', '', '管理员列表。', '1', '2', '3', '1513402959', '1513402959', 'fa-user', '0', '1');
INSERT INTO `manage_menu` VALUES ('73', '添加/修改管理员', 'Manage', 'manage', 'publish', '', '添加/修改管理员。', '2', '1', '72', '1513403009', '1513403009', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('74', '删除管理员', 'Manage', 'manage', 'delete', '', '删除管理员。', '2', '1', '72', '1513403036', '1513403036', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('31', '角色分组', 'Manage', 'manage', 'manageCate', '', '管理员角色分组管理。', '1', '2', '3', '1511083098', '1513412856', 'fa-group', '0', '2');
INSERT INTO `manage_menu` VALUES ('46', '操作日志', 'Manage', 'manage', 'log', '', '管理员操作日志。', '1', '2', '4', '1511940227', '1513396537', 'fa-book', '0', '0');
INSERT INTO `manage_menu` VALUES ('29', '添加/修改权限分组', 'Manage', 'manage', 'manageCatePublish', '', '添加/修改管理员权限分组。', '2', '1', '31', '1511227503', '1513396481', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('30', '删除权限分组', 'Manage', 'manage', 'manageCateDelete', '', '删除后台管理员权限分组。', '2', '1', '31', '1511227568', '1513396473', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('134', '头像上传', 'manage', 'manage', 'avatar', '', '头像上传', '2', '1', '72', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('135', '配置列表', 'manage', 'index', 'lists', '', '配置列表', '2', '1', '130', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('136', '删除配置', 'manage', 'index', 'del', '', '删除配置', '2', '1', '130', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('137', '模板管理', 'manage', 'template', 'index', '', '模板管理', '1', '1', '0', '0', '0', 'fa-file-code-o', '0', '0');
INSERT INTO `manage_menu` VALUES ('138', '模板管理', 'manage', 'template', 'index', '', '', '1', '1', '137', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('139', '微信管理', 'manage', 'Wechat', 'index', '', '微信管理', '1', '1', '0', '0', '0', 'fa-comments-o', '0', '0');
INSERT INTO `manage_menu` VALUES ('140', '公众号管理', 'manage', 'Wechat', 'index', '', '公众号管理', '1', '1', '139', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('141', '菜单管理', 'manage', 'wechat', 'menu', '', '', '1', '1', '139', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('142', '消息素材', 'manage', 'wechat', 'materialmessage', '', '消息素材', '1', '1', '139', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('143', '回复设置', 'manage', 'wechat', 'replay', '', '回复设置', '1', '1', '139', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('66', '管理员登录', 'manage', 'common', 'login', '', '管理员登录。', '2', '2', '0', '1513061455', '1513402429', '', '0', '100');
INSERT INTO `manage_menu` VALUES ('144', '添加分类操作', 'manage', 'category', 'insert', '', '添加分类操作', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('145', '修改分类', 'manage', 'category', 'edit', '', '修改分类页面', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('146', '修改分类操作', 'manage', 'category', 'catUpdate', '', '修改分类操作', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('147', '单页添加/修改', 'manage', 'article', 'page', '', '单页添加/修改', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('148', '文章添加/修改', 'manage', 'article', 'publish', '', '文章添加/修改', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('149', '文章列表', 'manage', 'article', 'index', '', '文章列表', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('150', '删除', 'manage', 'article', 'delete', '', '删除文章', '2', '1', '36', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('151', '媒体文件', 'manage', 'template', 'images', '', '媒体文件', '2', '1', '137', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('152', '添加模板页面', 'manage', 'template', 'add', '', '添加模板页面', '2', '1', '138', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('153', '添加模板方法', 'manage', 'template', 'insert', '', '添加模板方法', '2', '1', '138', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('154', '修改页面', 'manage', 'template', 'edit', '', '修改页面', '2', '1', '138', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('155', '修改', 'manage', 'template', 'update', '', '修改模板', '2', '1', '138', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('156', '删除', 'manage', 'template', 'delete', '', '删除模板文件', '2', '1', '138', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('157', '删除媒体文件', 'manage', 'template', 'imgDel', '', '删除媒体文件', '2', '1', '138', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('158', '模型管理', 'manage', 'module', 'index', '', '模型管理', '1', '1', '0', '0', '0', 'fa-asterisk', '0', '0');
INSERT INTO `manage_menu` VALUES ('159', '模型列表', 'manage', 'module', 'index', '', '模型列表', '1', '1', '158', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('160', '留言管理', 'manage', 'message', 'index', '', '留言管理', '1', '1', '5', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('161', '广告管理', 'manage', 'ad', 'index', '', '广告管理', '1', '1', '5', '0', '0', '', '0', '0');
INSERT INTO `manage_menu` VALUES ('162', '产品管理', 'manage', 'product', 'index', '', '', '1', '1', '5', '0', '0', '', '0', '0');

-- -----------------------------
-- Table structure for `module`
-- -----------------------------
DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listfields` varchar(255) NOT NULL DEFAULT '',
  `setup` text NOT NULL,
  `listorder` smallint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `module`
-- -----------------------------
INSERT INTO `module` VALUES ('13', '单页模型', 'page', '单页模型', '0', '0', '*', '', '0', '1');
INSERT INTO `module` VALUES ('2', '文章模型', 'article', '文章模型', '0', '0', '*', '', '0', '1');
INSERT INTO `module` VALUES ('3', '图片模型', 'picture', '图片展示', '1', '0', '*', '', '0', '1');
INSERT INTO `module` VALUES ('4', '产品模型', 'productss', '产品展示', '1', '0', '*', '', '0', '1');
INSERT INTO `module` VALUES ('12', '产品', 'product', '', '0', '0', '*', '', '0', '1');
INSERT INTO `module` VALUES ('11', '广告模型', 'ad', '广告模型', '0', '0', '*', '', '0', '1');

-- -----------------------------
-- Table structure for `navigation`
-- -----------------------------
DROP TABLE IF EXISTS `navigation`;
CREATE TABLE `navigation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `enname` varchar(255) DEFAULT NULL COMMENT '英文名称',
  `pid` int(11) DEFAULT NULL COMMENT '父级ID',
  `url` varchar(255) DEFAULT NULL COMMENT '链接地址',
  `model` varchar(255) DEFAULT NULL COMMENT '1.文章列表;2.图文列表;3产品列表;4.单页面',
  `window` int(2) DEFAULT NULL COMMENT '是否在新窗口打开：_self、_blank',
  `sort` int(4) DEFAULT NULL COMMENT '排序:数字越小越靠前',
  `status` int(2) DEFAULT NULL COMMENT '是否显示：1.显示2.不显示',
  `addtime` int(12) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `page`
-- -----------------------------
DROP TABLE IF EXISTS `page`;
CREATE TABLE `page` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(2) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `entitle` varchar(255) NOT NULL,
  `fontstyle` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `content` mediumtext NOT NULL,
  `status` int(2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `page`
-- -----------------------------
INSERT INTO `page` VALUES ('1', '33', '组织架构', 'organization chart', 'font-weight:normal;', '/uploads/20180320\\1dac88a3ab17939419bedc0472246976.png', 'sdf', 'sdfsdf', '<p><img src=\"/uploads/20180323/1521773628382423.jpg\" title=\"1521773628382423.jpg\" alt=\"59db334f5448c[1].jpg\"/></p>', '1');
INSERT INTO `page` VALUES ('2', '34', '公司介绍', 'Information', 'font-weight:bold;', '', 'sdfsd', 'sdds', '<p><span style=\"font-size:12px;background-color:white;\"><span style=\"line-height:2;font-size:16px;\">&nbsp;</span><span style=\"line-height:2;font-size:16px;\"> </span><span style=\"line-height:2;font-size:16px;\">北京市文化置业有限公司（以下简称“文化置业”）成立于2013年7月，注册资本金2亿元人民币。作为北京市文投集团全资子公司，文化置业是文投集团落实首都文化产业发展规划,推动文化产业基础设施建设与文化创意产业园区、文化创意产业功能区建设与运营的重要平台。</span><br/></span></p><p style=\"font-size:14px;color:#333333;font-family:\"><span style=\"font-size:12px;background-color:white;\"><span style=\"line-height:3;\"><br/></span></span> </p><p>\n	<span style=\"font-size:16px;line-height:2;background-color:white;\"><span style=\"line-height:2;font-size:16px;\">&nbsp;\n &nbsp; &nbsp; \n根据文投集团战略部署，文化置业以“坚持文化市场导向、聚焦文化产业需求、助力文化企业发展、推动文化产业升级”为使命，坚持“立足北京、深耕京津冀、辐射全中国”战略构想，着力打造\n \n“文化创意产业园区开发建设与运营管理新模式”，并以文创园区开发、文创平台建设、文创产业投资、文创资产运营为重点，搭建“项目建设管理、投融资、资产运营管理、文化产业集成、综合管理服务”五大平台，努力实现社会效益与经济效益的双丰收。</span></span> </p><p>\n	<span style=\"font-size:12px;background-color:white;\"><span style=\"line-height:36px;\"><br/></span> </span><span style=\"font-size:16px;line-height:2;background-color:white;\"><span style=\"line-height:2;font-size:16px;\">&nbsp;\n &nbsp; &nbsp; \n文化置业首个文创产业园项目—文化都汇，矗立于北京大兴国家新媒体产业基地，总建筑面积约13.8万平方米。项目以前瞻的规划设计、周全的商务配套、强有力的扶持政策，构建文化产业生态圈，立势中国文化产业创新之作。文化置业开发建设的北京文化产权交易中心，总建筑面积6.1万平方米，位于北京前门，是经北京市政府批准并重点打造的一个立足北京、面向全球，从事文化产权要素、资源交易服务的综合性、标准化文化产权交易平台。北京宋庄艺术小镇项目坐落在中国北京市城市副中心北侧2公里、宋庄文化创意产业集聚区内，总用地面积13.70万平方米，拟建设中国艺术品交易中心（艺博会会址），建成后将成为全球性的集艺术品创作、展览展示、交易交流为一体的国际综合平台。公司还储备了一批前景好、潜力大、极具升值空间的优质项目,今后将择机启动开发建设。</span></span> </p><p>\n	<span style=\"font-size:12px;background-color:white;\"><span style=\"line-height:36px;\"><br/></span> </span><span style=\"font-size:12px;line-height:1.5;background-color:white;\"><span style=\"line-height:2;font-size:16px;\">&nbsp; &nbsp; &nbsp; 善建者立，善营者久。北京市文化置业有限公司愿意与您一起，携手共创辉煌的未来。</span></span></p><p><br/></p>', '1');
INSERT INTO `page` VALUES ('3', '36', '企业文化', 'Our corporate culture', '', '', '月月月月', '月月月枯', '<p>月月</p>', '1');
INSERT INTO `page` VALUES ('4', '2', '关于我们', 'ABOUT US', '', '/public/themes/Home/images/tu2.jpg', 'ss', '北京市文化置业有限公司成立于2013年7月，注册资本人民币2亿元', '<p><span style=\"color: rgb(255, 0, 0); font-size: 18px;\"><strong>北京市文化置业有限公司</strong></span>成立于2013年7月，注册资本人民币2亿元</p><p>公司隶属于北京市文化投资发展集团有限责任公司,是北京市文化投资发展集团有限责任公司落实首都文化产业发展规划 推动文化产业基础设施建设与文化创意产业园区、文化创意产业功能区建设与运营的重要平台</p>', '1');
INSERT INTO `page` VALUES ('5', '35', '领导致辞', '', '', '', '', '', '<p style=\"\\&quot;\\\\&quot;&quot;font-size:14px;color:#333333;font-family:\\\\\\\\\\\\\\\\&quot;\\\\\\\\&quot;&quot;\\\\&quot;\\&quot;\"><span style=\"\\&quot;line-height:2;font-size:16px;\\&quot;\">中国梦正在推动着中华文化复兴。在这个美好的时代，文化置业应运而生。</span> \n	</p><p><br/></p><p style=\"\\&quot;\\\\&quot;\\\\\\\\&quot;\\\\\\\\\\\\\\\\&quot;font-size:14px;color:#333333;font-family:\\\\\\\\\\\\\\\\&quot;\\\\\\\\&quot;\\\\&quot;\\&quot;\"><span style=\"\\&quot;line-height:2;font-size:16px;\\&quot;\">依托文投集团的雄厚实力，文化置业以服务首都经济发展，助推文化产业繁荣为使命，为首都文化产业发展贡献应有的力量。</span> </p><p><br/></p><p style=\"\\&quot;\\\\&quot;\\\\\\\\&quot;\\\\\\\\\\\\\\\\&quot;font-size:14px;color:#333333;font-family:\\\\\\\\\\\\\\\\&quot;\\\\\\\\&quot;\\\\&quot;\\&quot;\"><span style=\"\\&quot;line-height:2;font-size:16px;\\&quot;\">我们秉承变革与创新，抓住机遇，勇立潮头，不断整合资源，以精心打造的产品和服务，向文化产业倾注我们的热情和智慧。</span> \n	</p><p><br/></p><p style=\"\\&quot;\\\\&quot;\\\\\\\\&quot;\\\\\\\\\\\\\\\\&quot;font-size:14px;color:#333333;font-family:\\\\\\\\\\\\\\\\&quot;\\\\\\\\&quot;\\\\&quot;\\&quot;\"><span style=\"\\&quot;line-height:2;font-size:16px;\\&quot;\">产业致胜，文化致远，我们正沐浴着文化产业高速发展的阳光。展望未来，浪潮澎湃而百舸争流，峰峦起伏却万山红遍。 文化置业愿意和您一道，迎接全面复兴的盛世中华！</span> </p><p><br/></p>', '1');
INSERT INTO `page` VALUES ('6', '37', '发展历程', '', '', '', '', '', '<p>wwwwww<br/></p>', '0');
INSERT INTO `page` VALUES ('7', '50', '人才理念', '', '', '', '', '', '<p>公司人才理念： &nbsp;忠诚 &nbsp; &nbsp; &nbsp; 专业 &nbsp; &nbsp; &nbsp; 进取 &nbsp; &nbsp; &nbsp; 廉洁</p>', '1');
INSERT INTO `page` VALUES ('8', '51', '工作机会', '', '', '', '', '', '<p>sdfsdfsdf<br/></p>', '1');
INSERT INTO `page` VALUES ('9', '41', '产业投资', 'INTRODUCE', '', '', '', '', '<p><span style=\"font-size:16px;\">公司致力于打通文化产业与资本市场的融资通道，为文创产业功能区及文化园区提供全方位的投融资服务。通过现代化金融手段，开展股权、债权融资业务，为入驻企业提供金融服务，为文化企业健康发展搭建平台。</span><span style=\"line-height:1.5;font-size:16px;\">公司主要采取“以租代投、以售代投”的模式为文创企业提供投融资服务，采用“以投代建”的模式为文创功能区建设提供投融资服务。</span></p>', '1');
INSERT INTO `page` VALUES ('10', '45', '监督举报', '', '', '', '', '', '<p>感谢您关注<em>A Letter of Thanks</em></p><p>\n	</p><p>\n	<span style=\"color:#333333;font-size:16px;\">为加强我公司监督机制建设，我公司设立党支部纪检小组对公司各项违规事项进行监督，恳请各投标单位及个人提供项目招标、施工建设等工作中的违规情况或线索。如发现人员有投标单位出现围标、陪标、串标等违规行为，以及我司工作人员索贿、受贿或参与暗箱操作等违规行为，请将详情、线索及意见通过电话或邮箱提供给我司党支部纪检小组，以便我司核实和查处。谢谢</span><br/><br/>\n	 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>\n	</p><p>举报方式<em>Report way</em></p><p>\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;	</p><p>\n	<span style=\"font-size:16px;\">通信地址：北京市海淀区厂洼中街66号英泰科技大厦二层</span> </p><p>\n	<span style=\"font-size:16px;\">邮编：100089</span> </p><p>\n	<span style=\"font-size:16px;\">举报电话：010-68960700-843</span> </p><p>\n	<span style=\"font-size:16px;\">网上举报：jijianlianjie@sohu.com</span> </p><p><br/></p>', '1');

-- -----------------------------
-- Table structure for `product`
-- -----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(2) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wx_auth`
-- -----------------------------
DROP TABLE IF EXISTS `wx_auth`;
CREATE TABLE `wx_auth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `authorizer_appid` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺的appid  授权之后不用刷新',
  `authorizer_refresh_token` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺授权之后的刷新token，每月刷新',
  `authorizer_access_token` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺的公众号token，只有2小时',
  `func_info` varchar(1000) NOT NULL DEFAULT '' COMMENT '授权项目',
  `nick_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公众号昵称',
  `head_img` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号头像url',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公众号原始账号',
  `alias` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号原始名称',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号二维码url',
  `auth_time` int(11) DEFAULT '0' COMMENT '授权时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=8192 COMMENT='店铺(实例)微信公众账号授权';


-- -----------------------------
-- Table structure for `wx_config`
-- -----------------------------
DROP TABLE IF EXISTS `wx_config`;
CREATE TABLE `wx_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `instance_id` int(11) NOT NULL DEFAULT '1' COMMENT '实例ID',
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT '配置项WCHAT,QQ,WPAY,ALIPAY...',
  `value` varchar(1000) NOT NULL DEFAULT '' COMMENT '配置值json',
  `desc` varchar(1000) NOT NULL DEFAULT '' COMMENT '描述',
  `is_use` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否启用 1启用 0不启用',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `modify_time` int(11) DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=963 COMMENT='第三方配置表';

-- -----------------------------
-- Records of `wx_config`
-- -----------------------------
INSERT INTO `wx_config` VALUES ('1', '0', 'WCHAT', '{\"APP_KEY\":\"\",\"APP_SECRET\":\"\",\"AUTHORIZE\":\"http:\\/\\/b2c1.01.niushop.com.cn\",\"CALLBACK\":\"http:\\/\\/b2c1.01.niushop.com.cn\\/wap\\/Login\\/callback\"}', '微信', '0', '1488350947', '1497105440');
INSERT INTO `wx_config` VALUES ('2', '0', 'SHOPWCHAT', '{\"appid\":\"dfdsfdsf90bc7b7a34234\",\"appsecret\":\"e5147ce07128asdfds222f628b5c3fe1af2ea5797\",\"token\":\"dffdf2233\"}', '', '1', '1497088090', '1517560819');

-- -----------------------------
-- Table structure for `wx_default_replay`
-- -----------------------------
DROP TABLE IF EXISTS `wx_default_replay`;
CREATE TABLE `wx_default_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关注时回复';

-- -----------------------------
-- Records of `wx_default_replay`
-- -----------------------------
INSERT INTO `wx_default_replay` VALUES ('3', '0', '3', '0', '1517293977', '0');

-- -----------------------------
-- Table structure for `wx_fans`
-- -----------------------------
DROP TABLE IF EXISTS `wx_fans`;
CREATE TABLE `wx_fans` (
  `fans_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '粉丝ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员编号ID',
  `source_uid` int(11) NOT NULL DEFAULT '0' COMMENT '推广人uid',
  `instance_id` int(11) NOT NULL COMMENT '店铺ID',
  `nickname` varchar(255) NOT NULL COMMENT '昵称',
  `nickname_decode` varchar(255) DEFAULT '',
  `headimgurl` varchar(500) NOT NULL DEFAULT '' COMMENT '头像',
  `sex` smallint(6) NOT NULL DEFAULT '1' COMMENT '性别',
  `language` varchar(20) NOT NULL DEFAULT '' COMMENT '用户语言',
  `country` varchar(60) NOT NULL DEFAULT '' COMMENT '国家',
  `province` varchar(255) NOT NULL DEFAULT '' COMMENT '省',
  `city` varchar(255) NOT NULL DEFAULT '' COMMENT '城市',
  `district` varchar(255) NOT NULL DEFAULT '' COMMENT '行政区/县',
  `openid` varchar(255) NOT NULL DEFAULT '' COMMENT '用户的标识，对当前公众号唯一     用户的唯一身份ID',
  `unionid` varchar(255) NOT NULL DEFAULT '' COMMENT '粉丝unionid',
  `groupid` int(11) NOT NULL DEFAULT '0' COMMENT '粉丝所在组id',
  `is_subscribe` bigint(1) NOT NULL DEFAULT '1' COMMENT '是否订阅',
  `memo` varchar(255) NOT NULL COMMENT '备注',
  `subscribe_date` int(11) DEFAULT '0' COMMENT '订阅时间',
  `unsubscribe_date` int(11) DEFAULT '0' COMMENT '解订阅时间',
  `update_date` int(11) DEFAULT '0' COMMENT '粉丝信息最后更新时间',
  PRIMARY KEY (`fans_id`),
  KEY `IDX_sys_weixin_fans_openid` (`openid`),
  KEY `IDX_sys_weixin_fans_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 COMMENT='微信公众号获取粉丝列表';


-- -----------------------------
-- Table structure for `wx_follow_replay`
-- -----------------------------
DROP TABLE IF EXISTS `wx_follow_replay`;
CREATE TABLE `wx_follow_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关注时回复';

-- -----------------------------
-- Records of `wx_follow_replay`
-- -----------------------------
INSERT INTO `wx_follow_replay` VALUES ('3', '0', '3', '0', '1517292987', '0');

-- -----------------------------
-- Table structure for `wx_key_replay`
-- -----------------------------
DROP TABLE IF EXISTS `wx_key_replay`;
CREATE TABLE `wx_key_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `key` varchar(255) NOT NULL COMMENT '关键词',
  `match_type` tinyint(4) NOT NULL COMMENT '匹配类型1模糊匹配2全部匹配',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关键词回复';

-- -----------------------------
-- Records of `wx_key_replay`
-- -----------------------------
INSERT INTO `wx_key_replay` VALUES ('1', '0', '你好', '1', '2', '0', '1512464471', '0');
INSERT INTO `wx_key_replay` VALUES ('3', '0', '333', '1', '3', '0', '1517293956', '0');

-- -----------------------------
-- Table structure for `wx_media`
-- -----------------------------
DROP TABLE IF EXISTS `wx_media`;
CREATE TABLE `wx_media` (
  `media_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '图文消息id',
  `title` varchar(100) DEFAULT NULL,
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '实例id店铺id',
  `type` varchar(255) NOT NULL DEFAULT '1' COMMENT '类型1文本(项表无内容) 2单图文 3多图文',
  `sort` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) DEFAULT '0' COMMENT '创建日期',
  `modify_time` int(11) DEFAULT '0' COMMENT '修改日期',
  PRIMARY KEY (`media_id`),
  UNIQUE KEY `id` (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1170;

-- -----------------------------
-- Records of `wx_media`
-- -----------------------------
INSERT INTO `wx_media` VALUES ('1', '欢迎您来到CLTPHP官方公众号大世界！', '0', '1', '0', '1512551413', '0');
INSERT INTO `wx_media` VALUES ('2', '你好，欢迎来到CLTPHP的世界！', '0', '1', '0', '1512550726', '0');
INSERT INTO `wx_media` VALUES ('3', 'CLTPHP内容管理系统', '0', '2', '0', '1512550547', '0');
INSERT INTO `wx_media` VALUES ('4', 'CLTPHP内容管理系统5.2.2发布', '0', '3', '0', '1512551330', '0');

-- -----------------------------
-- Table structure for `wx_media_item`
-- -----------------------------
DROP TABLE IF EXISTS `wx_media_item`;
CREATE TABLE `wx_media_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `media_id` int(11) NOT NULL COMMENT '图文消息id',
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(50) NOT NULL COMMENT '作者',
  `cover` varchar(200) NOT NULL COMMENT '图文消息封面',
  `show_cover_pic` tinyint(4) NOT NULL DEFAULT '1' COMMENT '封面图片显示在正文中',
  `summary` text,
  `content` text NOT NULL COMMENT '正文',
  `content_source_url` varchar(200) NOT NULL DEFAULT '' COMMENT '图文消息的原文地址，即点击“阅读原文”后的URL',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序号',
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT '阅读次数',
  PRIMARY KEY (`id`),
  KEY `id` (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=712;

-- -----------------------------
-- Records of `wx_media_item`
-- -----------------------------
INSERT INTO `wx_media_item` VALUES ('28', '3', 'CLTPHP内容管理系统', 'cltphp', '/uploads/20171206/6dfec00133ee42c5c33cea8ab0cfad8f.png', '1', 'CLTPHP内容管理系统，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。', '<p style=\"text-indent: 2em;\"><span style=\"text-indent: 2em;\">虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。</span><br/></p><p style=\"text-indent: 2em;\"><br/></p><p style=\"text-indent: 2em;\">CLTPHP采用了优美的layui框架，一面极简，一面丰盈。加上angular Js，让数据交互变得更为简洁直白。用最基础的代码，实现最强大的效果，让你欲罢不能！</p><p style=\"text-indent: 2em;\"><br/></p><p style=\"text-indent: 2em;\">CLTPHP采用的ThinkPHP5为基础框架，从而使得CLTPHP的拓展性变的极为强大。从模型构造到栏目建立，再到前台展示，一气呵成，网站后台一条龙式操作，让小白用户能快速掌握CLTPHP管理系统的核心操作，让小白开发者能更好的理解CLTPHP的核心构建价值。</p><p><br/></p>', 'http://www.cltphp.com/', '0', '6');
INSERT INTO `wx_media_item` VALUES ('29', '2', '你好，欢迎来到CLTPHP的世界！', '', '', '0', '', '', '', '0', '0');
INSERT INTO `wx_media_item` VALUES ('39', '4', 'CLTPHP内容管理系统5.2.2发布', 'chichu', '/uploads/20171206/91febfbe3eaaa412ba6b54ca4164402d.jpg', '1', '这是一篇多图文', '<h4 style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-weight: normal; font-stretch: inherit; font-size: 22px; line-height: inherit; font-family: \">CLTPHP5.2.2发布</h4><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; vertical-align: baseline; margin: 0px; padding: 0px;\">修改bug若干</span></p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\">下载地址：</span><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\"><a href=\"http://qiniu.cltphp.com/cltphp5.2.2.zip\" target=\"_self\" title=\"CLTPHP5.2.2\" style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px; text-decoration: none;\">CLTPHP5.2.2</span></a></span></span></p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\">补丁地址：</span><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px; text-decoration: none;\"><a href=\"http://qiniu.cltphp.com/CLTPHP5.2.1%E5%88%B05.2.2%E8%A1%A5%E4%B8%81.zip\" target=\"_self\" style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;\">CLTPHP5.2.1到5.2.2升级</a></span></span></span></p>', 'http://www.cltphp.com/newsInfo-44-5.html', '0', '2');
INSERT INTO `wx_media_item` VALUES ('40', '4', '给我们一点点时间 我们给你一个新突破', 'chichu', '/uploads/20171206/18fd882e982e07e7b35dac5b962ab393.jpg', '0', '给我们一点点时间 我们给你一个新突破', '<p><span style=\"color: rgb(102, 102, 102); font-family: \">说实话，最近这段时间我们太忙了</span><img src=\"http://img.baidu.com/hi/jx2/j_0016.gif\"/><span style=\"color: rgb(102, 102, 102); font-family: \">，cltphp的开发，甚至可以说是搁浅了一段时间。不过，各位请耐心等待一下啊，给我们一点点时间，或许不止一点点，我们给你一个新突破。</span></p>', 'http://www.cltphp.com/newsInfo-45-5.html', '0', '4');
INSERT INTO `wx_media_item` VALUES ('41', '4', 'CLTPHP操作开发手册已完全更新', 'chichu', '/uploads/20171206/db19ac0c46a3ffd4ebf94028024d3036.jpg', '1', 'CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。', '<p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">喜欢的朋友可以购买参考</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">手册地址：<a href=\"https://www.kancloud.cn/chichu/cltphp/\" target=\"_self\">https://www.kancloud.cn/chichu/cltphp/</a></p><p><br/></p>', 'http://www.cltphp.com/newsInfo-16-5.html', '0', '4');
INSERT INTO `wx_media_item` VALUES ('42', '1', '欢迎您来到CLTPHP官方公众号大世界！', '', '', '0', '', '', '', '0', '0');
INSERT INTO `wx_media_item` VALUES ('45', '5', 'CLTPHP操作开发手册已完全更新', 'chichu', '/uploads/20171206/463cc15ed856b237e4241c1cc40b768c.png', '0', 'CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。', '<p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;\">CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">喜欢的朋友可以购买参考</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;\">同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;\">手册地址：https://www.kancloud.cn/chichu/cltphp/</p><p><br/></p>', 'https://www.kancloud.cn/chichu/cltphp', '0', '0');
INSERT INTO `wx_media_item` VALUES ('47', '8', 'erwerwer', 'wer', '/uploads/20180129/5e0b555608a1899155e5d74e98ad49ec.png', '0', 'wer', '<p>wer</p>', '', '0', '0');
INSERT INTO `wx_media_item` VALUES ('48', '8', 'werwer', 'werwe', '/uploads/20180129/5c3d8868239b449223b6fd96d13025fa.jpg', '0', '35345345345', '<p>wrwerw</p>', '', '0', '0');
INSERT INTO `wx_media_item` VALUES ('49', '9', 'erwerwerwer', '', '', '0', '', '', '', '0', '0');
INSERT INTO `wx_media_item` VALUES ('51', '8', '3', '33333333333333333333', '/uploads/20180131/22fcb8930b7224c1d517c10dc2ea87fa.png', '0', '3333333333333', '<p>33333333333</p>', '', '0', '0');
INSERT INTO `wx_media_item` VALUES ('52', '8', '33', '333333333333', '/uploads/20180131/e3f88761f208384c5527803d09ab555e.png', '0', '33333', '<p>333333333333333</p>', '', '0', '0');

-- -----------------------------
-- Table structure for `wx_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wx_menu`;
CREATE TABLE `wx_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `menu_name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `ico` varchar(32) NOT NULL DEFAULT '' COMMENT '菜图标单',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父菜单',
  `menu_event_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1普通url 2 图文素材 3 功能',
  `media_id` int(11) NOT NULL DEFAULT '0' COMMENT '图文消息ID',
  `menu_event_url` varchar(255) NOT NULL DEFAULT '' COMMENT '菜单url',
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT '触发数',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_date` int(11) DEFAULT '0' COMMENT '创建日期',
  `modify_date` int(11) DEFAULT '0' COMMENT '修改日期',
  PRIMARY KEY (`menu_id`),
  KEY `IDX_biz_shop_menu_orders` (`sort`),
  KEY `IDX_biz_shop_menu_shopId` (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 COMMENT='微设置->微店菜单';

-- -----------------------------
-- Records of `wx_menu`
-- -----------------------------
INSERT INTO `wx_menu` VALUES ('10', '0', 'FDDS', '', '0', '2', '0', 'http://www.baidu.com/2', '0', '1', '1517217010', '1522388198');
INSERT INTO `wx_menu` VALUES ('11', '0', '菜单名称', '', '0', '2', '0', '', '0', '3', '1517217053', '1522388198');
INSERT INTO `wx_menu` VALUES ('12', '0', 'SDWE', '', '0', '2', '0', '', '0', '2', '1517217061', '1522388198');
INSERT INTO `wx_menu` VALUES ('13', '0', 'SDFCED', '', '11', '1', '0', 'http://www.baidu.com/', '0', '1', '1517217714', '1522311669');
INSERT INTO `wx_menu` VALUES ('14', '0', 'LJSD', '', '11', '2', '0', 'http://www.baidu.com/', '0', '3', '1517217715', '1522311670');
INSERT INTO `wx_menu` VALUES ('15', '0', 'YMLF', '', '11', '1', '0', 'http://www.baidu.com/', '0', '2', '1517217715', '1522311670');
INSERT INTO `wx_menu` VALUES ('16', '0', 'RWERWER', '', '11', '1', '0', 'http://www.baidu.com/', '0', '5', '1517217716', '1522311670');
INSERT INTO `wx_menu` VALUES ('17', '0', 'ERWERD', '', '11', '1', '0', 'http://www.baidu.com/', '0', '4', '1517217716', '1522311670');

-- -----------------------------
-- Table structure for `wx_user`
-- -----------------------------
DROP TABLE IF EXISTS `wx_user`;
CREATE TABLE `wx_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '表id',
  `uid` int(11) NOT NULL COMMENT 'uid',
  `wxname` varchar(60) NOT NULL COMMENT '公众号名称',
  `aeskey` varchar(256) NOT NULL DEFAULT '' COMMENT 'aeskey',
  `encode` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'encode',
  `appid` varchar(50) NOT NULL DEFAULT '' COMMENT 'appid',
  `appsecret` varchar(50) NOT NULL DEFAULT '' COMMENT 'appsecret',
  `wxid` varchar(64) NOT NULL COMMENT '公众号原始ID',
  `weixin` char(64) NOT NULL COMMENT '微信号',
  `token` char(255) NOT NULL COMMENT 'token',
  `w_token` varchar(150) NOT NULL DEFAULT '' COMMENT '微信对接token',
  `create_time` int(11) NOT NULL COMMENT 'create_time',
  `updatetime` int(11) NOT NULL COMMENT 'updatetime',
  `tplcontentid` varchar(2) NOT NULL COMMENT '内容模版ID',
  `share_ticket` varchar(150) NOT NULL COMMENT '分享ticket',
  `share_dated` char(15) NOT NULL COMMENT 'share_dated',
  `authorizer_access_token` varchar(200) NOT NULL COMMENT 'authorizer_access_token',
  `authorizer_refresh_token` varchar(200) NOT NULL COMMENT 'authorizer_refresh_token',
  `authorizer_expires` char(10) NOT NULL COMMENT 'authorizer_expires',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `web_access_token` varchar(200) NOT NULL COMMENT '网页授权token',
  `web_refresh_token` varchar(200) NOT NULL COMMENT 'web_refresh_token',
  `web_expires` int(11) NOT NULL COMMENT '过期时间',
  `menu_config` text COMMENT '菜单',
  `wait_access` tinyint(1) DEFAULT '0' COMMENT '微信接入状态,0待接入1已接入',
  `concern` varchar(225) DEFAULT '' COMMENT '关注回复',
  `default` varchar(225) DEFAULT '' COMMENT '默认回复',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `uid_2` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='微信公共帐号';

-- -----------------------------
-- Records of `wx_user`
-- -----------------------------
INSERT INTO `wx_user` VALUES ('1', '0', 'CLTPHP', '', '0', 'wx08c8be078e00b88b', '2e6f2d97d60582f21111be7862d14ddc', 'gh_8aacbef4e497', 'chichu12345', 'sdfdsfdsfdsf', 'cltphp', '0', '0', '', '', '', '', '', '', '1', 'eY9W4LLdISpE3UtTfuodgz1HJdBYCMbzZWkiLEhF0Nzvzv2q2DtGIV5h7CPrc0Nd4_kJgKN_FdM3kNaCxfFC1wmu6JLnNoOrmMuy3FK2AhMDLCbAGAXFW', '', '1504242136', '0', '0', '欢迎来到CLTPHP！CLTPHP采用ThinkPHP5作为基础框架，同时采用Layui作为后台界面，使得CLTPHP适用与大型企业网站、个人博客论坛、企业网站、手机网站的定制开发。更高效、更快捷的进行定制开发一直是CLTPHP追求的价值。', '亲！您可以输入关键词来获取您想要知道的内容。（例：手册）');

-- -----------------------------
-- Table structure for `wx_user_msg`
-- -----------------------------
DROP TABLE IF EXISTS `wx_user_msg`;
CREATE TABLE `wx_user_msg` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `msg_type` varchar(255) NOT NULL,
  `content` text,
  `is_replay` int(11) NOT NULL DEFAULT '0' COMMENT '是否回复',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信用户消息表';


-- -----------------------------
-- Table structure for `wx_user_msg_replay`
-- -----------------------------
DROP TABLE IF EXISTS `wx_user_msg_replay`;
CREATE TABLE `wx_user_msg_replay` (
  `replay_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msg_id` int(11) NOT NULL,
  `replay_uid` int(11) NOT NULL COMMENT '当前客服uid',
  `replay_type` varchar(255) NOT NULL,
  `content` text,
  `replay_time` int(11) DEFAULT '0',
  PRIMARY KEY (`replay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信用户消息回复表';

